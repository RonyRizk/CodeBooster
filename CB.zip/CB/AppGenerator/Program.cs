﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Reflection;
using CodeGenerator;
using System.Net;
using CodeBoosterClientNS;
using CodeBoosterClient.CodeBoosterWCF;

namespace CodeGenerator
{
    class Program
    {
        #region Members
        private static string _ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
        private static DALC.Training oTraining = new DALC.Training(_ConnectionString);
        private static CodeBoosterClientNS.CodeBoosterClient oCodeBoosterClient = new CodeBoosterClientNS.CodeBoosterClient(oTraining);
        private static CodeBooster oCodeBooster = oCodeBoosterClient.My_CodeBooster;
        #endregion
        #region Main
        static void Main(string[] args)
        {
            #region Initialization & Authentication
            oCodeBooster.Tables_Excluded_From_Generatrion_Process = new List<string>();
            oCodeBooster.KeysMapper = new Dictionary<string, string>();
            oCodeBooster.WCFMethodsGenerationMode = Enum_WCFMethodsGenerationMode.Selection;
            oCodeBooster.WCFMethodsSelection = new List<string>();
            oCodeBooster.Methods_With_Events = new List<string>();
            oCodeBooster.Methods_With_Events_By_Ref = new List<string>();
            oCodeBooster.DefaultRecordsToCreate = new Dictionary<string, string>();
            oCodeBooster.Tables_Static_Data = new List<string>();
            oCodeBooster.NonSetup_Fields = new List<string>();
            oCodeBooster.Tables_To_Create_Get_By_Hierarchy = new List<HierarchyBracket>();
            oCodeBooster.Tables_Exluded_From_12M_Hanlder = new List<string>();
            oCodeBooster.ByPassed_PreCheck_Notifications = new List<Notification_ByPassing>();
            oCodeBooster.AssemblyPath = ConfigurationManager.AppSettings["BLC_PATH"];
            oCodeBooster.Is_Show_Notifications_In_Console = true;
            oCodeBoosterClient.Authenticate_User();


            Params_ConvertTypeSchemaToUIFields oParams_ConvertTypeSchemaToUIFields = new Params_ConvertTypeSchemaToUIFields();
            Search_AdvancedProp oSearch_AdvancedProp = new Search_AdvancedProp();
            WebClient oWebClient = new WebClient();
            UIFields oUIFields = new UIFields();
            #endregion
            #region Events
            //oCodeBooster.Methods_With_Events.Add("Edit_User");
            //oCodeBooster.Methods_With_Events.Add("Delete_Document");
            #endregion
            #region Events By Ref
            //oCodeBooster.Methods_With_Events_By_Ref = new List<string>();
            //oCodeBooster.Methods_With_Events_By_Ref.Add("Get_Document_By_REL_KEY_NAME");
            //oCodeBooster.Methods_With_Events_By_Ref.Add("Get_Document_By_REL_KEY_REL_ENTITY");           
            #endregion
            #region Uploaded_files
            //oCodeBooster.Is_Uploaded_File_Feature = true;
            //oCodeBooster.Uploaded_Files_BackEnd_Events = new List<Uploaded_File_BackEnd_Event>();
            //oCodeBooster.Uploaded_Files_BackEnd_Events.Add(new Uploaded_File_BackEnd_Event() { TBL_NAME = "[TBL_PERSON]" , UI_METHOD_NAME = "Get_Person_By_Where", Mode = 0 });
            #endregion
            #region Caching
            //oCodeBooster.Methods_With_Caching = new List<Caching_Topology>();
            //oCodeBooster.Methods_With_Caching.Add(new Caching_Topology() { Method_Name = "Get_Person_By_PERSON_ID", Caching_Level = Enum_Caching_Level.Application });    
            #endregion
            #region Cash Dopper
            //oCodeBooster.Cash_Dropper_Collection = new List<string>();
            //oCodeBooster.Cash_Dropper_Collection.Add("[TBL_PERSON]");
            #endregion
            #region Excluding Tables From 12M Hanlder
            oCodeBooster.Tables_Exluded_From_12M_Hanlder = new List<string>();
            oCodeBooster.Tables_Exluded_From_12M_Hanlder.Add("[TBL_OWNER]");
            oCodeBooster.Tables_Exluded_From_12M_Hanlder.Add("[TBL_USER]");
            oCodeBooster.Tables_Exluded_From_12M_Hanlder.Add("[TBL_INC]");
            oCodeBooster.Tables_Exluded_From_12M_Hanlder.Add("[TBL_SETUP]");
            #endregion
            #region Body Section
            Console.WriteLine("Enter An Option:");
            Console.WriteLine("001 --> Create SP's & BLC Layer");
            Console.WriteLine("002 --> Generate WCF / JSON Code");
            Console.WriteLine("003 --> Generate UI");
            Console.WriteLine("004 --> Generate Profiling Patch");
            Console.WriteLine("005 --> Generate Multiligual Patch");
            Console.WriteLine("006 --> Generate Offline Patch");

            string str_Option = Console.ReadLine();
            #region Options
            oCodeBoosterClient.Local_Patch_Folder = @"D:\";
            oCodeBoosterClient.Is_Apply_CB_Rules = true;
            oCodeBoosterClient.Show_Embedded_TSql_Exceptions = false;
            oCodeBooster.Is_Create_DB_Demo = true;
            oCodeBooster.Is_Profiling_Enabled = false;
            oCodeBooster.Is_Multilingual_Enabled = false;
            oCodeBooster.Is_BackOffice_Enabled = false;
            oCodeBooster.Is_Offline_Enabled = false;
            oCodeBooster.Is_Summary_Enabled = false;
            oCodeBooster.Is_EnvCode_Enabled = false;
            oCodeBooster.Is_Generate_WCF_Caller = true;
            oCodeBooster.Is_Embed_USE_DB = true;
            oCodeBooster.UI_Root_Folder = @"C:\inetpub\wwwroot\ClinicPlusWeb\Content";
            oCodeBooster.Is_By_Criteria_Shadowed = true;

            #region Advanced Options
            oCodeBooster.Is_Renamed_Routines_Generation_Stopped = true;
            oCodeBooster.Is_Count_UDF_Generation_Stopped = true;
            oCodeBooster.Is_Create_Default_Record_Generation_Stopped = true;
            oCodeBooster.Is_Get_Rows_Generations_Stopped = true;
            oCodeBooster.Is_Get_By_Criteria_With_Entity_Generation_Stopped = true;
            oCodeBooster.Is_Business_Behavior_Generation_Stopped = true; 
            // oCodeBooster.Is_OnDemand_DALC = true;
            // oCodeBooster.Is_MemCached_Enabled = true;
            #endregion
            #endregion
            #region ByPassing Notification
            oCodeBooster.ByPassed_PreCheck_Notifications = new List<Notification_ByPassing>();
            oCodeBooster.ByPassed_PreCheck_Notifications.Add(new Notification_ByPassing() { TABLE_NAME = "[TBL_USER_TYPE]", COLUMN_NAME = "[USER_TYPE_CODE]", My_PreCheck_To_ByPass = Enum_Precheck_Enum.INVALID_CODE_FIELD });
            oCodeBooster.ByPassed_PreCheck_Notifications.Add(new Notification_ByPassing() { TABLE_NAME = "[TBL_USER]", COLUMN_NAME = "[OWNER_ID]", My_PreCheck_To_ByPass = Enum_Precheck_Enum.FK_INDEXED });
            oCodeBooster.ByPassed_PreCheck_Notifications.Add(new Notification_ByPassing() { TABLE_NAME = "[TBL_MENU]", COLUMN_NAME = "[OWNER_ID]", My_PreCheck_To_ByPass = Enum_Precheck_Enum.FLD_REQUIRED });

            oCodeBooster.ByPassed_PreCheck_Notifications.Add(new Notification_ByPassing() { TABLE_NAME = "[TBL_ENTITY]", COLUMN_NAME = "[CHILD_ID]", My_PreCheck_To_ByPass = Enum_Precheck_Enum.MAPPED_KEY });
            oCodeBooster.ByPassed_PreCheck_Notifications.Add(new Notification_ByPassing() { TABLE_NAME = "[TBL_CONTACT]", COLUMN_NAME = "[CHILD_ID]", My_PreCheck_To_ByPass = Enum_Precheck_Enum.MAPPED_KEY });
            #endregion
            #region WCF

            //----------------------------                    
            //oCodeBooster.WCFMethodsSelection.Add("IsAuthenticated_JSON");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Startup_Data");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Startup_Data_Signature");
            //oCodeBooster.WCFMethodsSelection.Add("EditSetup");                   
            //----------------------------


            // Person
            // ---------------------------------------------------------------------
            //oCodeBooster.WCFMethodsSelection.Add("Edit_Person");
            //oCodeBooster.WCFMethodsSelection.Add("Delete_Person");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Person_By_PERSON_ID");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Person_By_PERSON_ID_Adv");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Person_By_Criteria");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Person_By_Criteria_Adv");                    
            // ---------------------------------------------------------------------


            // Address
            // ---------------------------------------------------------------------
            //oCodeBooster.WCFMethodsSelection.Add("Edit_Address");
            //oCodeBooster.WCFMethodsSelection.Add("Delete_Address");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Address_By_PERSON_ID");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Address_By_PERSON_ID_Adv");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Address_By_ADDRESS_ID");
            //oCodeBooster.WCFMethodsSelection.Add("Get_Address_By_ADDRESS_ID_Adv");
            // ---------------------------------------------------------------------
            #endregion
            #region WCF ByPass Ticketing
            //oCodeBooster.List_ByPass_Ticketing = new List<string>();
            //oCodeBooster.List_ByPass_Ticketing.Add("Edit_Person");
            #endregion
            #region Audit
            //oCodeBooster.List_Tables_To_Audit = new List<string>();
            //oCodeBooster.List_Tables_To_Audit.Add("[TBL_PERSON]");
            #endregion
            #region Method Monitoring.
            //oCodeBooster.Is_Method_Monitoring_Enabled = true;
            #endregion
            #region Cache
            //oCodeBooster.Methods_With_Caching = new List<Caching_Topology>();
            //oCodeBooster.Methods_With_Caching.Add(new Caching_Topology() { Method_Name = "Get_Person_By_PERSON_ID" });
            #endregion
            #region Custom Procedure Caller
            //oCodeBooster.List_Procedure_Info = new List<Procedure_Info>();
            //oCodeBooster.List_Procedure_Info.Add(new Procedure_Info() { Procedure_Name = "UP_TEST", Result_CLR_Type = "Person", Result_Mode = Enum_Procedure_Result_Mode.List, Alias = "Test" });            
            #endregion
            switch (str_Option)
            {
                #region case "001":
                case "001":
                    oCodeBoosterClient.GenerateAllSPAndBLCLayer();
                    break;
                #endregion                
                #region case "002":
                case "002":

                    //----------------------------  
                    oCodeBooster.My_Enum_WCF_Target = Enum_WCF_Target.WebAPI;
                    oCodeBooster.My_Enum_WCF_Accessibility = Enum_WCF_Accessibility.Same_Domain;
                    //----------------------------  


                    // --------------                                        
                    oCodeBoosterClient.GenerateWCFLayer();
                    // --------------

                    break;
                #endregion
                #region case "003":
                case "003":

                    // --------------
                    UIFields oUIFields_EditUI = new UIFields();
                    UIFields oUIFields_Criteria = new UIFields();
                    UIFields oUIFields_Result = new UIFields();
                    // --------------

                    // --------------
                    oCodeBooster.My_Enum_UI_Target = Enum_UI_Target.HTML5;
                    oCodeBooster.My_Enum_HTML5_Target = Enum_HTML5_Target.NG;
                    oCodeBooster.Is_KOEditor_ASPX_Enabled = false;
                    // --------------


                    // Gather Required Data.
                    // --------------
                    oCodeBoosterClient.Gather_Required_Data();
                    // --------------

                    // Cleans UI Folder
                    // --------------
                    oCodeBoosterClient.Cleanse_UI_Patch_Folder();
                    // --------------

                    #region Person
                    #region Search Screen
                    oUIFields_Criteria = new UIFields();
                    oUIFields_Criteria.MainTableName = "[TBL_PERSON]";
                    oUIFields_Criteria.Based_On_Type = "BLC.Params_Get_Person_By_Criteria";

                    oUIFields_Result = new UIFields();
                    oUIFields_Result.MainTableName = "[TBL_PERSON]";
                    oUIFields_Result.Based_On_Type = "BLC.Person";
                    oUIFields_Result.GetMethodName = "Get_Person_By_Criteria";
                    oUIFields_Result.GridFields = new List<GridField>();



                    oSearch_AdvancedProp = new Search_AdvancedProp();
                    oSearch_AdvancedProp.ContainerMargins = "0,5,0,5";
                    oCodeBooster.Entity_FriendlyName = "Person";
                    oCodeBoosterClient.Generate_ListUI(Enum_SearchMethod.With_Criteria_Section, oUIFields_Criteria, oUIFields_Result, oSearch_AdvancedProp);
                    #endregion

                    #endregion
                    #region Address

                    oCodeBooster.My_Enum_UI_Target = Enum_UI_Target.HTML5;

                    #region Search Screen
                    oUIFields_Criteria = new UIFields();
                    oUIFields_Criteria.MainTableName = "[TBL_ADDRESS]";
                    oUIFields_Criteria.Based_On_Type = "BLC.Params_Get_Address_By_Criteria_InList";
                    oUIFields_Criteria.ParentTableName = new List<string>() { "[TBL_PERSON]" };


                    oUIFields_Result = new UIFields();
                    oUIFields_Result.MainTableName = "[TBL_ADDRESS]";
                    oUIFields_Result.Based_On_Type = "BLC.Address";
                    oUIFields_Result.GetMethodName = "Get_Address_By_Criteria_InList_Adv";
                    oUIFields_Result.ParentTableName = new List<string>() { "[TBL_PERSON]" };
                    oUIFields_Result.GridFields = new List<GridField>();


                    oSearch_AdvancedProp = new Search_AdvancedProp();
                    oSearch_AdvancedProp.ContainerMargins = "0,5,0,5";
                    oCodeBooster.Entity_FriendlyName = "Address";
                    oCodeBoosterClient.Generate_ListUI(Enum_SearchMethod.Without_Criteria_Section, oUIFields_Criteria, oUIFields_Result, oSearch_AdvancedProp);
                    #endregion

                    #endregion


                    // Send UI Patch
                    // -------------
                    oCodeBoosterClient.Send_UI_Patch();
                    // --------------

                    break;
                #endregion
                #region case "004"
                case "004":
                    oCodeBoosterClient.Generate_Profiling_Patch();
                    break;
                #endregion
                #region case "005"
                case "005":
                    oCodeBoosterClient.Generate_Multilingual_Patch();
                    break;
                #endregion
                #region case "006"
                case "006":
                    oCodeBoosterClient.Generate_Offline_Patch();
                    break;
                    #endregion
            }
            Console.WriteLine("Press Any Key To Exit");
            Console.ReadLine();
            #endregion
        }
        #endregion        
    }
}



