﻿
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using BLC;
using System;

public partial class DataController
{
    [HttpPost]
    public string Upload_Image()
    {
        #region Declaration And Initialization Section.
        string str_REL_ENTITY = string.Empty;
        string str_REL_FIELD = string.Empty;
        string str_REL_KEY = string.Empty;

        IEnumerable<KeyValuePair<string, string>> QueryStringEntries = null;

        string str_File_Name = string.Empty;        
        string str_Extension = string.Empty;
        string str_Main_Folder = ConfigurationManager.AppSettings["UPLOAD_DOCUMENT_LOCATION"];
        string str_File_Full_Path = string.Empty;

        Uploaded_file oUploaded_file = new Uploaded_file();
        Tools.Tools oTools = new Tools.Tools();
        #endregion

        #region Body Section.

        #region Extract Required Data from Query string
        QueryStringEntries = Request.GetQueryNameValuePairs();
        str_REL_ENTITY = QueryStringEntries.First(x => x.Key == "REL_ENTITY").Value;
        str_REL_FIELD = QueryStringEntries.First(x => x.Key == "REL_FIELD").Value;
        str_REL_KEY = QueryStringEntries.First(x => x.Key == "REL_KEY").Value;
        #endregion

        #region Loop Over Each Uploaded File
        foreach (string fileName in HttpContext.Current.Request.Files)
        {
            #region Get Each Submitted File
            HttpPostedFile oHttpPostedFile = HttpContext.Current.Request.Files[fileName];
            #endregion

            #region Extract Extension
            // str_Extension = oHttpPostedFile.ContentType.Split(new char[] { '/' })[1];
            str_Extension = oHttpPostedFile.FileName.Substring
                                                            (
                                                               oHttpPostedFile.FileName.LastIndexOf(".") + 1, 
                                                               oHttpPostedFile.FileName.Length - oHttpPostedFile.FileName.LastIndexOf(".") - 1 
                                                            );
            #endregion

            #region Create Uploaded_file entry
            oUploaded_file = new Uploaded_file();
            oUploaded_file.UPLOADED_FILE_ID = -1;
            oUploaded_file.REL_ENTITY = str_REL_ENTITY;
            oUploaded_file.REL_FIELD = str_REL_FIELD;
            oUploaded_file.REL_KEY = Convert.ToInt64(str_REL_KEY);         
            oUploaded_file.SIZE = -1;
            oUploaded_file.EXTENSION = str_Extension;
            oUploaded_file.STAMP = oTools.Get_Unique_String();

            BLC.BLC oBLC_Default = new BLC.BLC();
            BLCInitializer oBLCInitializer = oBLC_Default.Prepare_BLCInitializer("", BLC.BLC.Enum_WCF_Method.Authenticate);
            using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
            {
                oBLC.Edit_Uploaded_file(oUploaded_file);
            }
            #endregion


            #region File Info
            str_File_Name = string.Format("{0}.{1}", oUploaded_file.UPLOADED_FILE_ID.ToString(), str_Extension);
            str_File_Full_Path = string.Format(@"{0}\{1}", str_Main_Folder, str_File_Name);
            #endregion

            #region Save File on Disk           
             oHttpPostedFile.SaveAs(str_File_Full_Path);
            #endregion
        }
        #endregion

        #endregion 

        #region Return Section.            
        return str_File_Name;
        #endregion
    }
}

