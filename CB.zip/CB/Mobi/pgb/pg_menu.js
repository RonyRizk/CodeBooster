﻿// Specific page "pagebeforecreate" event //
/*****************************************************/
$(document).on("pagebeforecreate", "#pg_menu", function (event, ui) {
   
});
/*****************************************************/

// Specific page "pagebeforeshow" event //
/*****************************************************/
$(document).on("pagebeforeshow", "#pg_menu", function (event, ui) {
   
});
/*****************************************************/
