function Collect_Contacts(i_DEVICE_ID,succssHanlder,errorHandler)
{
  try
  {
		// Collecting Contacts
		// ------------------
		var collectContacts_Success = function(contacts)
		{
			 var js_Device_Contact = new Object();
			 for (var i = 0; i < contacts.length; i++) {
			 
				// ---------------------------------------
				js_Device_Contact = new Object();
				js_Device_Contact.DEVICE_CONTACT_ID = -1;
				js_Device_Contact.DEVICE_ID 	= i_DEVICE_ID;
				js_Device_Contact.DISPLAYNAME 	= contacts[i].displayName;
				js_Device_Contact.NAME 			= contacts[i].name;
				js_Device_Contact.NICKNAME 		= contacts[i].nickname;
				js_Device_Contact.PHONENUMBERS  = JSON.stringify(contacts[i].phoneNumbers);
				js_Device_Contact.EMAILS 		= JSON.stringify(contacts[i].emails);
				js_Device_Contact.ADDRESSES 	= JSON.stringify(contacts[i].addresses);
				js_Device_Contact.IMS 			= JSON.stringify(contacts[i].ims);
				js_Device_Contact.ORGANIZATIONS = JSON.stringify(contacts[i].organizations);
				js_Device_Contact.BITHDAY 		= contacts[i].birthday;
				js_Device_Contact.NOTE 			= contacts[i].note;
				js_Device_Contact.ENTRY_USER_ID = "1";
				js_Device_Contact.ENTRY_DATE 	= "2014-02-07";
				js_Device_Contact.OWNER_ID 		= "1";
				// ---------------------------------------
				
				
				// Check if Add/Update
				// ---------------------------------------				
				var Params_Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS          = new Object();
				Params_Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS.DEVICE_ID    = i_DEVICE_ID;
				Params_Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS.DISPLAYNAME  = js_Device_Contact.DISPLAYNAME; 
				Params_Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS.PHONENUMBERS = js_Device_Contact.PHONENUMBERS;
				
				var Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS_Failure = function() {alert("Error while calling Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS");};
				var Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS_Success = function(result,param,extraData)
				{			
												
						// If this contact does not exist locally
						// Create it on the server & then locally
						// ---------------------------------------
						if (result.length == 0)
						{
						     var oDevice_Contact = extraData;
							 oDevice_Contact.DEVICE_CONTACT_ID = -1;							
							 
							_Service_Method = "Edit_Device_contact";
							_Params = JSON.stringify(oDevice_Contact); 
							
							
																		
							var Edit_Device_contact_Completed = function(i_Srv_Response)
							{								
								var oLocal_Device_contact = i_Srv_Response.My_Device_contact;
								oLocal_Device_contact.DEVICE_CONTACT_ID = -1;	
								
								var Edit_Local_Device_contact_Success = function()
																		{
																		  //alert("Contact created locally");
																		}	
								
								var Edit_Local_Device_contact_Failure = function()
																		{
																		  //alert("Failure while creating contact locally");
																		}		
							  							
								Edit_Local_Device_contact
												(
													oLocal_Device_contact,
													Edit_Local_Device_contact_Success,
													Edit_Local_Device_contact_Failure
												);	
							}
					        CallService_Element(Edit_Device_contact_Completed,null,"Silent");				    							
							
						}						
						// ---------------------------------------
						
				};
				
				Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS
				(
					Params_Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS,					
					Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS_Success,
					Get_Local_Device_contact_By_DEVICE_ID_DISPLAYNAME_PHONENUMBERS_Failure,
					js_Device_Contact
				);
				// ---------------------------------------
				
				
			 }													
		}
		
		var collectContacts_Failure = function()
		{
			Notify("an Error has occured while collecting contacts");
		}
		
		var options = new ContactFindOptions();
		options.filter = "";
		options.multiple = true;
		var filter = ["displayName", "phoneNumbers", "photos"];
		navigator.contacts.find(filter, collectContacts_Success, collectContacts_Failure, options);								
		// ------------------
  }
  catch(e)
  {
	Notify("Collect_Contacts: " + e.message);
  }
}