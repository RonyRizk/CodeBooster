// ---------------------------------------------------------------
var js_DBEngine = "1";
var _Is_Offline_Mode = false;
var _Exclusive_Tables_To_Sync = [];
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function Get_DB_Handler(successHandler, failureHandler) {
    try {
        switch (js_DBEngine) {
            case "1": // WebSQL	         
                Get_WebSqlDB_Handler(successHandler, failureHandler);
                break;
            case "2": // IndexedDB	         
                Get_IndexedDB_Handler(successHandler, failureHandler);
                break;
        }
    }
    catch (e) {
        alert("Get_DB_Handler: " + e.Message);
    }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function DB_Initializer
    (
        preFunction,
        preFunctionLocal,
        postFunctionLocal,
        preFunctionRemote,
        postFunctionRemote,
        offlineFunction, 
        i_Extra_LocalDB_Params
    )
{
  try
  {
      // ---------------------------------------------------------------      
      if ($.browser.msie == true || $.browser.mozilla == true) {
          js_DBEngine = "2";
      }
      else {
          js_DBEngine = "1"; 
      }	 
     js_DBEngine = "1"; //XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX <<<<<<<<<<< to be removed
	 // ---------------------------------------------------------------

	 // ---------------------------------------------------------------	 
	 switch (js_DBEngine) {
	     case "1": // WebSQL	         
	         Get_Local_WebSqlDB
                    (
                        preFunction,
                        preFunctionLocal,
                        postFunctionLocal,
                        preFunctionRemote,
                        postFunctionRemote,
                        offlineFunction, 
                        i_Extra_LocalDB_Params
                    );
	         break;
	     case "2": // IndexedDB	         
	         Get_Local_IndexedDB
                    (
                        preFunction,
                        preFunctionLocal,
                        postFunctionLocal,
                        preFunctionRemote,
                        postFunctionRemote,
                        offlineFunction, 
                        i_Extra_LocalDB_Params
                    );
	         break;
	     default:

	         // Detect IndexedDB support
	         // ---------------------------------------------------------------
	         window.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;
	         window.IDBKeyRange = window.IDBKeyRange || window.webkitIDBKeyRange || window.msIDBKeyRange;
	         // ---------------------------------------------------------------

	         // Switch between IndexedDB & WebSQL
	         // --------------------------------------------------------------	 
	         if (!window.indexedDB) {
	             Notify("Your browser doesn't support a stable version of IndexedDB. Such and such feature will not be")
	             Get_Local_WebSqlDB
                 (
                    preFunction,
                    preFunctionLocal,
                    postFunctionLocal,
                    preFunctionRemote,
                    postFunctionRemote,
                    offlineFunction, 
                    i_Extra_LocalDB_Params
                 );
	         }
	         else {
	             Notify("Your browser supports a stable version of IndexedDB.")
	             Get_Local_IndexedDB
                 (
                    preFunction,
                    preFunctionLocal,
                    postFunctionLocal,
                    preFunctionRemote,
                    postFunctionRemote,
                    offlineFunction, 
                    i_Extra_LocalDB_Params
                 );
	         }
	         // ---------------------------------------------------------------            
	 }
	 // ---------------------------------------------------------------
	 
  }
  catch(e)
  {
    Notify("DB_Initializer: " + e.message);
  }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function Sync_From_Scratch(i_Table_Name, successHandler, errorHandler) {
    try {

        if (WebSqlDB != null) {
            Sync_From_Scratch_WebSqlDB(i_Table_Name, successHandler, errorHandler);
            return;
        }

        if (MyIndexedDB != null) {           
            Sync_From_Scratch_IndexedDB(i_Table_Name, successHandler, errorHandler);
            return;
        }
    }
    catch (e) {
        Notify("Sync_From_Scratch:" + e.message);
    }
}
// ---------------------------------------------------------------


// ---------------------------------------------------------------
function Notify_Sync_Summary()
{
  try
  {	
     if (WebSqlDB != null) {		
		Notify_Sync_Summary_WebSqlDB();
		return;
	 }
	 
	 if (MyIndexedDB != null) {	    
		Notify_Sync_Summary_IndexedDB();
		return;
	 }
  }
  catch(e)
  {
    Notify("Notify_Sync_Summary:" + e.message);
  }
}
// ---------------------------------------------------------------
