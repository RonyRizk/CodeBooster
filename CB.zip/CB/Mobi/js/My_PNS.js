// -------------------------
var js_PNS_DEVICE_ID = 0;
var js_GCM_SenderID  = null;
// -------------------------

// -------------------------
var MySuccessHanlder = null;
var MyfailureHandler = null;
// -------------------------

// -------------------------
function Assure_PNS_Token_Registration(DEVICE_ID,successHandler,failureHandler)
{
 try
 {

     var Get_Local_Setup_PushNotification_Success = function (result) {

         // -------------------
         if (result.length == 0) {
             alert("My_PNS: _PUSH_NOTIFICATION Setup table is not existing");
             return;
         }
         else {
             for (var i = 0; i < result.length; i++) {
                 if (result[i].CODE_NAME == 'GCM_PROJECT_ID') {
                     js_GCM_SenderID = result[i].CODE_VALUE_EN;
                 }
             }
         }
         // -------------------

         // -------------------
         if (js_GCM_SenderID == null) {
             alert("My_PNS: GCM_PROJECT_ID is not defined");
             return;
         }
         // -------------------

         // ------------------	
         js_PNS_DEVICE_ID = DEVICE_ID;
         // ------------------	

         // ------------------
         MySuccessHanlder = successHandler;
         MyfailureHandler = failureHandler;
         // ------------------

         // ------------------
         getToken();
         // ------------------

         // Check if this device has already Push notification Token (PNS_TOKEN)
         // ------------------	
         /*
         var Get_Local_Device_data_By_DATA_KEY_OWNER_ID_Success = function (result) {
             if (result.length == 0) {
                 getToken();
             }
             else {
                 Notify("Device already has : " + result[0].DATA_VALUE);
                 if (successHandler != null) {
                     successHandler(result[0].DATA_VALUE);
                 }
             }
         };

         var Get_Local_Device_data_By_DATA_KEY_OWNER_ID_Failure = function () {
             Notify("Error while issuing Get_Local_Device_data_By_DATA_KEY_OWNER_ID");
             if (failureHandler != null) { failureHandler(); }
         };

         var Params_Get_Local_Device_data_By_DATA_KEY_OWNER_ID = new Object();
         Params_Get_Local_Device_data_By_DATA_KEY_OWNER_ID.OWNER_ID = 1;
         Params_Get_Local_Device_data_By_DATA_KEY_OWNER_ID.DATA_KEY = "PNS_TOKEN";
         Get_Local_Device_data_By_DATA_KEY_OWNER_ID
	    (
		    Params_Get_Local_Device_data_By_DATA_KEY_OWNER_ID,
		    Get_Local_Device_data_By_DATA_KEY_OWNER_ID_Success,
		    Get_Local_Device_data_By_DATA_KEY_OWNER_ID_Failure
	    );
        */
         // ------------------

     }


    // Get Required Push notification setup entries
	// ------------------
	var Params_Get_Local_Setup_PushNotification = new Object();	
	Params_Get_Local_Setup_PushNotification.TBL_NAME = '_PUSH_NOTIFICATION';

	Get_Local_Setup_By_TBL_NAME
    (
       Params_Get_Local_Setup_PushNotification,
       Get_Local_Setup_PushNotification_Success,
       null
    );
    // ------------------

 }
 catch(e)
 {
   Notify("Assure_PNS_Token_Registration:" + e.message);
 }
}
// -------------------------

// -------------------------
function getToken() {
    try {
        var pushNotification = window.plugins.pushNotification;
        var js_platform = device.platform;
        if (js_platform == 'android' || js_platform == 'Android') {
            pushNotification.register(this.GCM_SuccessHanlder, this.errorHandler, { "senderID": js_GCM_SenderID, "ecb": "onNotificationGCM" });
        }
        else {
            pushNotification.register(this.APN_SuccessHanlder, this.errorHandler, { "badge": "true", "sound": "true", "alert": "true", "ecb": "onNotificationAPN" });
        }
    }
    catch (e) {
        // Ex: In case of Ripple emulator, this function will throw an exception.
        Notify("getToken: " + e.Message);
    }
};
// -------------------------

// -------------------------
function GCM_SuccessHanlder(input)
{
    Notify("Token retrieved from GCM : " + input);    
}
// -------------------------

// -------------------------
function APN_SuccessHanlder(msg) {
    Notify("Token retrieved from APN: " + msg);
    Register_PNS_Token(msg, MySuccessHanlder, MyfailureHandler);  
}
// -------------------------

// -------------------------
function errorHandler(error)
{
  Notify("Error Handler  " + error);
}
// -------------------------

// -------------------------
function onNotificationAPN(event)
{
	var pushNotification = window.plugins.pushNotification;
	if (event.alert) {
	        //alert(event.alert);
	        Handle_Incoming_Notification(event.alert);
        }
        if (event.badge) {
            Notify("Set badge on  " + pushNotification);
            pushNotification.setApplicationIconBadgeNumber(this.successHandler, event.badge);
        }
        if (event.sound) {
            var snd = new Media(event.sound);
            snd.play();
        }
}
// -------------------------
    
	
// -------------------------	
function onNotificationGCM(e)
{    
	switch (e.event) {
	    case 'registered':	        
	        if (e.regid.length > 0) {	            
	            Register_PNS_Token(e.regid, MySuccessHanlder, MyfailureHandler);
	        }
	        break;
	    case 'message':


	        if (e.foreground) {
	            Handle_Incoming_Notification(e.payload.alert);
	        }
	        else {  // otherwise we were launched because the user touched a notification in the notification tray.
	            if (e.coldstart) {
	                Handle_Incoming_Notification(e.payload.alert);
	            }
	            else {
	                Handle_Incoming_Notification(e.payload.alert);
	            }
	        }

	        //alert(e.payload.alert);
	        //alert('message = ' + e.message + ' msgcnt = ' + e.msgcnt);
	        break;

            case 'error':
                alert('GCM error = ' + e.msg);
                break;

            default:
                alert("Unkown GCM event has occured");
                break;
        }
}
// -------------------------
	
// -------------------------
function Register_PNS_Token(Token,successHandler,failureHandler)
{
		try
		{
			
			// -------------------------
			var js_PNS_Token = new Object();
			js_PNS_Token.DEVICE_ID = js_PNS_DEVICE_ID;
			js_PNS_Token.PNS_TOKEN = Token;
			// -------------------------
						
			
			// -------------------------        
			_Service_Method = "Register_PNS_Token";
			_Params = JSON.stringify(js_PNS_Token);			

			var Register_PNS_Token_Completed = function (i_Srv_Response) {
            			   
			    // ------------------
			    var js_Device_data = new Object();
			    js_Device_data.DEVICE_DATA_ID = -1;
			    js_Device_data.DATA_KEY = "PNS_TOKEN";
			    js_Device_data.DATA_VALUE = Token;
			    js_Device_data.ENTRY_USER_ID = 1;
			    js_Device_data.ENTRY_DATE = "2014-02-10";
			    js_Device_data.OWNER_ID = 1;



			    var Edit_Local_Device_data_Success = function (entity, editMode) {
			        Notify("Token: " + entity.DATA_VALUE);
			        if (successHandler != null) {
			            successHandler(entity.DATA_VALUE);
			        }
			    };
			    var Edit_Local_Device_data_Failure = function () {
			        Notify("Error while creating entry in TBL_DEVICE_DATA")
			        if (failureHandler != null) { failureHandler(); }
			    };
			    Edit_Local_Device_data
				(
					js_Device_data,
					Edit_Local_Device_data_Success,
					Edit_Local_Device_data_Failure
				);
			    // ------------------

			};

			var Register_PNS_Token_Failure = function () {				
				if (failureHandler != null) {failureHandler();}
			};

			CallService_Element(Register_PNS_Token_Completed,Register_PNS_Token_Failure,"Silent");
			// -------------------------
		}
		catch(e)
		{
		  Notify("Register_PNS_Token: " + e.message);
		}
}
// -------------------------

// -------------------------
function Handle_Incoming_Notification(message) {

    function alertDismissed() {
        // do something
    }

    navigator.notification.alert(
                message,  // message
                alertDismissed,         // callback
                'FlyingRoses',            // title
                'OK'                  // buttonName
            );

}
// -------------------------





