//------------------------------
var _TX_Count = -1;
//------------------------------

// Pre/Post Events
//------------------------------
var onPreEvent_IndexedDB = null;

var onPreEvent_IndexedDB_LocalDB = null;
var onPostEvent_IndexedDB_LocalDB = null;

var onPreEvent_IndexedDB_RemoteDB = null;
var onPostEvent_IndexedDB_RemoteDB = null;

var onPostEvent_IndexedDB_OfflineMode = null;
//------------------------------

// Declaration and initialization section
// ---------------------------------------------------------------
var MyIndexedDB = null;
var db = null;
var js_IndexedDB_Definition = null;
var js_IndexedDBName = "";
var js_IndexedDBVersion = 1;
var js_Sync_Summary_IndexedDB = "";
var js_Extra_LocalDB_Params_IndexedDB = null;
var IndexedDB_Is_Call_Server_After_Local_Initialization = false;
// ---------------------------------------------------------------


// ---------------------------------------------------------------
window.indexedDB = window.indexedDB || window.mozIndexedDB || window.webkitIndexedDB || window.msIndexedDB;
window.IDBKeyRange = window.IDBKeyRange || window.webkitIDBKeyRange || window.msIDBKeyRange;
// ---------------------------------------------------------------

// ---------------------------------------------------------------
if (!window.indexedDB) {
	Notify("Your browser doesn't support a stable version of IndexedDB. Such and such feature will not be")
};
// ---------------------------------------------------------------


// ---------------------------------------------------------------
function Get_IndexedDB_Handler(successHandler,failureHandler) {
    try {
        if (localStorage.getItem("IndexedDB_DB_Initial_Data_Populated") != null) 
        {
	        if (localStorage.getItem("IndexedDB_DB_Info") != null)
	        {
		        //------------------------------
			    db = null;
			    var databaseOptions = JSON.parse(localStorage.getItem("IndexedDB_DB_Info"));
			    //------------------------------

			    // Open Database request
			    //------------------------------
			    var req_Open = indexedDB.open(databaseOptions.fileName, databaseOptions.version);
			    req_Open.onsuccess = function (event) {
				    db = event.target.result;
				    MyIndexedDB = db;

                    if (successHandler != null){successHandler();}
			    };

			    req_Open.onerror = function (event) {
				    alert("Database error code: " + event.target.errorCode);
                    if (failureHandler != null) {failureHandler();}
			    };
			    //------------------------------	
	        }
        }
    }
    catch (e) {

        //------------------------------
        if (failureHandler != null) { failureHandler(); }
        //------------------------------

        //------------------------------
        alert("Get_IndexedDB_Handler:" + e.Message);
        //------------------------------
    }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function Get_Local_IndexedDB
(
	preFunction,
	preFunctionLocalDB,
	postFunctionLocalDB,
	preFunctionRemoteDB,
	postFunctionRemoteDB,
	offlineFunction,
	i_Extra_LocalDB_Params) {
	try {

		/* ----------------- */
		onPreEvent_IndexedDB = preFunction;

		onPreEvent_IndexedDB_LocalDB = preFunctionLocalDB;
		onPostEvent_IndexedDB_LocalDB = postFunctionLocalDB;

		onPreEvent_IndexedDB_RemoteDB = preFunctionRemoteDB;
		onPostEvent_IndexedDB_RemoteDB = postFunctionRemoteDB;

		onPostEvent_IndexedDB_OfflineMode = offlineFunction;
		js_Extra_LocalDB_Params_IndexedDB = i_Extra_LocalDB_Params;
		/* ----------------- */

		// Fire PreEvent
		/* ----------------- */
		if (onPreEvent_IndexedDB != null) {
			onPreEvent_IndexedDB();
		}
		/* ----------------- */

		// Initial Data to be applied
		/* ----------------- */
		if (localStorage.getItem("IndexedDB_DB_Initial_Data_Populated") == null) {
			if (onPreEvent_IndexedDB_LocalDB != null) {
				onPreEvent_IndexedDB_LocalDB();
			}

			IndexedDB_Is_Call_Server_After_Local_Initialization = true;
			Populate_Initial_IndexedDB_Data();
			return;
		} else {
			if (onPreEvent_IndexedDB_RemoteDB != null) {

                if (localStorage.getItem("IndexedDB_DB_Info") != null)
                {

				    //------------------------------
				    db = null;
				    var databaseOptions = JSON.parse(localStorage.getItem("IndexedDB_DB_Info"));
				    //------------------------------

				    // Open Database request
				    //------------------------------
				    var req_Open = indexedDB.open(databaseOptions.fileName, databaseOptions.version);
				    req_Open.onsuccess = function (event) {
					    db = event.target.result;
					    MyIndexedDB = db;
				    };

				    req_Open.onerror = function (event) {
					    alert("Database error code: " + event.target.errorCode);
				    };
				    //------------------------------

				    //------------------------------
				    onPreEvent_IndexedDB_RemoteDB();
				    //------------------------------

                    IndexedDB_Is_Call_Server_After_Local_Initialization = false;
                }
			}			
		}
		/* ----------------- */

		/* ----------------- */
		if (localStorage.getItem("IndexedDB_DB_Info") == null) {
			var Params_Get_LocalDB = new Object();
			Params_Get_LocalDB.My_Sync_data = [];
			Params_Get_LocalDB.LocalDB_Type = 0;
			Params_Get_LocalDB.My_Extra_LocalDB_Params = js_Extra_LocalDB_Params_IndexedDB;

			var Get_Local_IndexedDB_Failure = function () {
				Notify("Failure while calling Get_LocalDB");
			}

			_Params = JSON.stringify(Params_Get_LocalDB);
			_Service_Method = "Get_LocalDB";
			CallService_Element(Get_Local_IndexedDB_Completed, Get_Local_IndexedDB_Failure, "Silent");
		} else {
			Prepare_Indexed_Sync_Data();
		}
		/* ----------------- */
	} catch (e) {
		alert("Get_Local_IndexedDB : " + e.message);
	}
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function Populate_Initial_IndexedDB_Data() {
	try {

		/* ----------------- */
		var js_InitialData = new Object();
		js_InitialData.My_Result = null;
		js_InitialData.My_Result = JSON.stringify(js_MyData_IDB);
		localStorage.setItem("IndexedDB_DB_Initial_Data_Populated", true);
		Get_Local_IndexedDB_Completed(js_InitialData);
		/* ----------------- */

	} catch (e) {
		localStorage.removeItem("IndexedDB_DB_Initial_Data_Populated");
		Notify("Populate_Initial_IndexedDB_Data: " + e.message);
	}
}
// ---------------------------------------------------------------

// Prepare_Indexed_Sync_Data
// ---------------------------------------------------------------
function Prepare_Indexed_Sync_Data() {
	try {

		//------------------------------
		db = null;
		var databaseOptions = JSON.parse(localStorage.getItem("IndexedDB_DB_Info"));
		//------------------------------

		//------------------------------
		var transactionScope = [];
		transactionScope.push("TBL_SYNC_DATA");
		//------------------------------

		//------------------------------
		var Params_Get_LocalDB = new Object();
		Params_Get_LocalDB.My_Sync_data = [];
		Params_Get_LocalDB.LocalDB_Type = 0;
		Params_Get_LocalDB.My_Extra_LocalDB_Params = js_Extra_LocalDB_Params_IndexedDB;
		//------------------------------

		//------------------------------
		var Get_Local_IndexedDB_Failure_OfflineMode = function () {
			Notify("Failure while calling Get_LocalDB");

			if (onPostEvent_IndexedDB_OfflineMode != null) {
				onPostEvent_IndexedDB_OfflineMode();
			}

			if (onPostEvent_IndexedDB_LocalDB != null) {
				onPostEvent_IndexedDB_LocalDB();
			}

			if (onPostEvent_IndexedDB_RemoteDB != null) {
				onPostEvent_IndexedDB_RemoteDB();
			}
		}
		//------------------------------

		//------------------------------
		var req_Open = indexedDB.open(databaseOptions.fileName, databaseOptions.version);
		req_Open.onsuccess = function (event) {

			db = event.target.result;
			MyIndexedDB = db;

			transaction = db.transaction(transactionScope, "readwrite");

			var objectStore = transaction.objectStore("TBL_SYNC_DATA");

			objectStore.openCursor().onsuccess = function (ev) {

				var cursor = ev.target.result;

				// ---------------------
				try {
					if (cursor) {

						// ------------
						var js_Sync_Data = new Object();
						js_Sync_Data.TABLE_NAME = cursor.value.TABLE_NAME;
						js_Sync_Data.LAST_AUDIT_ID = cursor.value.LAST_AUDIT_ID;
						Params_Get_LocalDB.My_Sync_data.push(js_Sync_Data);
						cursor.continue();
						// ------------
					} else {
						// To Support Exclusive Tables to Sync.
						// ------------
						if ((_Exclusive_Tables_To_Sync != null) && (_Exclusive_Tables_To_Sync.length > 0)) {
							for (var i = Params_Get_LocalDB.My_Sync_data.length - 1; i >= 0; i--) {
								if ($.inArray("[" + Params_Get_LocalDB.My_Sync_data[i].TABLE_NAME + "]", _Exclusive_Tables_To_Sync) < 0) {
									Params_Get_LocalDB.My_Sync_data.splice(i, 1);
								}
							}
						}
						// ------------

						// ------------
						_Params = JSON.stringify(Params_Get_LocalDB);
						_Service_Method = "Get_LocalDB";
						CallService_Element(Get_Local_IndexedDB_Completed, Get_Local_IndexedDB_Failure_OfflineMode, "Silent");
						// ------------
					}
				} catch (e) {
					alert(e.message);
				}
				// ---------------------
			};
		};
		//------------------------------

	} catch (e) {
		Notify("Prepare_Indexed_Sync_Data: " + e.Message);
	}
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function Get_Local_IndexedDB_Completed(i_Response) {
	try {

		//------------------------------
		js_IndexedDB_Definition = JSON.parse(i_Response.My_Result);
		js_IndexedDBName = js_IndexedDB_Definition.Name;
		js_IndexedDBVersion = js_IndexedDB_Definition.Version;
		js_Sync_Summary_IndexedDB = js_IndexedDB_Definition.My_Sync_Summary;
		//------------------------------

		// Prepare Database options
		//------------------------------
		var databaseOptions = {
			fileName : js_IndexedDBName,
			version : js_IndexedDBVersion,
			displayName : js_IndexedDBName
		};
		//------------------------------

		// Drop DB in case the name sent from server is different than the local one.
		//------------------------------
		if (localStorage.getItem("IndexedDB_DB_Info") != null) {
			var js_LocalDB_Info = JSON.parse(localStorage.getItem("IndexedDB_DB_Info"));
			if (js_LocalDB_Info.fileName != js_IndexedDB_Definition.Name) {
				localStorage.removeItem("IndexedDB_DB_Info");
				indexedDB.deleteDatabase(js_LocalDB_Info.fileName);
				Get_Local_IndexedDB
				(
					onPreEvent_IndexedDB,
					onPreEvent_IndexedDB_LocalDB,
					onPostEvent_IndexedDB_LocalDB,
					onPretEvent_IndexedDB_RemoteDB,
					onPostEvent_IndexedDB_RemoteDB,
					onPostEvent_IndexedDB_OfflineMode,
					js_Extra_LocalDB_Params_IndexedDB);
				return;
			}
		}
		//------------------------------

		//------------------------------
		localStorage.setItem("IndexedDB_DB_Info", JSON.stringify(databaseOptions))
		//------------------------------

		//------------------------------
		Create_IndexedDB();
		//------------------------------

	} catch (e) {
		alert("Get_Local_IndexedDB_Completed: " + e.message);
	}
}
// ---------------------------------------------------------------


// ---------------------------------------------------------------
function Create_IndexedDB() {

	// Open Database request
	// -----------------------------------------
	var req_Open = indexedDB.open(js_IndexedDBName, js_IndexedDBVersion);
	req_Open.onsuccess = function (event) {
		db = event.target.result;
		MyIndexedDB = db;
		Synchronize_IndexedDB();
	};

	req_Open.onerror = function (event) {
		alert("Database error code: " + event.target.errorCode);
	};

	req_Open.onupgradeneeded = function (event) {
		try {
			db = event.target.result;
			if (js_IndexedDB_Definition.My_LocalObjectStores != null) {
				for (var k = 0; k < js_IndexedDB_Definition.My_LocalObjectStores.length; k++) {
					try {
						var js_Current_ObjectStore = js_IndexedDB_Definition.My_LocalObjectStores[k];
						var js_ObjectStoreName = js_Current_ObjectStore.Name;
						var js_keyPath = js_Current_ObjectStore.keyPath;
						var objectStore = null;

						if (!db.objectStoreNames.contains(js_ObjectStoreName)) {

							// Create ObjectStore
							// ------------------------------
							if
							(
								(js_keyPath != null) &&
								(js_keyPath != '')) {
								objectStore = db.createObjectStore(js_ObjectStoreName, {
										keyPath : js_keyPath,
										autoIncrement : js_Current_ObjectStore.Is_AutoIncrement
									});
							} else {
								objectStore = db.createObjectStore(js_ObjectStoreName, {
										autoIncrement : js_Current_ObjectStore.Is_AutoIncrement
									});
							}
							// ------------------------------

							// Index
							// ------------------------------
							if (js_Current_ObjectStore.My_LocalIndexes != null) {
								var js_Index_Fields = "";
								for (var L = 0; L < js_Current_ObjectStore.My_LocalIndexes.length; L++) {
									if (js_Current_ObjectStore.My_LocalIndexes[L].My_Fields != null) {
										js_Index_Fields = js_Current_ObjectStore.My_LocalIndexes[L].My_Fields.join(",");
										objectStore.createIndex
										(
											js_Current_ObjectStore.My_LocalIndexes[L].Name,
											js_Current_ObjectStore.My_LocalIndexes[L].My_Fields, {
											unique : js_Current_ObjectStore.My_LocalIndexes[L].Is_Unique
										});

									}
								}
							}
							// ------------------------------
						}
					} catch (e) {
						alert("js_ObjectStoreName:" + js_ObjectStoreName + ": " + e.message);
					}
				}
			}
		} catch (e) {
			alert("Creating Initial DB Structure:" + e.Message);
		}
	}
	// -----------------------------------------
}
// ---------------------------------------------------------------


// ---------------------------------------------------------------
function Synchronize_IndexedDB() {
	try {
		var transaction = null;
		var objectStore = null;
		var objectStore_Sync_Data = null;
		var transactionScope = [];

        _TX_Count = 0;

		if (js_IndexedDB_Definition.My_LocalObjectStores != null) {
			for (var k = 0; k < js_IndexedDB_Definition.My_LocalObjectStores.length; k++) {
				var js_Current_ObjectStore = js_IndexedDB_Definition.My_LocalObjectStores[k];
				if (js_Current_ObjectStore.My_LocalEntries != null) {
					transactionScope = [];
					if (js_Current_ObjectStore.Name == "TBL_SYNC_DATA") {
						continue;
					}
					transactionScope.push(js_Current_ObjectStore.Name);
					transactionScope.push("TBL_SYNC_DATA");

					transaction = db.transaction(transactionScope, "readwrite");
					objectStore = transaction.objectStore(js_Current_ObjectStore.Name);

					transaction.oncomplete = function (event) {
						//Notify("Transaction complete");
					};

					transaction.onerror = function (event) {
						//Notify(event.target.error.message);
					}

					if
					(
						(js_Current_ObjectStore.My_LocalEntries != null)) {

                        // -----------------
						Notify(js_Current_ObjectStore.Name + " : " + js_Current_ObjectStore.My_LocalEntries.length);
						// -----------------

                        // -----------------
                        _TX_Count = _TX_Count + js_Current_ObjectStore.My_LocalEntries.length;                        
                        // -----------------

                        for (var L = 0; L < js_Current_ObjectStore.My_LocalEntries.length; L++) {
                        
							// -----------------
							if
							(
								(js_Current_ObjectStore.My_LocalEntries[L] == null) ||
								(js_Current_ObjectStore.My_LocalEntries[L].My_Object == null)) {
								continue;
							}
							// -----------------

							// SURROGATE_ID
							// -----------------
							js_Current_ObjectStore.My_LocalEntries[L].My_Object["SURROGATE_ID"] = js_Current_ObjectStore.My_LocalEntries[L].SURROGATE_ID;
							// -----------------

							// ----------------------
							switch (js_Current_ObjectStore.My_LocalEntries[L].My_Local_Entry_Type) {
							case 0: // Add
								if (js_Current_ObjectStore.Name != "TBL_SETUP") {
									// TO ALLOW THE KEY GENERATOR TO WORK
									var js_PK_Field = js_Current_ObjectStore.Name.toUpperCase().replace("TBL_", "") + "_ID";
									delete js_Current_ObjectStore.My_LocalEntries[L].My_Object[js_PK_Field];
								}

								var request_Add = objectStore.add(js_Current_ObjectStore.My_LocalEntries[L].My_Object);
								request_Add.onsuccess = function (event) {
									//Notify("Success while Adding : " + JSON.stringify(js_Current_ObjectStore.My_LocalEntries[L].My_Object));
								};
								break;
							case 1: // Update
								Handle_IndexedDB_Update_Process(js_Current_ObjectStore, js_Current_ObjectStore.My_LocalEntries[L]);
								break;
							case 2: // Delete
								Handle_IndexedDB_Delete_Process(js_Current_ObjectStore, js_Current_ObjectStore.My_LocalEntries[L]);
								break;
							}
							// ----------------------

							// ----------------------
							if
							(
								(js_Current_ObjectStore.Name != "TBL_SYNC_DATA")) {
								// ------------
								objectStore_Sync_Data = transaction.objectStore("TBL_SYNC_DATA");
								// ------------

								// ------------
								var js_Sync_Data = new Object();
								js_Sync_Data.TABLE_NAME = js_Current_ObjectStore.Name;
								js_Sync_Data.LAST_AUDIT_ID = js_Current_ObjectStore.My_LocalEntries[L].LAST_AUDIT_ID;

								var request_Sync_Data = objectStore_Sync_Data.put(js_Sync_Data);

								request_Sync_Data.onsuccess = function (event) {
									//Notify("Success while updating TBL_SYNC_DATA");
								};

								request_Sync_Data.onerror = function (event) {
									//Notify("Error while updating TBL_SYNC_DATA");
								};
								// ------------
							}
							// ----------------------
						}
					}
				}
			}
		}

		// Fire PostEvent
		/* ----------------- */
		if (IndexedDB_Is_Call_Server_After_Local_Initialization == false) {
			if (onPostEvent_IndexedDB_RemoteDB != null) {
				onPostEvent_IndexedDB_RemoteDB(_TX_Count);
			}
		} else {
			if (onPostEvent_IndexedDB_LocalDB != null) {
				onPostEvent_IndexedDB_LocalDB();
			}
			Get_Local_IndexedDB
			(
				onPreEvent_IndexedDB,
				onPreEvent_IndexedDB_LocalDB,
				onPostEvent_IndexedDB_LocalDB,
				onPreEvent_IndexedDB_RemoteDB,
				onPostEvent_IndexedDB_RemoteDB,
				onPostEvent_IndexedDB_OfflineMode,
				js_Extra_LocalDB_Params_IndexedDB);
		}
		/* ----------------- */
	} catch (e) {
		alert("Synchronize_IndexedDB: " + e.message);
	}
}
// ---------------------------------------------------------------


// Sync_From_Scratch IndexedDB
// ---------------------------------------------------------------
function Sync_From_Scratch_IndexedDB(i_Table_Name, successHandler, errorHandler) {
	try {
	
	    // Normalize table name
		//------------------------------
		i_Table_Name = i_Table_Name.replace("[","");
		i_Table_Name = i_Table_Name.replace("]","");
		//------------------------------
	
		//------------------------------
		db = null;
		var databaseOptions = JSON.parse(localStorage.getItem("IndexedDB_DB_Info"));
		//------------------------------

		//------------------------------
		var transactionScope = [];
		transactionScope.push("TBL_SYNC_DATA");
		transactionScope.push(i_Table_Name);
		//------------------------------

		//------------------------------
		var req_Open = indexedDB.open(databaseOptions.fileName, databaseOptions.version);
		req_Open.onsuccess = function (event) {

            // ----------------------
			db = event.target.result;
			MyIndexedDB = db;
            transaction = db.transaction(transactionScope, "readwrite");
            // ----------------------

            // ----------------------
            transaction.oncomplete = function (event) {
				Notify("Transaction completed in Sync_From_Scratch_IndexedDB");
                
                 // Sync. this specific table.
                 /*----------------------*/
                 DB_Initializer
		         (
			        null, //MyPreEvent,
			        null, //MyPreEventLocalDB,
			        null, //MyPostEventLocalDB,
			        null, //MyPreEventRemoteDB,
			        function (iTxCount) {
			            console.log(i_Table_Name + " : iTxCount:" + iTxCount);
			            if (successHandler != null) { successHandler(); }
			        }, //MyPostEventRemoteDB,
			        null, //MyOfflineEvent,
			        My_Extra_LocalDB_Params
                 );
                 /*----------------------*/
                
			};

			transaction.onerror = function (event) {
			    Notify("Error in Transaction in Sync_From_Scratch_IndexedDB : " + event.target.error.message);
                if (errorHandler != null){errorHandler();}
			}
            // ----------------------
			
			
			// Delete all entries in i_Table_Name
			// ----------------------
			var objectStore_Table = transaction.objectStore(i_Table_Name);
			var objectStore_Table_Request = objectStore_Table.clear();
			objectStore_Table_Request.onsuccess = function(event) {	
				Notify("Success while clearing data in " + i_Table_Name);
			};
			objectStore_Table_Request.onerror = function(event) {						
				Notify("Error while clearing data in " + i_Table_Name);
			};
			// ----------------------

			// Reset the corresponding entry in [TBL_SYNC_DATA]
			// ----------------------
			var objectStore_Sync_Data = transaction.objectStore("TBL_SYNC_DATA");
			objectStore_Sync_Data.openCursor().onsuccess = function (ev) {
				var cursor = ev.target.result;
				if (cursor) {
					if (cursor.value.TABLE_NAME == i_Table_Name) {
						
						var js_Sync_Data = new Object();
						js_Sync_Data.TABLE_NAME = i_Table_Name;
						js_Sync_Data.LAST_AUDIT_ID = -1;
						
						var request_Update_Sync_Data = objectStore_Sync_Data.put(js_Sync_Data);
						request_Update_Sync_Data.onsuccess = function (event) {
							Notify('Success while reseting Sync. Data for ' + i_Table_Name);
						};
						request_Update_Sync_Data.onerror = function (event) {
							Notify('Error while reseting Sync. Data for ' + i_Table_Name + ' : '  + JSON.stringify(event));
						};
					}
					cursor.continue();
				}
			};
			// ----------------------
		};
		//------------------------------
	} catch (e) {
		alert("Sync_From_Scratch_IndexedDB: " + e.message);
	}
}
// ---------------------------------------------------------------


// ---------------------------------------------------------------
function Notify_Sync_Summary_IndexedDB() {
	try {
		Notify(JSON.stringify(js_Sync_Summary_IndexedDB));
	} catch (e) {
		Notify("Notify_Sync_Summary_IndexedDB:" + e.message);
	}
}
// ---------------------------------------------------------------
