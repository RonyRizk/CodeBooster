/* Members */
// -------------------------
var _APP_VERSION = 1;
// -------------------------

// -------------------------
function Collect_UUID(successHandler, errorHandler) {
    try {

        // ----------------
        if (successHandler == null) {return; }
        // ----------------
        
        // ----------------
        switch (window.device.platform) {
            case "Win32NT":
                successHandler(device.uuid);                
                break;
            default:
                try {
                    var success_uniqueDeviceID = function (uuid) {
                        successHandler(uuid);
                    }
                    var failure_uniqueDeviceID = function () {
                        successHandler(device.uuid);
                    }
                    window.plugins.uniqueDeviceID.get(success_uniqueDeviceID, failure_uniqueDeviceID);
                }
                catch (e) {                    
                    successHandler(device.uuid);
                }
                break;
        }
        // ----------------

    }
    catch (e) {
        Notify("Collect_UUID: " + e.Message);
        if (errorHandler != null) {errorHandler(); }
    }
}
// -------------------------

// -------------------------
function Prepare_Device_Object(i_uuid) {
    try {

        // ------------------------------
        var js_Device = new Object();
        js_Device.DEVICE_ID      = -1;
        js_Device.NAME           = (device.name != null ? device.name : '');
        js_Device.PHONEGAP       = 'PHONEGAP';
        js_Device.PLATFORM       = device.platform;
        js_Device.VERSION        = device.version;
        js_Device.PNS_TOKEN      = "";
        js_Device.DESCRIPTION    = "";
        js_Device.ENTRY_USER_ID  = 1;
        js_Device.ENTRY_DATE     = "2014-09-30";
        js_Device.OWNER_ID       = 1;
        js_Device.UUID           = i_uuid;
        js_Device.My_APP_VERSION = _APP_VERSION;
        // ------------------------------

        // ------------------------------            
        return js_Device;
        // ------------------------------
    }
    catch (e) {
        Notify("Prepare_Device_Object : " + e.Message);
    }
}
// -------------------------

// -------------------------
function Assure_Device_Registration(successHandler,failureHandler)
{
 try {

    // Check if this device is already registered.
	// ------------------
     var Get_Local_Device_data_By_DATA_KEY_Success = function (result) {
         if (result.length == 0) {
             Notify("Device Not registered");
             Register_Device(successHandler, failureHandler);
         }
         else {
             Notify("Device already registered: " + result[0].DATA_VALUE);
             if (successHandler != null) {
                 successHandler(result[0].DATA_VALUE);
             }
         }
     };
			
	var Get_Local_Device_data_By_DATA_KEY_Failure = function(){											
				Notify("Error while issuing Get_Local_Device_data_By_DATA_KEY_OWNER_ID");	
				if (failureHandler != null) {failureHandler();}
			};

	var Params_Get_Local_Device_data_By_DATA_KEY = new Object();	
	Params_Get_Local_Device_data_By_DATA_KEY.DATA_KEY = "DEVICE_ID"
	Get_Local_Device_data_By_DATA_KEY
	(
		Params_Get_Local_Device_data_By_DATA_KEY,	
		Get_Local_Device_data_By_DATA_KEY_Success,
		Get_Local_Device_data_By_DATA_KEY_Failure
	);
	// ------------------
 }
 catch(e)
 {
   Notify("Assure_Device_Registration:" + e.message);
 }
}
// -------------------------

// -------------------------
function Register_Device(successHandler,failureHandler)
{
		try {

		    var Collect_UUID_Success = function (result_uuid) {

		        // -------------------------
		        var js_Device = new Object();
		        js_Device = Prepare_Device_Object(result_uuid);
		        // -------------------------


		        // -------------------------        
		        _Service_Method = "Edit_Device";
		        _Params = JSON.stringify(js_Device);
		        Notify(_Params);

		        var Edit_Device_Completed = function (i_Srv_Response) {

		            // ------------------
		            var js_Device_data = new Object();
		            js_Device_data.DEVICE_DATA_ID = -1;
		            js_Device_data.DATA_KEY = "DEVICE_ID";
		            js_Device_data.DATA_VALUE = i_Srv_Response.My_Device.DEVICE_ID;
		            js_Device_data.ENTRY_USER_ID = 1;
		            js_Device_data.ENTRY_DATE = "2014-02-10";
		            js_Device_data.OWNER_ID = 1;



		            var Edit_Local_Device_data_Success = function (entity, editMode) {
		                Notify("DEVICE_ID: " + entity.DATA_VALUE);
		                if (successHandler != null) {
		                    successHandler(entity.DATA_VALUE);
		                }
		            };
		            var Edit_Local_Device_data_Failure = function () {
		                Notify("Error while creating entry in TBL_DEVICE_DATA")
		                if (failureHandler != null) { failureHandler(); }
		            };
		            Edit_Local_Device_data
				(
					js_Device_data,
					Edit_Local_Device_data_Success,
					Edit_Local_Device_data_Failure
				);
		            // ------------------

		        };

		        var Edit_Device_Failure = function () {
		            Notify("An Error has occured while issuing Edit_Device method");
		            if (failureHandler != null) { failureHandler(); }
		        };

		        CallService_Element(Edit_Device_Completed, Edit_Device_Failure, "Silent");
		        // -------------------------
		    }

		    Collect_UUID
            (
                Collect_UUID_Success, 
                null
            );
		}
		catch(e)
		{
		  Notify("Register_Device: " + e.message);
		}
}
// -------------------------