﻿// Update configuration to our liking
$(document).on("mobileinit", function () {

    $.mobile.defaultPageTransition = "slidefade";

    $.mobile.loader.prototype.options.text = "";
    $.mobile.loader.prototype.options.textVisible = false;
    $.mobile.loader.prototype.options.theme = "b";
    $.mobile.loader.prototype.options.textonly = false;
    $.mobile.loader.prototype.options.html = "";
    
    $.mobile.page.prototype.options.theme = "c";
    //$.mobile.page.prototype.options.contentTheme = "b";
    
    // We want popups to cover the page behind them with a dark background
    //$.mobile.popup.prototype.options.overlayTheme = "b";

    // Set a namespace for jQuery Mobile data attributes
    //$.mobile.ns = "jqm-";
});