﻿// ---------------------------------------------------------------
var _WCF_Base_Url = "http://localhost/GiveLifeMobi/AppWCF.svc";
var _Service_Method = "";
var _Params = "";
var _Ticket = "";
var _Content_Type = "application/json; charset=utf-8";
var _Type = "POST";
var _Data_Type = "json";
var _ProcessData = false;
var _LIST_ITEMS_PER_PAGE = 20;
var _UserInfo = "";
var _Async = true;
var Service_Call_InCompleted = "";
// ---------------------------------------------------------------

// ---------------------------------------------------------------
var Type = _Type;
var Url = "";
var ContentType = _Content_Type;
var DataType = _Data_Type;
var ProcessData = _ProcessData;
// ---------------------------------------------------------------


// ---------------------------------------------------------------
$(document).ready(function () {    
    /* -------------------------------------------------- */
    //if (!jq_FncCommon()) { return; };
    /* -------------------------------------------------- */
    
    // CHECK PAGE NAME //
    /* ----------------- */
    /*if (_pageUrl.indexOf('.aspx') != -1) {
    _pagename = _arr_pageUrl[_arr_pageUrl.length - 1].split('.')[0];
    _pagename = _pagename.toUpperCase();
    }*/
    /* ----------------- */

    /* --------------------------------------------------------------- */    
    // CHECK UserInfo //
    if (localStorage.getItem('UserInfo') != null) {
        _UserInfo = JSON.parse(localStorage.getItem('UserInfo'));
    }
    /* --------------------------------------------------------------- */
});
// ---------------------------------------------------------------

/* --------------------------------------------------------------- */
ko.bindingHandlers.jqmSelectEnable = {
    update: function (element, valueAccessor) {
        try {
            ko.bindingHandlers.enable.update(element, valueAccessor);
            var value = ko.utils.unwrapObservable(valueAccessor());
            $(element).selectmenu(value ? "enable" : "disable");
        }
        catch (e) { console.log(e.message); }
    }
};
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
ko.bindingHandlers.jqmButtonEnable = {
    update: function (element, valueAccessor) {
        try {
            ko.bindingHandlers.enable.update(element, valueAccessor);
            var value = ko.utils.unwrapObservable(valueAccessor());
            $(element).button(value ? "enable" : "disable"); //.button("refresh");
            if (value == true) {
                $(element).focus();
            }
        }
        catch (e) { console.log(e.message); }
    }
};
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
ko.bindingHandlers.jqmTextInputEnable = {
    update: function (element, valueAccessor) {
        try {
            ko.bindingHandlers.enable.update(element, valueAccessor);
            var value = ko.utils.unwrapObservable(valueAccessor());
            $(element).textinput(value ? "enable" : "disable").textinput('refresh');
            if (value == true) {
                $(element).focus();
            }
        }
        catch (e) { console.log(e.message); }
    }
};
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
ko.bindingHandlers.jqmCheckboxradioVisible = {
    update: function (element, valueAccessor) {
        try {
            ko.bindingHandlers.enable.update(element, valueAccessor);
            var value = ko.utils.unwrapObservable(valueAccessor());
            if (value == true) {
                $(element).closest("div.ui-radio").show();
            }
            else {                
                $(element).attr("checked", false).checkboxradio("refresh").closest("div.ui-radio").hide();
            }
        }
        catch (e) { console.log(e.message); }
    }
};
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
ko.bindingHandlers.jqmChecked = {
    update: function (element, valueAccessor) {
        try
        {
            var value = valueAccessor();
            var valueUnwrapped = ko.utils.unwrapObservable(value);
            //$(element).attr("checked", valueUnwrapped).checkboxradio("refresh");
            $(element).attr("checked", valueUnwrapped).flipswitch("refresh");
        }
        catch (e) {
            console.log(e.message);
        }
    }
};
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
ko.virtualElements.allowedBindings.jqmRefreshList = true;
ko.bindingHandlers.jqmRefreshList = {
    update: function (element, valueAccessor) {
        try {
            ko.utils.unwrapObservable(valueAccessor()); // make this update fire each time the array is updated.
            // locate the listview
            var listview = $(element).parents().andSelf().filter("[data-role='listview']");
            
            if (listview) {
                try {
                    $(listview).listview('refresh').enhanceWithin();
                }
                catch (e) { console.log(e.message); }
            }
        }
        catch (e) { console.log(e.message); }
    }
};
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
ko.virtualElements.allowedBindings.jqmRefreshControlGroup = true;
ko.bindingHandlers.jqmRefreshControlGroup = {
    update: function (element, valueAccessor, allBindings, viewModel, bindingContext) {
        try {
            ko.utils.unwrapObservable(valueAccessor());
            // locate the controlgroup
            var contrlgrp = $(element).parents().andSelf().filter("[data-role='controlgroup']");
            if (contrlgrp) {
                try {
                    $(contrlgrp).controlgroup("refresh").enhanceWithin();
                    //$(allBindings.get('forElement')).enhanceWithin().controlgroup("refresh");
                }
                catch (e) { console.log(e.message); }
            }
         }
        catch (e) { console.log(e.message); }                       
    }
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function sleep(milliseconds) {
    var start = new Date().getTime();
    for (var i = 0; i < 1e7; i++) {
        if ((new Date().getTime() - start) > milliseconds) {
            break;
        }
    }
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function jq_NavigateToPage(i_PageId, i_Options) {
    try {
        var currentPageId = $(":mobile-pagecontainer").pagecontainer("getActivePage")[0].id;
        if (currentPageId != i_PageId) {
            jq_ShowMobileLoader();
        }
        //$(":mobile-pagecontainer").pagecontainer("change", "#" + i_PageId/*, { role: "dialog" }*/);
        var func = function () {            
            if (i_Options != null) {
                $(":mobile-pagecontainer").pagecontainer("change", "#" + i_PageId, i_Options);
            }
            else {
                $(":mobile-pagecontainer").pagecontainer("change", "#" + i_PageId);
            }
        }
        setTimeout(func, 300);
    }
    catch (e) {
        alert("jq_NavigateToPage: " + e.message);
    }
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function jq_BlockUI(i_WithOverlay) {    
    if (i_WithOverlay) {
        $.blockUI({ css: {
            border: 'none',
            padding: '15px',
            backgroundColor: '#000',
            'border-radius': '10px',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: .6,
            color: '#fff'
        }, overlayCSS: { backgroundColor: 'transparent' }, message: '<img src="/css/images/ajax-loader.gif" alt="" />'
        });
    }
    else {
        $.blockUI({ css: {
            border: 'none',
            padding: '15px',
            backgroundColor: '#000',
            'border-radius': '10px',
            '-webkit-border-radius': '10px',
            '-moz-border-radius': '10px',
            opacity: .6,
            color: '#fff'
        }, overlayCSS: { backgroundColor: 'transparent' }, message: null /*'<img src="/images/ajax-loader.gif" />'*/
        });
    }
}

function jq_UnBlockUI() {
    try {
        $.unblockUI();
    }
    catch (e) {Notify("jq_UnBlockUI: " + e.message); }
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function jq_BlockElement(i_Elem_Obj) {
    //i_Elem_Obj.parent("div").block({ message: '<img src="images/element-loader.gif" alt="" />', overlayCSS: { backgroundColor: '#fe1a00', opacity: 1, 'border-radius': '5px', '-webkit-border-radius': '5px', '-moz-border-radius': '5px', '-moz-box-shadow': '0px 1px 7px 0px #c4c4c4', '-webkit-box-shadow': '0px 1px 7px 0px #c4c4c4', 'box-shadow': '0px 1px 7px 0px #c4c4c4', border: '1px solid #ffffff' }, css: { border: 'none', backgroundColor: 'transparent'} });
    i_Elem_Obj.parent("div").block({ message: '<img src="images/element-loader.gif" alt="" />', overlayCSS: { backgroundColor: '#000000', opacity: 1, '-webkit-border-radius': 'inherit', 'border-radius': 'inherit', border: '1px solid #ffffff' }, css: { border: 'none', backgroundColor: 'transparent'} });
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function jq_UnBlockElement(i_Elem_Obj) {
    i_Elem_Obj.parent("div").unblock();
}
/* --------------------------------------------------------------- */

// FOR MOBILE //
/////////////////////////////////////////////////////////////////////
/* --------------------------------------------------------------- */
function jq_ShowMobileLoader() {
    try {        
        $.mobile.loading("show");
    } catch (e) { }
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function jq_HideMobileLoader() {
    try {
        $.mobile.loading("hide");
    }
    catch (e) { }
}
/* --------------------------------------------------------------- */
/////////////////////////////////////////////////////////////////////

// CHECK INTERNET CONNECTION //
/* --------------------------------------------------------------- */
function jq_ConnectionExist() {
    try {        
        return navigator.onLine;
    }
    catch (e) {
        alert("jq_ConnectionExist: " + e.message);
    }
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
// parse a date in yyyy-mm-dd format
function jq_parseDate(i_dateString) { 
    try {
        var yyyymmdd = /^(\d){8}$/;     
        var yyyydashmmdashdd = /(\d{4})-(\d{2})-(\d{2})/;
        var mmslashddslashyyyy = /^((((0?[1-9]|[12]\d|3[01])[\.\-\/](0?[13578]|1[02])[\.\-\/]((1[6-9]|[2-9]\d)?\d{2}))|((0?[1-9]|[12]\d|30)[\.\-\/](0?[13456789]|1[012])[\.\-\/]((1[6-9]|[2-9]\d)?\d{2}))|((0?[1-9]|1\d|2[0-8])[\.\-\/]0?2[\.\-\/]((1[6-9]|[2-9]\d)?\d{2}))|(29[\.\-\/]0?2[\.\-\/]((1[6-9]|[2-9]\d)?(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)|00)))|(((0[1-9]|[12]\d|3[01])(0[13578]|1[02])((1[6-9]|[2-9]\d)?\d{2}))|((0[1-9]|[12]\d|30)(0[13456789]|1[012])((1[6-9]|[2-9]\d)?\d{2}))|((0[1-9]|1\d|2[0-8])02((1[6-9]|[2-9]\d)?\d{2}))|(2902((1[6-9]|[2-9]\d)?(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00)|00))))$/;
        // yyyymmdd
        if (yyyymmdd.test(i_dateString)) {
            var y = i_dateString.substr(0, 4),
            m = i_dateString.substr(4, 2) - 1,
            d = i_dateString.substr(6, 2);
            return new Date(y, m, d);
        }
        // yyyy-mm-dd
        else if (yyyydashmmdashdd.test(i_dateString)) {
            var parts = i_dateString.match(/(\d+)/g);
            // new Date(year, month [, date [, hours[, minutes[, seconds[, ms]]]]])    
            return new Date(parts[0], parts[1] - 1, parts[2]); // months are 0-based
        }
        else if (mmslashddslashyyyy.test(i_dateString)) {        
            var date = i_dateString.split(' ')[0];
            var parts = date.split('/');
            return new Date(parts[2], parts[0] - 1, parts[1]); // months are 0-based
        }
    }
    catch(e) {
        alert('jq_parseDate: ' + e.message);
    }
}
function jq_todayDate() {
    var d = new Date();
    var curr_date = d.getDate();
    var curr_month = d.getMonth(); //Months are zero based
    var curr_year = d.getFullYear();

    return new Date(curr_year, curr_month, curr_date); // months are 0-based
}
function jq_parsedTodayDate(format_pattern) {
    var d = new Date();
    var curr_date = d.getDate();
    var curr_month = d.getMonth(); //Months are zero based
    var curr_year = d.getFullYear();

    return jq_formatDate(curr_year + '-' + parseInt(curr_month + 1) + '-' + curr_date, format_pattern);
}
var _Month_Names = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
var _Day_Names = ['Su', 'M', 'T', 'W', 'Th', 'F', 'Sa'];
function jq_formatDate(dt, pattern) {
    var d = jq_parseDate(dt);
    var toRet = '';
    switch (pattern) {
        case 'd-M':
            toRet = d.getDate() + '-' + _Month_Names[d.getMonth()];
            break;
        case 'M d':
            toRet = _Month_Names[d.getMonth()] + ' ' + d.getDate();
            break;
        case 'd-M-y':
            toRet = d.getDate() + '-' + _Month_Names[d.getMonth()] + '-' + d.getFullYear();
            break;
        case 'm/d D':
            toRet = (d.getMonth() + 1) + '/' + d.getDate() + ' ' + _Day_Names[d.getDay()];
            break;
        case 'd/m D':
            toRet = d.getDate() + '/' + (d.getMonth() + 1) + ' ' + _Day_Names[d.getDay()];
            break;
        case 'y-m-d':
            toRet = d.getFullYear() + '-' + ((d.getMonth() + 1) < 10 ? '0' + (d.getMonth() + 1) : (d.getMonth() + 1)) + '-' + (d.getDate() < 10 ? '0' + d.getDate() : d.getDate());
            break;
        case 'ymd':
            toRet = d.getFullYear() + '' + ((d.getMonth() + 1) < 10 ? '0' + (d.getMonth() + 1) : (d.getMonth() + 1)) + '' + (d.getDate() < 10 ? '0' + d.getDate() : d.getDate());
            break;
    }
    return toRet;
}
function jq_getDayName(dt) {
    var d = jq_parseDate(dt);
    return _Day_Names[d.getDay()];
}
function jq_getDay(dt) {
    var d = new jq_parseDate(dt);
    return d.getDate();
}
function jq_dateDiff(date1, date2) {
    var date1 = jq_parseDate(date1);
    var date2 = jq_parseDate(date2);
    //Get 1 day in milliseconds
    var one_day = 1000 * 60 * 60 * 24;

    // Convert both dates to milliseconds
    var date1_ms = date1.getTime();
    var date2_ms = date2.getTime();

    // Calculate the difference in milliseconds
    var difference_ms = date2_ms - date1_ms;

    // Convert back to days and return
    return Math.round(difference_ms / one_day);
}
function js_timeDiff(time1, time2, diffType) {        // diffType = D, H, M, S
    var difference = time2 - time1;
 
    var daysDifference = Math.floor(difference/1000/60/60/24);
    difference -= daysDifference*1000*60*60*24
 
    var hoursDifference = Math.floor(difference/1000/60/60);
    difference -= hoursDifference*1000*60*60
 
    var minutesDifference = Math.floor(difference/1000/60);
    difference -= minutesDifference*1000*60
 
    var secondsDifference = Math.floor(difference/1000);
 
    switch(diffType) {
        case "D": 
            return daysDifference;
            break;
        case "H":
            return hoursDifference;
            break;
        case "M":
            return minutesDifference;
            break;
        case "S":
            return secondsDifference;
            break;
    } 
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function jq_formatMoney(amt) {
    //return parseFloat(Math.round(parseFloat(amt), 2)).toFixed(2);
    return parseFloat(amt).toFixed(2);
}
/* --------------------------------------------------------------- */

/******** QueryString parser ******/
function jq_parseQuery(query) {
    var Params = new Object();
    if (!query) return Params; // return empty object
    var Pairs = query.split(/[;&]/);
    for (var i = 0; i < Pairs.length; i++) {
        var KeyVal = Pairs[i].split('=');
        if (!KeyVal || KeyVal.length != 2) continue;
        var key = unescape(KeyVal[0]);
        var val = unescape(KeyVal[1]);
        val = val.replace(/\+/g, ' ');
        Params[key] = val;
    }
    return Params;
}
/******** /QueryString parser ******/

// ---------------------------------------------------------------
function js_Prepare_WCF_Url_For_Call() {
    try {
        var js_Return = "";

        if (_UserInfo != null) {
            _Ticket = _UserInfo.Ticket;            
        }
        else {
            _Ticket = "";
        }
        
        js_Return = _WCF_Base_Url + "/" + _Service_Method + "?" + "Ticket=" + _Ticket;
        return js_Return;
    }
    catch (e) {
        alert("js_Prepare_WCF_Url_For_Call");
    }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function CallService_Element(i_Success_Method, i_Failure_Method, i_Silent, i_Async) {

    // -----------------
    if (i_Async == null) {
        i_Async = true;
    }
    // -----------------

    $.ajax({
	beforeSend: function () { if (i_Silent == null) { jq_ShowMobileLoader(); jq_BlockUI(); } }, //Show spinner
        complete: function () { if (i_Silent == null) { jq_HideMobileLoader(); jq_UnBlockUI(); } }, //Hide spinner
        type: Type,
        url: js_Prepare_WCF_Url_For_Call(),
        data: _Params,
        contentType: ContentType,
        dataType: DataType,
        processdata: ProcessData,
        timeout: 20000,
        async: i_Async,
        success: function (i_Srv_Response) {
            if (i_Srv_Response.ExceptionMsg != '') {
                jq_DisplayMessage("MSG_GeneralError", "", i_Srv_Response.ExceptionMsg, null, i_Silent);
                if (i_Failure_Method)
                    i_Failure_Method(i_Srv_Response);
            }
            else {
                if (i_Success_Method) {
                    i_Success_Method(i_Srv_Response);
                }
            }
        },
        error: function (xhr, textStatus, errorThrown) {

            // ------------------
            jq_HideMobileLoader();
            jq_UnBlockUI();
            // ------------------

            //jq_DisplayMessage("MSG_GeneralError", "", "To continue, please connect your device to the internet.");
            //jq_DisplayMessage("MSG_GeneralError", "", textStatus + ' ' + errorThrown, null, i_Silent);
            if (i_Failure_Method)
                i_Failure_Method();
        }
    });
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function CallService(i_Service_Method, i_Silent) {
    try {                
        /* ----------------- */
        jq_BlockUI(1);
        /* ----------------- */

        $.ajax({
            type: Type,
            url: js_Prepare_WCF_Url_For_Call(),
            data: _Params,
            //data: "Input=" + encodeURIComponent(_Params),
            contentType: ContentType,
            dataType: DataType,
            processdata: ProcessData,
            async: _Async,
            success: function (i_Srv_Response) {
                if (i_Srv_Response.ExceptionMsg != '') {
                    $.unblockUI();
                    //jq_DisplayNotification(i_Srv_Response.ExceptionMsg, 'fail');
                    jq_DisplayMessage("MSG_GeneralError", "", i_Srv_Response.ExceptionMsg, null, i_Silent);
                    if (Service_Call_InCompleted)
                        Service_Call_InCompleted();
                    //alert(i_Srv_Response.ExceptionMsg);
                }
                else {
                    $.unblockUI();
                    if (i_Service_Method) {
                        js_ExecuteFunctionByName(i_Service_Method, window, i_Srv_Response);
                    }
                    else {
                        Service_Call_Completed(i_Srv_Response);
                    }
                    /*****************/                    
                    //setTimeout("jq_ResizeIframe();", 100);
                    /*****************/
                    //alert(_Service_Method);                
                }
            },
            error: ServiceFailed
        });
    }
    catch (e) {
        alert('CallService: ' + e.message);
    }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function ServiceFailed(xhr, textStatus, errorThrown) {
    try {
        $.unblockUI();

        jq_DisplayMessage("MSG_GeneralError", "WCF Error!", textStatus + '~' + errorThrown);
        //alert(xhr.My_Exception_Message);
        /*var js_response = xhr.responseText.replace(/[\r\n]/g, ' ').match(/<body.*>(.*)<\/body>/);
        js_response = js_response.toString().substring(js_response.toString().indexOf("request."), js_response.toString().indexOf("for more details"));
        js_response = js_response.trim();
        js_response = js_response.replace(_Service_Method, "");
        js_response = js_response.replace("request.", "");
        js_response = js_response.replace("request.", "for more details");
        js_response = js_response.replace("The exception message is ' : ", "");
        js_response = js_response.replace("See server logs", "");

        alert(js_response);*/

        //window.location.href = "/";

        return false;
    }
    catch (e) {
        alert("ServiceFailed: " + e.Message);
        return false;
    }

}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function js_ExecuteFunctionByName(functionName, context /*, args */) {
    try {
        var args = Array.prototype.slice.call(arguments).splice(2);
        var namespaces = functionName.split(".");
        var func = namespaces.pop();
        for (var i = 0; i < namespaces.length; i++) {
            context = context[namespaces[i]];
        }
        return context[func].apply(this, args);
    }
    catch (e) {
        alert('js_ExecuteFunctionByName: ' + e.message);
    }
}
//----------------------------------------------------------------

/* GET PARAM FROM QUERY STRING */
/* --------------------------------------------------------------- */
function jq_GetParameterByName(name) {
    try {
        name = name.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
        return results == null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    }
    catch (e) {        
    }
}
/* --------------------------------------------------------------- */

/* JQUERY UI CONFIRMATION MESSAGE */
/* --------------------------------------------------------------- */
function jq_ConfirmationMessage(i_Title, i_Msg, i_OK_Handler, i_CANCEL_Handler, i_FocusElemId) {
    try {
        var conf_Title = i_Title != '' ? i_Title : 'Confirmation';
        var conf_Msg = i_Msg;
        
        $("#popup_ConfDialog").find("#ConfDialog_Title").html(conf_Title);
        $("#popup_ConfDialog").find("#ConfDialog_Msg").html(conf_Msg);

        $("#ConfDialog_Btn_OK").removeClass("ui-btn-active");
        $("#ConfDialog_Btn_OK").off().on("click", function (e) {
            if (i_OK_Handler)
                i_OK_Handler();

            $("#popup_ConfDialog").popup('close');
            // Element to Focus after close //
            // -------------------------------
            if (i_FocusElemId) {
                var func = function () { $("#" + i_FocusElemId).focus(); }
                setTimeout(func, 100);
            }
            // -------------------------------
            e.preventDefault();
        });
        $("#ConfDialog_Btn_CANCEL").removeClass("ui-btn-active");
        $("#ConfDialog_Btn_CANCEL").off().on("click", function (e) {                        
            if (i_CANCEL_Handler)
                i_CANCEL_Handler();

            $("#popup_ConfDialog").popup('close');
            // Element to Focus after close //
            // -------------------------------
            if (i_FocusElemId) {
                var func = function () { $("#" + i_FocusElemId).focus(); }
                setTimeout(func, 100);
            }
            // -------------------------------
            e.preventDefault();
        });

        $("#popup_ConfDialog").popup('open', { transition: 'pop', positionTo: 'window' });
        var func = function () { $("#ConfDialog_Btn_OK").focus(); }
        setTimeout(func, 300);
    }
    catch (e) {
        alert("jq_ConfirmationMessage: " + e.Message);
    }
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function jq_DisplayMessage(i_Msg_Name, i_Title, i_Msg, i_FocusElemId, i_Silent) {
    try {

        alert(i_Msg);
        return;
        
        var disp_Title = i_Msg_Name == "MSG_GeneralError" && i_Title == "" ? "Oops!" : i_Title;
        var disp_Msg = i_Msg;

        $("#popup_DispDialog").find("#DispDialog_Title").html(disp_Title);
        $("#popup_DispDialog").find("#DispDialog_Msg").html(disp_Msg);

        $("#DispDialog_Btn_CLOSE").removeClass("ui-btn-active");
        $("#DispDialog_Btn_CLOSE").off().on("click", function (e) {
            $("#popup_DispDialog").popup('close');
            // Element to Focus after close //
            // -------------------------------
            if (i_FocusElemId) {
                var func = function () { $("#" + i_FocusElemId).focus(); }
                setTimeout(func, 100);
            }
            // -------------------------------
            e.preventDefault();
        });
                        
        if (i_Msg_Name) {
            switch (i_Msg_Name) {
                case "MSG_GeneralError":
                    if (!$("#popup_DispDialog div[role='banner']").hasClass("frbgred")) {
                        //$("#DispDialog_Icon").removeClass("ui-icon-info").addClass("ui-icon-alert");
                        $("#popup_DispDialog div[role='banner']").removeClass("frbgblue").addClass("frbgred");
                    }
                    break;
                case "MSG_GeneralInfo":
                    if (!$("#popup_DispDialog div[role='banner']").hasClass("frbgblue")) {
                        //$("#DispDialog_Icon").removeClass("ui-icon-alert").addClass("ui-icon-info");
                        $("#popup_DispDialog div[role='banner']").removeClass("frbgred").addClass("frbgblue");
                    }
                    break;
            }
        }
        $("#popup_DispDialog").popup('open', { transition: 'flip', positionTo: 'window' });
        var func = function () { $("#DispDialog_Btn_CLOSE").focus(); }
        setTimeout(func, 300);
    }
    catch (e) {
        alert("jq_DisplayMessage: " + e.Message);
    }
}
/* --------------------------------------------------------------- */


/* --------------------------------------------------------------- */
String.prototype.format = function (args) {
    var str = this;
    return str.replace(String.prototype.format.regex, function (item) {
        var intVal = parseInt(item.substring(1, item.length - 1));
        var replace;
        if (intVal >= 0) {
            replace = args[intVal];
        } else if (intVal === -1) {
            replace = "{";
        } else if (intVal === -2) {
            replace = "}";
        } else {
            replace = "";
        }
        return replace;
    });
};
String.prototype.format.regex = new RegExp("{-?[0-9]+}", "g");
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
$.validator.setDefaults({
    highlight: function (input) {
        /* add code for default*/
        if (!$(input).is("select")) {
            $(input).addClass("input_error");
        }
    },
    unhighlight: function (input) {
        /* add code for default*/
        $(input).removeClass("input_error");
    },
    errorPlacement: function (error, element) {
        if (element.is("textarea")) {
            error.insertAfter(element);
        }
        else if (element.is(':radio') || element.is(':checkbox')) {
            error.insertAfter($(element).closest("fieldset"));
        }
        else {
            error.insertAfter($(element).parent());
        }
        /*if (element.is("select")) {
        error.insertAfter($(element).parent());
        } 
        else {
        error.insertAfter(element);
        }*/
    }
});
/* --------------------------------------------------------------- */

// ---------------------------------------------------------------
function Notify(i_Msg) {
    try {
        console.log(i_Msg);
        //alert(i_Msg);
    }
    catch (e) { }
}
// ---------------------------------------------------------------

