﻿function Assure_Latest_App_Version(successHandler, failureHandler) {
    try {

        // ---------------
        var js_Local_Version = "";
        var js_UUID = "";
        // ---------------

        // ---------------
        var Collect_UUID_Success = function (i_uuid) {

            // ---------------
            js_UUID = i_uuid;
            // ---------------

            // ---------------
            cordova.getAppVersion(function (version) {

                // ----------
                js_Local_Version = version;
                // ----------

                // ----------
                var Params_Get_App_Latest_Version = new Object();
                Params_Get_App_Latest_Version.LOCAL_VERSION = version;
                Params_Get_App_Latest_Version.UUID = js_UUID;

                var Get_App_Latest_Version_Completed = function (result) {

                    if (result.My_Result != js_Local_Version) {

                        // -------
                        //alert("You have to upgrade");
                        // -------

                        // -------
                        window.localStorage.clear();
                        // -------

                        // -------
                        //jq_BlockUI();
                        // -------
                    }
                    else {
                        if (successHandler != null) { successHandler(); }
                    }
                }

                var Get_App_Latest_Version_Failure = function () {
                    alert("Not able to get Latest Version from Server");
                    if (failureHandler != null) { failureHandler(); }
                }

                _Params = JSON.stringify(Params_Get_App_Latest_Version);
                _Service_Method = "Get_App_Latest_Version";
                CallService_Element(Get_App_Latest_Version_Completed, Get_App_Latest_Version_Failure);
                // ----------

            });
            // ---------------
        }
        // ---------------

        // ---------------
        Collect_UUID(Collect_UUID_Success,null);
        // ---------------

        
    }
    catch (e) {
        alert("Assure_Latest_App_Version:" + e.message);
    }
}