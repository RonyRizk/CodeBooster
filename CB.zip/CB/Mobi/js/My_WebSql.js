﻿//------------------------------
var _TX_Count = -1;
//------------------------------

// Pre/Post Events
//------------------------------
var onPreEvent_WebSql          = null;

var onPreEvent_WebSql_LocalDB  = null;
var onPostEvent_WebSql_LocalDB = null;

var onPreEvent_WebSql_RemoteDB = null;
var onPostEvent_WebSql_RemoteDB = null;

var onPostEvent_WebSql_OfflineMode = null;
//------------------------------

//------------------------------
var WebSqlDB = null;
var js_WebSqlDB_Definition = null;			
var js_WebSqlDBName    = "";			
var js_WebSqlDBVersion = 1;			
var js_DBSize          = 1 * 1024 * 1024;
var js_Sync_Summary_WebSqlDB = "";
var js_Extra_LocalDB_Params_WebSql = null;
var WebSql_Is_Call_Server_After_Local_Initialization = false;
//------------------------------

//------------------------------
var js_List_Of_OFFLINE_OPERATIONS = [];
//------------------------------


//------------------------------
function Get_WebSqlDB_Handler(successHandler, failureHandler) {
    try {

        //------------------------------
        if (localStorage.getItem("WebSQL_DB_Initial_Data_Populated") != null) {
            if (localStorage.getItem("WebSQL_DB_Info") != null) {

                //------------------------------
                var databaseOptions = JSON.parse(localStorage.getItem("WebSQL_DB_Info"));
                //------------------------------

                // Open Database
                //------------------------------
                WebSqlDB = openDatabase
                    (
		             databaseOptions.fileName,
		             databaseOptions.version,
		             databaseOptions.displayName,
		             databaseOptions.maxSize
	                );
                //------------------------------

                //------------------------------
                if (successHandler != null) { successHandler(); }
                //------------------------------
            }
        }
        //------------------------------
    }
    catch (e) {

        //------------------------------
        if (failureHandler != null) { failureHandler(); }
        //------------------------------

        //------------------------------
        alert("Get_WebSqlDB_Handler:" + e.Message);
        //------------------------------
    }
}
//------------------------------

//------------------------------
function Get_Local_WebSqlDB
        (
            preFunction,
            preFunctionLocalDB,
            postFunctionLocalDB,
            preFunctionServerDB,
            postFunctionServerDB,
            offlineFunction, 
            i_Extra_LocalDB_Params
        )
{
    try {

        
       
	    /* ----------------- */
        onPreEvent_WebSql = preFunction;
        onPreEvent_WebSql_LocalDB        = preFunctionLocalDB;
        onPostEvent_WebSql_LocalDB       = postFunctionLocalDB;
        onPreEvent_WebSql_RemoteDB       = preFunctionServerDB;
		onPostEvent_WebSql_RemoteDB      = postFunctionServerDB;
		onPostEvent_WebSql_OfflineMode   = offlineFunction;
		js_Extra_LocalDB_Params_WebSql   = i_Extra_LocalDB_Params;		
		/* ----------------- */
		
		// Fire PreEvent
		/* ----------------- */
		if (onPreEvent_WebSql != null) {
		    onPreEvent_WebSql();
		}
		/* ----------------- */
		
		// Initial Data to be applied
		/* ----------------- */
		if (localStorage.getItem("WebSQL_DB_Initial_Data_Populated") == null) {
		  if (onPreEvent_WebSql_LocalDB != null) { onPreEvent_WebSql_LocalDB(); } 

		  WebSql_Is_Call_Server_After_Local_Initialization = true;
		  Populate_Initial_WebSql_Data();		 
		  return;
		}
		else {
		    if (onPreEvent_WebSql_RemoteDB != null) {

		        if (localStorage.getItem("WebSQL_DB_Info") != null) {

		            //------------------------------
		            var databaseOptions = JSON.parse(localStorage.getItem("WebSQL_DB_Info"));
		            //------------------------------

		            // Open Database
		            //------------------------------
		            WebSqlDB = openDatabase
                    (
		                databaseOptions.fileName,
		                databaseOptions.version,
		                databaseOptions.displayName,
		                databaseOptions.maxSize
	                );
		            //------------------------------

		            //------------------------------
		            onPreEvent_WebSql_RemoteDB();
		            //------------------------------  

		            //------------------------------  
		            WebSql_Is_Call_Server_After_Local_Initialization = false;
		            //------------------------------  
		        }      
            }
		}
	    /* ----------------- */
	
	    /* ----------------- */
		if (localStorage.getItem("WebSQL_DB_Info") == null) {
		    
			/* ----------------- */
			var Params_Get_LocalDB = new Object();
			Params_Get_LocalDB.LocalDB_Type            = 1;
			Params_Get_LocalDB.My_Sync_data            = [];
			Params_Get_LocalDB.My_Extra_LocalDB_Params = js_Extra_LocalDB_Params_WebSql;

			_Params = JSON.stringify(Params_Get_LocalDB);			
			_Service_Method = "Get_LocalDB";
			CallService_Element(Get_Local_WebSqlDB_Completed, Get_Local_WebSqlDB_Failure,"Silent");
			/* ----------------- */
		}
		else
		{		   
			Prepare_WebSql_Sync_Data();
		}
		/* ----------------- */
    }
    catch (e) {
        Notify("Get_Local_WebSqlDB: " + e.Message);
    }
}
//------------------------------

//------------------------------
function Populate_Initial_WebSql_Data()
{
  try
  {
   

    /* ----------------- */
    var js_InitialData = new Object();
    js_InitialData.My_Result = null;
    js_InitialData.My_Result = JSON.stringify(js_MyData_WebDB);
    localStorage.setItem("WebSQL_DB_Initial_Data_Populated", true);
    Get_Local_WebSqlDB_Completed(js_InitialData);
    /* ----------------- */

		
  }
  catch(e)
  {
    localStorage.removeItem("WebSQL_DB_Initial_Data_Populated");
    Notify("Populate_Initial_WebSql_Data: " + e.message);
  }
}
//------------------------------


// Prepare_WebSql_Sync_Data
//------------------------------
function Prepare_WebSql_Sync_Data()
{
 try
 {		
	//------------------------------
	var databaseOptions = JSON.parse(localStorage.getItem("WebSQL_DB_Info"));
    //------------------------------
 
	// Open Database
	//------------------------------
	WebSqlDB = openDatabase(
		databaseOptions.fileName,
		databaseOptions.version,
		databaseOptions.displayName,
		databaseOptions.maxSize
	);
	//------------------------------
		
	//------------------------------
	WebSqlDB.transaction(function (tx) {
	    tx.executeSql
					(
						"SELECT * FROM [TBL_SYNC_DATA]",
						[],
						function (tx, results) {

						    // --------------------------			
						    var Params_Get_LocalDB = new Object();
						    Params_Get_LocalDB.LocalDB_Type = 1;
						    Params_Get_LocalDB.My_Sync_data = [];
						    Params_Get_LocalDB.My_Extra_LocalDB_Params = js_Extra_LocalDB_Params_WebSql;
						    // --------------------------

						    // --------------------------
						    for (var i = 0; i < results.rows.length; i++) {

						        row = results.rows.item(i);

						        // To Support Exclusive Tables to Sync.
						        // ------------
						        if ((_Exclusive_Tables_To_Sync != null) && (_Exclusive_Tables_To_Sync.length > 0)) {						            
						            if ($.inArray(row.TABLE_NAME, _Exclusive_Tables_To_Sync) < 0) {
						                continue;
						            }
						        }
						        // ------------

						        // ------------
						        var js_Sync_data = new Object();
						        js_Sync_data.TABLE_NAME = row.TABLE_NAME;
						        js_Sync_data.LAST_AUDIT_ID = row.LAST_AUDIT_ID;
						        Params_Get_LocalDB.My_Sync_data.push(js_Sync_data);
						        // ------------
						    }
						    // ---------------------------

						    // ---------------------------							
						    _Params = JSON.stringify(Params_Get_LocalDB);
						    _Service_Method = "Get_LocalDB";
						    CallService_Element(Get_Local_WebSqlDB_Completed, Get_Local_WebSqlDB_Failure_OfflineMode, "Silent");
						    // ---------------------------
						},
						 function (tx, sqlError) {
						     Notify("An Error has occured while issuing SELECT * FROM [TBL_SYNC_DATA] statement ");
						     Notify(JSON.stringify(sqlError));
						 }
					);
	});
	// ---------------------
 }
 catch(e)
 {
   Notify("Prepare_WebSql_Sync_Data: " + e.Message);
 }
}
//------------------------------


//------------------------------
function Get_Local_WebSqlDB_Failure(i_Input) {
    try {
        // Notify("An Error has occured while calling Get_LocalDB");		
		Notify("An Error has occured while calling Get_LocalDB");
    }
    catch (e) {
        Notify("Get_Local_WebSqlDB_Failure: " + e.Message);
    }
}
//------------------------------


//------------------------------
function Get_Local_WebSqlDB_Failure_OfflineMode(i_Input) {
    try {
        Notify("Get_LocalDB : Working in Offline Mode");        

		if (onPostEvent_WebSql_OfflineMode != null){
            onPostEvent_WebSql_OfflineMode();
        }
		
        if (onPostEvent_WebSql_LocalDB != null) {
		    onPostEvent_WebSql_LocalDB();
		}

		if (onPostEvent_WebSql_RemoteDB != null) {
		    onPostEvent_WebSql_RemoteDB();
		}
    }
    catch (e) {
        Notify("Get_Local_WebSqlDB_Failure: " + e.Message);
    }
}
//------------------------------


//------------------------------
function Get_Local_WebSqlDB_Completed(i_Input) {
    try 
    {   
		//------------------------------		
		js_WebSqlDB_Definition 		= JSON.parse(i_Input.My_Result);			
		js_WebSqlDBName        		= js_WebSqlDB_Definition.Name;			
		js_WebSqlDBVersion     		= js_WebSqlDB_Definition.Version;	
		js_DBSize	           		= js_WebSqlDB_Definition.Size;
		js_Sync_Summary_WebSqlDB 	= js_WebSqlDB_Definition.My_Sync_Summary;
		//------------------------------
		
		// Prepare Database options
        //------------------------------
        var databaseOptions = {
            fileName: js_WebSqlDBName,
            version: js_WebSqlDBVersion,
            displayName: js_WebSqlDBName,
            maxSize: js_DBSize
        };
        //------------------------------
		
		// Open Database
        //------------------------------
        WebSqlDB = openDatabase(
            databaseOptions.fileName,
            databaseOptions.version,
            databaseOptions.displayName,
            databaseOptions.maxSize
        );
        //------------------------------
		
		// Drop DB in case the name sent from server is different than the local one.
		//------------------------------		
		if (localStorage.getItem("WebSQL_DB_Info") != null)
		{		  
		  var js_LocalDB_Info = JSON.parse(localStorage.getItem("WebSQL_DB_Info"));			  		  
		  if (js_LocalDB_Info.fileName != js_WebSqlDB_Definition.Name) {		      
		      localStorage.removeItem("WebSQL_DB_Info");
		      Get_Local_WebSqlDB
                (
                    onPreEvent_WebSql,
                    onPreEvent_WebSql_LocalDB,
                    onPostEvent_WebSql_LocalDB,
                    onPreEvent_WebSql_RemoteDB,
                    onPostEvent_WebSql_RemoteDB,
                    onPostEvent_WebSql_OfflineMode, 
                    js_Extra_LocalDB_Params_WebSql
                );
			 return;
		  }
		}
		//------------------------------		
		
	
		//------------------------------
		localStorage.setItem("WebSQL_DB_Info", JSON.stringify(databaseOptions))			
	    //------------------------------
	
		//------------------------------			
        Drop_Triggers(js_WebSqlDB_Definition);         
		//------------------------------		
    }
    catch (e) {
        Notify("Get_Local_WebSqlDB_Completed: " + e.Message);
    }
}
//------------------------------



// Drop Triggers if exist (To avoid creating audit entries while getting data from the server)
// --------------------------------------------------
function Drop_Triggers(i_Input) {

    // -------------------------------
    var js_Statement = "";
    var js_DDL_Operations = ["016"]; // Drop Trigger
    // -------------------------------

    // -------------------------------
    WebSqlDB.transaction(function (tx) {
        for (var i = 0; i < i_Input.My_Offline_operation.length; i++) {
            if
                (
                    $.inArray(i_Input.My_Offline_operation[i].OFFLINE_OPERATION_TYPE_CODE, js_DDL_Operations) != -1
                ) {
                js_Statement = i_Input.My_Offline_operation[i].STATEMENT;
                tx.executeSql
                (
                    js_Statement,
                    [],
                        function (tx, resultSet) {
                            //Notify("Success : " + js_Statement)
                        },
                    function (tx, sqlError) {
                        Notify("[A3] : " + js_Statement);
                        Notify(JSON.stringify(sqlError));
                        return true;  // rollback                        
                    }
                );
            }
        }
    },
    function () {
        Notify("Failure with Drop_Triggers");         
    },
    function () {
        Notify("Success with Drop_Triggers");
        Create_Required_Tables(i_Input);
    }    
    );
    // -------------------------------
}
// --------------------------------------------------



// Create required Tables
// --------------------------------------------------           
function Create_Required_Tables(i_Input) {

    // -------------------------------
    var js_Statement = "";
    var js_DDL_Operations = [
                                        "001", // Create table
                                        "002", // Alter  table
                                        "003", // Drop   table
                                        "007", // Create Index
                                        "008", // Alter  Index
                                        "009"
                                    ];
    // -------------------------------


    // -------------------------------
    WebSqlDB.transaction(function (tx) {
        for (var i = 0; i < i_Input.My_Offline_operation.length; i++) {
            if
                    (
                        $.inArray(i_Input.My_Offline_operation[i].OFFLINE_OPERATION_TYPE_CODE, js_DDL_Operations) != -1
                    ) {
                js_Statement = i_Input.My_Offline_operation[i].STATEMENT;								
                tx.executeSql
                        (
                            js_Statement,
                            [],
                             function (tx, resultSet) {
                                 //Notify("Success : " + js_Statement)
                             },
                            function (tx, sqlError) {
                                Notify("[A1] : " + js_Statement);
                                Notify(JSON.stringify(sqlError));                                
                                return true;  // rollback
                            }
                        );
            }
        }
    },
    function () {
        Notify("Failure with Create_Required_Tables");
    },
    function () {
        Notify("Success with Create_Required_Tables");
        Delete_Offline_Entries(i_Input);
    }
    );
    // -------------------------------
}
// --------------------------------------------------           


// Delete existing entries in TBL_OFFLINE_OPERATION
// --------------------------------------------------
function Delete_Offline_Entries(i_Input) {
    var js_Statement = "";
    WebSqlDB.transaction(function (tx) {
        js_Statement = "DELETE FROM [TBL_OFFLINE_OPERATION]";
        tx.executeSql
                        (
                            js_Statement,
                            [],
                             function (tx, resultSet) {
                                 //Notify("Success : " + js_Statement)
                             },
                            function (tx, sqlError) {
                                Notify("[A2] : " + js_Statement);
                                Notify(JSON.stringify(sqlError));
                                return true;  // rollback
                            }
                        );
    },
    function () {
        Notify("Failure with Delete_Offline_Entries");        
    },
    function () {
        Notify("Success with Delete_Offline_Entries");        
        Create_Entries_in_TBL_OFFLINE_OPERATION(i_Input);
    }    
    );
}
// --------------------------------------------------


// Create entries in TBL_OFFLINE_OPERATION
// --------------------------------------------------
function Create_Entries_in_TBL_OFFLINE_OPERATION(i_Input) {
    var js_Statement = "";
    WebSqlDB.transaction(function (tx) {
        for (var i = 0; i < i_Input.My_Offline_operation.length; i++) {
            js_List_Of_OFFLINE_OPERATIONS.push(i_Input.My_Offline_operation[i]);

            js_Statement = 'INSERT INTO [TBL_OFFLINE_OPERATION] ([OFFLINE_OPERATION_ID],[TABLE_NAME], [OFFLINE_OPERATION_TYPE_CODE],[STATEMENT])  VALUES  (  NULL,  ?,  ?,  ?);'
            tx.executeSql
                (
                    js_Statement,
                    [
                        i_Input.My_Offline_operation[i].TABLE_NAME,
                        i_Input.My_Offline_operation[i].OFFLINE_OPERATION_TYPE_CODE,
                        i_Input.My_Offline_operation[i].STATEMENT
                    ],
                    function (tx, resultSet) {
                        //Notify("Success : " + js_Statement)
                    },
                    function (tx, sqlError) {
                        Notify("An error has occured while issuing : " + i_Input.My_Offline_operation[i].STATEMENT);
                        Notify(JSON.stringify(sqlError));
                        return true;  // rollback
                    }
                );
        }
    },
    function () {
        Notify("Failure Create_Entries_in_TBL_OFFLINE_OPERATION");        
    },
     function () {
         Notify("Success with Create_Entries_in_TBL_OFFLINE_OPERATION");         
         Create_Triggers(i_Input);
     }    
    );
}
// --------------------------------------------------



// Create Triggers
// --------------------------------------------------
function Create_Triggers(i_Input) {
    
    // -----------------
    var js_Statement = "";
    var js_DDL_Operations = ["014"]; // Create Trigger
    // -----------------
        
    WebSqlDB.transaction(function (tx) {
        for (var i = 0; i < js_List_Of_OFFLINE_OPERATIONS.length; i++) {
            if
                (
                    $.inArray(js_List_Of_OFFLINE_OPERATIONS[i].OFFLINE_OPERATION_TYPE_CODE, js_DDL_Operations) != -1
                ) {
                js_Statement = js_List_Of_OFFLINE_OPERATIONS[i].STATEMENT;
                Notify(js_Statement);
                tx.executeSql
                    (
                        js_Statement,
                        [],
                            function (tx, resultSet) {
                                //Notify("Success : " + js_Statement)
                            },
                        function (tx, sqlError) {
                            Notify("[A4] : " + js_Statement);
                            Notify(JSON.stringify(sqlError));
                            return true;  // rollback
                        }
                    );
            }
        }
    },
    function () {
        Notify("Failure with Create_Triggers");        
    },
    function () {
        Notify("Success with Create_Triggers");        
        Assure_Sync_Data_Rows_Existence(i_Input);
    }    
    );
}
// --------------------------------------------------


// Assure_Sync_Data_Rows_Existence
// --------------------------------------------------
function Assure_Sync_Data_Rows_Existence(i_Input) {

    WebSqlDB.transaction(function (tx) {
        for (var i = 0; i < i_Input.My_Offline_operation.length; i++) {
            if ((i_Input.My_Offline_operation[i].OFFLINE_OPERATION_TYPE_CODE == "010")) {
                tx.executeSql(i_Input.My_Offline_operation[i].STATEMENT);
            }
        }
    },
     function () {
         Notify("Failure with Assure_Sync_Data_Rows_Existence");         
     },
     function () {
         Notify("Success with Assure_Sync_Data_Rows_Existence");         
         Synchronize_webSqlDB(i_Input);
     }
    );
}
// --------------------------------------------------



// Synchronize WebSqlDB
// --------------------------------------------------
function Synchronize_webSqlDB(i_Input) {
    var js_Statement = "";
	var js_Offline_TX = null;
	WebSqlDB.transaction(function (tx) {

        // ----------------
	    _TX_Count = 0;
	    if (i_Input.My_Offline_Transaction != null) {
	        _TX_Count = i_Input.My_Offline_Transaction.length;
	        //console.log("_TX_Count:" + _TX_Count);
	    }
	    // ----------------

	    for (var i = 0; i < i_Input.My_Offline_Transaction.length; i++) {

	        js_Offline_TX = i_Input.My_Offline_Transaction[i];
	        js_Statement = js_Offline_TX.STATEMENT;

	        tx.executeSql
                            (
                                js_Statement,
                                [],
                                 function (tx, resultSet) {
                                 },
                                function (tx, sqlError) {
                                    Notify(js_Statement);
                                    Notify("Error while issuing : " + js_Statement);
                                    Notify(JSON.stringify(sqlError));
                                    return true;  // rollback
                                }
                            );

	        //js_Statement = "UPDATE [TBL_SYNC_DATA] SET [LAST_AUDIT_ID] = ? WHERE [TABLE_NAME] = ?";										 
	        tx.executeSql
					  (
						  "UPDATE [TBL_SYNC_DATA] SET [LAST_AUDIT_ID] = ? WHERE [TABLE_NAME] = ?",
						  [js_Offline_TX.LAST_AUDIT_ID, js_Offline_TX.TABLE_NAME],
						  function (tx, resultSet) {
						      //Notify("Success")
						  },
						  function (tx, sqlError) {
						      Notify("UPDATE [TBL_SYNC_DATA] SET [LAST_AUDIT_ID] = ? WHERE [TABLE_NAME] = ?");
						      Notify(JSON.stringify(sqlError));
						      return true;  // rollback
						  }
					  );

	    }
	},
    function (error) {
        alert(JSON.stringify(error));
        Notify("Failure with Synchronize_webSqlDB");
    },
     function () {

         /*----------------------*/
         Notify("Success with Synchronize_webSqlDB");
         /*----------------------*/



         // Fire PostEvent
         /* ----------------- */
         if (WebSql_Is_Call_Server_After_Local_Initialization == false) {
             if (onPostEvent_WebSql_RemoteDB != null) {
                 onPostEvent_WebSql_RemoteDB(_TX_Count);
             }
         }
         else {
             if (onPostEvent_WebSql_LocalDB != null) {
                 onPostEvent_WebSql_LocalDB();
             }
             Get_Local_WebSqlDB
             (
                onPreEvent_WebSql,
                onPreEvent_WebSql_LocalDB,
                onPostEvent_WebSql_LocalDB,
                onPreEvent_WebSql_RemoteDB,
                onPostEvent_WebSql_RemoteDB,
                onPostEvent_WebSql_OfflineMode,
                js_Extra_LocalDB_Params_WebSql
             );
         }
         /* ----------------- */
     }
    );
}
// --------------------------------------------------


// Sync_From_Scratch WebSqlDB
// --------------------------------------------------
function Sync_From_Scratch_WebSqlDB(i_Table_Name,successHandler,errorHandler) {
    var js_Statement = "";

    WebSqlDB.transaction(function (tx) {

        // Delete all entries in i_Table_Name
        // ------------
        js_Statement = "DELETE FROM " + i_Table_Name;
        tx.executeSql
                            (
                                js_Statement,
                                [],
                                 function (tx, resultSet) {
                                 },
                                function (tx, sqlError) {
                                    Notify(js_Statement);
                                    Notify("Error while issuing : " + js_Statement);
                                    Notify(JSON.stringify(sqlError));
                                    return true;  // rollback
                                }
                            );
        // ------------

        // Reset the corresponding entry in [TBL_SYNC_DATA]
        // ------------        								 
        tx.executeSql
					  (
						  "UPDATE [TBL_SYNC_DATA] SET [LAST_AUDIT_ID] = -1 WHERE [TABLE_NAME] = ?",
						  [i_Table_Name],
						  function (tx, resultSet) {
						      //Notify("Success")
						  },
						  function (tx, sqlError) {
						      Notify("UPDATE [TBL_SYNC_DATA] SET [LAST_AUDIT_ID] = -1 WHERE [TABLE_NAME] = ?");
						      Notify(JSON.stringify(sqlError));
						      return true;  // rollback
						  }
					  );
        // ------------
    },
    function (error) {

        /*----------------------*/
        alert(JSON.stringify(error));
        Notify("Failure with Sync_From_Scratch_WebSqlDB");
        /*----------------------*/


        /*----------------------*/
        if (errorHandler != null) {
            errorHandler();
        }
        /*----------------------*/
    },
     function () {
     
         /*----------------------*/
         Notify("Success with Sync_From_Scratch_WebSqlDB");
         /*----------------------*/

         // Make it exclusive the table in question.
         /*----------------------*/
         _Exclusive_Tables_To_Sync = [];
         _Exclusive_Tables_To_Sync.push(i_Table_Name);
         /*----------------------*/

         // Sync. this specific table.
         /*----------------------*/
         DB_Initializer
		 (
			null, //MyPreEvent,
			null, //MyPreEventLocalDB,
			null, //MyPostEventLocalDB,
			null, //MyPreEventRemoteDB,
			function (iTxCount) {
			    console.log(i_Table_Name + " : iTxCount:" + iTxCount);
			    if (successHandler != null) { successHandler(); }
			}, //MyPostEventRemoteDB,
			null, //MyOfflineEvent,
			My_Extra_LocalDB_Params
         );
         /*----------------------*/

     }
    );
}
// --------------------------------------------------



// --------------------------------------------------
function Notify_Sync_Summary_WebSqlDB()
{
  try
  {
     Notify(JSON.stringify(js_Sync_Summary_WebSqlDB));
  }
  catch(e)
  {
    Notify("Notify_Sync_Summary_WebSqlDB:" + e.message);
  }
}
// --------------------------------------------------