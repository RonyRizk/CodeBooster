﻿
// Global Application View Model //
/***********************************/
var MyApp_VM = {
    PLATFORM            : ko.observable(""),
    SETUP_ENTRIES       : ko.mapping.fromJS([])
};
/***********************************/

/***********************************/
var My_Extra_LocalDB_Params = [];
/***********************************/

/***********************************/
MyApp_VM.Get_All_Setup_Entries = function () {
    try {

        // ---------------
        ko.mapping.fromJS([], MyApp_VM.SETUP_ENTRIES);
        // ---------------

        // ---------------
        var Params_Get_Local_Setup_By_OWNER_ID = new Object();
        Params_Get_Local_Setup_By_OWNER_ID.OWNER_ID = 1;

        var Get_Local_Setup_By_OWNER_ID_Success = function (result) {
            if (result != null) {

                for (var i = 0; i < result.length; i++) {
                    MyApp_VM.SETUP_ENTRIES.push(ko.mapping.fromJS(result[i]));                    
                }
            }
        }

        Get_Local_Setup_By_OWNER_ID
        (
            Params_Get_Local_Setup_By_OWNER_ID,
            Get_Local_Setup_By_OWNER_ID_Success,
            null
        );
        // ---------------

    }
    catch (e) {
        Notify("Get_All_Setup_Entries : " + e.Message);
    }
}
/***********************************/


/***********************************/
MyApp_VM.Menu_Handler = function (menu) {
    jq_NavigateToPage(menu.LINK());
}
/***********************************/





/***********************************/
MyApp_VM.Get_Startup_Data = function () {  
    MyApp_VM.Get_All_Setup_Entries();
}
/***********************************/


/***********************************/
MyApp_VM.Resolve_Setup_Entry = function (TBL_NAME, CODE_NAME, LANGUAGE_CODE) {    
    var js_Return_Value = "";
    var js_SetupEntry =
                    ko.utils.arrayFirst(MyApp_VM.SETUP_ENTRIES(), function (setupentry) {
                        return ((setupentry.TBL_NAME() == TBL_NAME) && (setupentry.CODE_NAME() == CODE_NAME));
                    });

    if (js_SetupEntry != null) {
        js_Return_Value = js_SetupEntry.CODE_VALUE_EN;
    }
    return js_Return_Value;


}
/***********************************/

/***********************************/
var MyPreEvent = function () {
    Notify("Pre");
}
/***********************************/


/***********************************/
var MyOfflineEvent = function () {
    _Is_Offline_Mode = true;
    Notify("You are working in offline mode");
}
/***********************************/


/***********************************/
var MyPreEventLocalDB = function () {
    Notify("MyPreEventLocalDB event fired");
};
/***********************************/


/***********************************/
var MyPostEventLocalDB = function () {

};
/***********************************/


/***********************************/
var MyPreEventRemoteDB = function () {
};
/***********************************/


/***********************************/
var MyPostEventRemoteDB = function () {

    // ---------------
    Notify("MyPostEventRemoteDB event fired");
    // ---------------

    // ---------------
    jq_HideMobileLoader();
    jq_UnBlockUI();
    // ---------------

    // Hide the splash screen
    // ------------------------
    try {
        navigator.splashscreen.hide();
    }
    catch (e) {
        Notify("navigator.splashscreen.hide has thrown an error");
    }
    // ------------------------
    
    // ------------------------
    MyApp_VM.Get_Startup_Data();
    // ------------------------  


    // Assure_Device_Registration_Success
    // ------------------------
    var Assure_Device_Registration_Success = function (i_DEVICE_ID) {
    
    };
    // ------------------------

    // Assure_Device_Registration_Failure
    // ------------------------
    var Assure_Device_Registration_Failure = function () { Notify("Error while calling Assure_Device_Registration"); };
    // ------------------------

    // Assure_Device_Registration
    // ------------------------
    if (_Is_Offline_Mode == false) {
        Assure_Device_Registration
						(
							Assure_Device_Registration_Success,
							Assure_Device_Registration_Failure
						);
    }
    // ------------------------                                       
};
/***********************************/


/***********************************/
MyApp_VM.Sync_DB = function () {
    try {

        var Collect_UUID_Success = function (result_uuid) {
            // ---------------
            var Extra_LocalDB_Param = new Object();
            Extra_LocalDB_Param.PARAM_NAME = "DEVICE";
            Extra_LocalDB_Param.PARAM_VALUE = JSON.stringify(Prepare_Device_Object(result_uuid));
            My_Extra_LocalDB_Params.push(Extra_LocalDB_Param);


            DB_Initializer(MyPreEvent, MyPreEventLocalDB, MyPostEventLocalDB, MyPreEventRemoteDB, MyPostEventRemoteDB, MyOfflineEvent, My_Extra_LocalDB_Params);
            // ---------------

        }

        // ---------------
        Collect_UUID(Collect_UUID_Success, null);
        // ---------------

    }
    catch (e) {
        Notify("Sync_DB: " + e.Message);
    }
}
/***********************************/


// Document Ready //
/*****************************************************/
$(document).ready(function () {


    document.addEventListener("deviceready", onDeviceReady, false);

    // #####################################################
    function onDeviceReady() {
        try {

                    
            return;

            // ---------------            
            jq_ShowMobileLoader();
            jq_BlockUI();
            // ---------------

            // ---------------
            //MyApp_VM.Sync_DB();
            // ---------------           


            // Check if platform = iOS & Version >= 7.0 to apply top margin //
            // Check if platform = Win32NT(wp8) to Hide Status Bar //
            // -------------------------
            try {
                // Set Global PLATFORM 
                // ---------------------
                MyApp_VM.PLATFORM(window.device.platform);
                // ---------------------
                if (window.device.platform == "iOS" && parseFloat(window.device.version) >= 7.0) {
                    StatusBar.overlaysWebView(false);
                    StatusBar.show();
                }
                else if (window.device.platform == "Win32NT") {
                    StatusBar.hide();
                }
            }
            catch (e) { Notify(e.message); }
            // -------------------------
        }
        catch (e) { Notify('Deviceready: ' + e.message); }
    }
    // #####################################################



    // Change defaults //
    /***********************************/
    // EXTERNAL TOOLBARS //
    ////////////////////////////////////////////////////////////////
    $("div[data-role='popup']").enhanceWithin().popup();
    $("div[data-role='panel']").enhanceWithin().panel();
    ////////////////////////////////////////////////////////////////    
    /***********************************/


    // FastClick Init //
    /***********************************/
    FastClick.attach(document.body);
    /***********************************/

    // Knockout Binding //
    /***********************************/
    ko.applyBindings(MyApp_VM);
    /***********************************/

    // Global events for App //
    /***********************************/
    //// ORIENTATION CHANGE ////    
    /////////////////////////////////////////////////////////////////////////
    $(window).on("orientationchange", function (event) {
        $.mobile.resetActivePageHeight();
    });
    /////////////////////////////////////////////////////////////////////////    



});
/*****************************************************/

// "pagecontainercreate" centralized event for all pages in the App //
/*****************************************************/
$(document).on("pagecontainercreate", function (event, ui) {
    $(".ActionTheme").attr("data-theme", "b");
});
/*****************************************************/

// "pagecontainerbeforeshow" centralized event for all pages in the App //
/*****************************************************/
$(document).on("pagecontainerbeforeshow", function (event, ui) {
    // No Disc Icon //
    $("div.ui-btn, a.ui-btn").addClass("ui-nodisc-icon");
});
/*****************************************************/

// "pagecontainerbeforetransition" centralized event for all pages in the App //
/*****************************************************/
$(document).on("pagecontainerbeforetransition", function (event, ui) {
    var pg_id = ui.toPage[0].id;

    var page = $("#" + pg_id);
    page.css("-webkit-backface-visibility", "hidden");
    //$.mobile.changePage("#somepage", {transition: "slide"});
    setTimeout(function () { page.css("-webkit-backface-visibility", "visible"); }, 450);
     
});
/*****************************************************/

