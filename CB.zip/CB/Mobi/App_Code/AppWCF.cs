using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.IO;
using System.Web.Hosting;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;
using System.Web.Script.Serialization;
using System.Net;
using BLC;
[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public partial class AppWCF
{
#region Members
#endregion
#region Extract_Ticket
private string Extract_Ticket()
{
#region Declaration And Initialization Section.
string str_Ticket = string.Empty;
#endregion
#region Body Section.
// --------------------
var oIncomingMessageProperties = OperationContext.Current.IncomingMessageProperties;
if (oIncomingMessageProperties != null)
{
var oHttpRequestMessageProperty = oIncomingMessageProperties[HttpRequestMessageProperty.Name] as HttpRequestMessageProperty;
if (oHttpRequestMessageProperty != null)
{
string str_QueryString = oHttpRequestMessageProperty.QueryString;
if (string.IsNullOrEmpty(str_QueryString) == false)
{
string[] oQueryString_Parts = str_QueryString.Split(new char[] { '&' });
if
(
(oQueryString_Parts != null) &&
(oQueryString_Parts.Count() > 0)
)
{
foreach(var oRow_QueryString_Part in oQueryString_Parts)
{
if (oRow_QueryString_Part.ToUpper().StartsWith("TICKET") == true)
{
string[] oTicket_Parts  = oRow_QueryString_Part.Split(new char[] {'='});
if
(
(oTicket_Parts != null) &&
(oTicket_Parts.Count() > 0)
)
{
str_Ticket = oTicket_Parts[1].ToString();
str_Ticket = str_Ticket + "=";
}
}
}
}
}
}
}
// --------------------
#endregion
#region Return Section.
return str_Ticket;
#endregion
}
#endregion
#region IsValidWebTicket
private bool IsValidWebTicket(string i_Input)
{
#region Declaration And Initialization Section.
bool Is_Valid = false;
BLCInitializer oBLCInitializer = new BLCInitializer();
#endregion
#region Body Section.
BLC.BLC oBLC_Default = new BLC.BLC();
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
Is_Valid = oBLC.IsValidTicket(i_Input);
}
#endregion
#region Return Section.
return Is_Valid;
#endregion
}
#endregion
#region Delete_Academic_year
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_Academic_year Delete_Academic_year(Params_Delete_Academic_year i_Params_Delete_Academic_year)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_Academic_year oResult_Delete_Academic_year = new Result_Delete_Academic_year();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_Academic_year(i_Params_Delete_Academic_year);
oResult_Delete_Academic_year.My_Params_Delete_Academic_year = i_Params_Delete_Academic_year;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_Academic_year.ExceptionMsg = string.Format("Delete_Academic_year : {0}", ex.Message);
}
else
{
oResult_Delete_Academic_year.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_Academic_year;
#endregion
}
#endregion
#region Delete_Attendance
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_Attendance Delete_Attendance(Params_Delete_Attendance i_Params_Delete_Attendance)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_Attendance oResult_Delete_Attendance = new Result_Delete_Attendance();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_Attendance(i_Params_Delete_Attendance);
oResult_Delete_Attendance.My_Params_Delete_Attendance = i_Params_Delete_Attendance;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_Attendance.ExceptionMsg = string.Format("Delete_Attendance : {0}", ex.Message);
}
else
{
oResult_Delete_Attendance.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_Attendance;
#endregion
}
#endregion
#region Delete_Document
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_Document Delete_Document(Params_Delete_Document i_Params_Delete_Document)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_Document oResult_Delete_Document = new Result_Delete_Document();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_Document(i_Params_Delete_Document);
oResult_Delete_Document.My_Params_Delete_Document = i_Params_Delete_Document;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_Document.ExceptionMsg = string.Format("Delete_Document : {0}", ex.Message);
}
else
{
oResult_Delete_Document.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_Document;
#endregion
}
#endregion
#region Delete_Enrollment
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_Enrollment Delete_Enrollment(Params_Delete_Enrollment i_Params_Delete_Enrollment)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_Enrollment oResult_Delete_Enrollment = new Result_Delete_Enrollment();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_Enrollment(i_Params_Delete_Enrollment);
oResult_Delete_Enrollment.My_Params_Delete_Enrollment = i_Params_Delete_Enrollment;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_Enrollment.ExceptionMsg = string.Format("Delete_Enrollment : {0}", ex.Message);
}
else
{
oResult_Delete_Enrollment.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_Enrollment;
#endregion
}
#endregion
#region Delete_Group
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_Group Delete_Group(Params_Delete_Group i_Params_Delete_Group)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_Group oResult_Delete_Group = new Result_Delete_Group();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_Group(i_Params_Delete_Group);
oResult_Delete_Group.My_Params_Delete_Group = i_Params_Delete_Group;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_Group.ExceptionMsg = string.Format("Delete_Group : {0}", ex.Message);
}
else
{
oResult_Delete_Group.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_Group;
#endregion
}
#endregion
#region Delete_Kg
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_Kg Delete_Kg(Params_Delete_Kg i_Params_Delete_Kg)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_Kg oResult_Delete_Kg = new Result_Delete_Kg();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_Kg(i_Params_Delete_Kg);
oResult_Delete_Kg.My_Params_Delete_Kg = i_Params_Delete_Kg;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_Kg.ExceptionMsg = string.Format("Delete_Kg : {0}", ex.Message);
}
else
{
oResult_Delete_Kg.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_Kg;
#endregion
}
#endregion
#region Delete_Kitchen
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_Kitchen Delete_Kitchen(Params_Delete_Kitchen i_Params_Delete_Kitchen)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_Kitchen oResult_Delete_Kitchen = new Result_Delete_Kitchen();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_Kitchen(i_Params_Delete_Kitchen);
oResult_Delete_Kitchen.My_Params_Delete_Kitchen = i_Params_Delete_Kitchen;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_Kitchen.ExceptionMsg = string.Format("Delete_Kitchen : {0}", ex.Message);
}
else
{
oResult_Delete_Kitchen.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_Kitchen;
#endregion
}
#endregion
#region Delete_Notification
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_Notification Delete_Notification(Params_Delete_Notification i_Params_Delete_Notification)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_Notification oResult_Delete_Notification = new Result_Delete_Notification();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_Notification(i_Params_Delete_Notification);
oResult_Delete_Notification.My_Params_Delete_Notification = i_Params_Delete_Notification;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_Notification.ExceptionMsg = string.Format("Delete_Notification : {0}", ex.Message);
}
else
{
oResult_Delete_Notification.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_Notification;
#endregion
}
#endregion
#region Delete_Student
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_Student Delete_Student(Params_Delete_Student i_Params_Delete_Student)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_Student oResult_Delete_Student = new Result_Delete_Student();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_Student(i_Params_Delete_Student);
oResult_Delete_Student.My_Params_Delete_Student = i_Params_Delete_Student;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_Student.ExceptionMsg = string.Format("Delete_Student : {0}", ex.Message);
}
else
{
oResult_Delete_Student.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_Student;
#endregion
}
#endregion
#region Delete_User
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_User Delete_User(Params_Delete_User i_Params_Delete_User)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_User oResult_Delete_User = new Result_Delete_User();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_User(i_Params_Delete_User);
oResult_Delete_User.My_Params_Delete_User = i_Params_Delete_User;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_User.ExceptionMsg = string.Format("Delete_User : {0}", ex.Message);
}
else
{
oResult_Delete_User.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_User;
#endregion
}
#endregion
#region Delete_User_group
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_User_group Delete_User_group(Params_Delete_User_group i_Params_Delete_User_group)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_User_group oResult_Delete_User_group = new Result_Delete_User_group();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_User_group(i_Params_Delete_User_group);
oResult_Delete_User_group.My_Params_Delete_User_group = i_Params_Delete_User_group;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_User_group.ExceptionMsg = string.Format("Delete_User_group : {0}", ex.Message);
}
else
{
oResult_Delete_User_group.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_User_group;
#endregion
}
#endregion
#region Delete_User_menu
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Delete_User_menu Delete_User_menu(Params_Delete_User_menu i_Params_Delete_User_menu)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Delete_User_menu oResult_Delete_User_menu = new Result_Delete_User_menu();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Delete_User_menu(i_Params_Delete_User_menu);
oResult_Delete_User_menu.My_Params_Delete_User_menu = i_Params_Delete_User_menu;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Delete_User_menu.ExceptionMsg = string.Format("Delete_User_menu : {0}", ex.Message);
}
else
{
oResult_Delete_User_menu.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Delete_User_menu;
#endregion
}
#endregion
#region Download_Offline_Transations
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Download_Offline_Transations Download_Offline_Transations(Params_Download_Offline_Transations i_Params_Download_Offline_Transations)
{
#region Declaration And Initialization Section.
List<Offline_Transaction>  oReturnValue = new List<Offline_Transaction> ();
string i_Ticket = string.Empty;
Result_Download_Offline_Transations oResult_Download_Offline_Transations = new Result_Download_Offline_Transations();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Download_Offline_Transations(i_Params_Download_Offline_Transations);
oResult_Download_Offline_Transations.My_Result = oReturnValue;
oResult_Download_Offline_Transations.My_Params_Download_Offline_Transations = i_Params_Download_Offline_Transations;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Download_Offline_Transations.ExceptionMsg = string.Format("Download_Offline_Transations : {0}", ex.Message);
}
else
{
oResult_Download_Offline_Transations.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Download_Offline_Transations;
#endregion
}
#endregion
#region Edit_Academic_year
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Academic_year Edit_Academic_year(Academic_year i_Academic_year)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Academic_year oResult_Edit_Academic_year = new Result_Edit_Academic_year();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Academic_year(i_Academic_year);
oResult_Edit_Academic_year.My_Academic_year = i_Academic_year;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Academic_year.ExceptionMsg = string.Format("Edit_Academic_year : {0}", ex.Message);
}
else
{
oResult_Edit_Academic_year.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Academic_year;
#endregion
}
#endregion
#region Edit_Attendance
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Attendance Edit_Attendance(Attendance i_Attendance)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Attendance oResult_Edit_Attendance = new Result_Edit_Attendance();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Attendance(i_Attendance);
oResult_Edit_Attendance.My_Attendance = i_Attendance;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Attendance.ExceptionMsg = string.Format("Edit_Attendance : {0}", ex.Message);
}
else
{
oResult_Edit_Attendance.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Attendance;
#endregion
}
#endregion
#region Edit_Device
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Device Edit_Device(Device i_Device)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Device oResult_Edit_Device = new Result_Edit_Device();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Device(i_Device);
oResult_Edit_Device.My_Device = i_Device;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Device.ExceptionMsg = string.Format("Edit_Device : {0}", ex.Message);
}
else
{
oResult_Edit_Device.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Device;
#endregion
}
#endregion
#region Edit_Device_contact
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Device_contact Edit_Device_contact(Device_contact i_Device_contact)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Device_contact oResult_Edit_Device_contact = new Result_Edit_Device_contact();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Device_contact(i_Device_contact);
oResult_Edit_Device_contact.My_Device_contact = i_Device_contact;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Device_contact.ExceptionMsg = string.Format("Edit_Device_contact : {0}", ex.Message);
}
else
{
oResult_Edit_Device_contact.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Device_contact;
#endregion
}
#endregion
#region Edit_Document
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Document Edit_Document(Document i_Document)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Document oResult_Edit_Document = new Result_Edit_Document();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Document(i_Document);
oResult_Edit_Document.My_Document = i_Document;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Document.ExceptionMsg = string.Format("Edit_Document : {0}", ex.Message);
}
else
{
oResult_Edit_Document.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Document;
#endregion
}
#endregion
#region Edit_Enrollment
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Enrollment Edit_Enrollment(Enrollment i_Enrollment)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Enrollment oResult_Edit_Enrollment = new Result_Edit_Enrollment();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Enrollment(i_Enrollment);
oResult_Edit_Enrollment.My_Enrollment = i_Enrollment;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Enrollment.ExceptionMsg = string.Format("Edit_Enrollment : {0}", ex.Message);
}
else
{
oResult_Edit_Enrollment.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Enrollment;
#endregion
}
#endregion
#region Edit_Group
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Group Edit_Group(Group i_Group)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Group oResult_Edit_Group = new Result_Edit_Group();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Group(i_Group);
oResult_Edit_Group.My_Group = i_Group;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Group.ExceptionMsg = string.Format("Edit_Group : {0}", ex.Message);
}
else
{
oResult_Edit_Group.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Group;
#endregion
}
#endregion
#region Edit_Kg
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Kg Edit_Kg(Kg i_Kg)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Kg oResult_Edit_Kg = new Result_Edit_Kg();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Kg(i_Kg);
oResult_Edit_Kg.My_Kg = i_Kg;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Kg.ExceptionMsg = string.Format("Edit_Kg : {0}", ex.Message);
}
else
{
oResult_Edit_Kg.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Kg;
#endregion
}
#endregion
#region Edit_Kitchen
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Kitchen Edit_Kitchen(Kitchen i_Kitchen)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Kitchen oResult_Edit_Kitchen = new Result_Edit_Kitchen();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Kitchen(i_Kitchen);
oResult_Edit_Kitchen.My_Kitchen = i_Kitchen;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Kitchen.ExceptionMsg = string.Format("Edit_Kitchen : {0}", ex.Message);
}
else
{
oResult_Edit_Kitchen.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Kitchen;
#endregion
}
#endregion
#region Edit_Notification
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Notification Edit_Notification(Notification i_Notification)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Notification oResult_Edit_Notification = new Result_Edit_Notification();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Notification(i_Notification);
oResult_Edit_Notification.My_Notification = i_Notification;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Notification.ExceptionMsg = string.Format("Edit_Notification : {0}", ex.Message);
}
else
{
oResult_Edit_Notification.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Notification;
#endregion
}
#endregion
#region Edit_Setup
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Setup Edit_Setup(SetupEntry i_SetupEntry)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Setup oResult_Edit_Setup = new Result_Edit_Setup();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Setup(i_SetupEntry);
oResult_Edit_Setup.My_SetupEntry = i_SetupEntry;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Setup.ExceptionMsg = string.Format("Edit_Setup : {0}", ex.Message);
}
else
{
oResult_Edit_Setup.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Setup;
#endregion
}
#endregion
#region Edit_Student
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_Student Edit_Student(Student i_Student)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_Student oResult_Edit_Student = new Result_Edit_Student();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_Student(i_Student);
oResult_Edit_Student.My_Student = i_Student;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_Student.ExceptionMsg = string.Format("Edit_Student : {0}", ex.Message);
}
else
{
oResult_Edit_Student.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_Student;
#endregion
}
#endregion
#region Edit_User
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_User Edit_User(User i_User)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_User oResult_Edit_User = new Result_Edit_User();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_User(i_User);
oResult_Edit_User.My_User = i_User;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_User.ExceptionMsg = string.Format("Edit_User : {0}", ex.Message);
}
else
{
oResult_Edit_User.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_User;
#endregion
}
#endregion
#region Edit_User_group
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_User_group Edit_User_group(User_group i_User_group)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_User_group oResult_Edit_User_group = new Result_Edit_User_group();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_User_group(i_User_group);
oResult_Edit_User_group.My_User_group = i_User_group;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_User_group.ExceptionMsg = string.Format("Edit_User_group : {0}", ex.Message);
}
else
{
oResult_Edit_User_group.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_User_group;
#endregion
}
#endregion
#region Edit_User_menu
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Edit_User_menu Edit_User_menu(User_menu i_User_menu)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Edit_User_menu oResult_Edit_User_menu = new Result_Edit_User_menu();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Edit_User_menu(i_User_menu);
oResult_Edit_User_menu.My_User_menu = i_User_menu;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Edit_User_menu.ExceptionMsg = string.Format("Edit_User_menu : {0}", ex.Message);
}
else
{
oResult_Edit_User_menu.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Edit_User_menu;
#endregion
}
#endregion
#region EditSetup
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_EditSetup EditSetup(SetupEntry i_SetupEntry)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_EditSetup oResult_EditSetup = new Result_EditSetup();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.EditSetup(i_SetupEntry);
oResult_EditSetup.My_SetupEntry = i_SetupEntry;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_EditSetup.ExceptionMsg = string.Format("EditSetup : {0}", ex.Message);
}
else
{
oResult_EditSetup.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_EditSetup;
#endregion
}
#endregion
#region Forgot_Password
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Forgot_Password Forgot_Password(Params_Forgot_Password i_Params_Forgot_Password)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Forgot_Password oResult_Forgot_Password = new Result_Forgot_Password();
#endregion
#region Body Section.
try
{


BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Forgot_Password(i_Params_Forgot_Password);
oResult_Forgot_Password.My_Params_Forgot_Password = i_Params_Forgot_Password;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Forgot_Password.ExceptionMsg = string.Format("Forgot_Password : {0}", ex.Message);
}
else
{
oResult_Forgot_Password.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Forgot_Password;
#endregion
}
#endregion
#region Get_Academic_year_By_Criteria_InList
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Academic_year_By_Criteria_InList Get_Academic_year_By_Criteria_InList(Params_Get_Academic_year_By_Criteria_InList i_Params_Get_Academic_year_By_Criteria_InList)
{
#region Declaration And Initialization Section.
List<Academic_year>  oReturnValue = new List<Academic_year> ();
string i_Ticket = string.Empty;
Result_Get_Academic_year_By_Criteria_InList oResult_Get_Academic_year_By_Criteria_InList = new Result_Get_Academic_year_By_Criteria_InList();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Academic_year_By_Criteria_InList(i_Params_Get_Academic_year_By_Criteria_InList);
oResult_Get_Academic_year_By_Criteria_InList.My_Result = oReturnValue;
oResult_Get_Academic_year_By_Criteria_InList.My_Params_Get_Academic_year_By_Criteria_InList = i_Params_Get_Academic_year_By_Criteria_InList;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Academic_year_By_Criteria_InList.ExceptionMsg = string.Format("Get_Academic_year_By_Criteria_InList : {0}", ex.Message);
}
else
{
oResult_Get_Academic_year_By_Criteria_InList.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Academic_year_By_Criteria_InList;
#endregion
}
#endregion
#region Get_Academic_year_By_OWNER_ID
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Academic_year_By_OWNER_ID Get_Academic_year_By_OWNER_ID(Params_Get_Academic_year_By_OWNER_ID i_Params_Get_Academic_year_By_OWNER_ID)
{
#region Declaration And Initialization Section.
List<Academic_year>  oReturnValue = new List<Academic_year> ();
string i_Ticket = string.Empty;
Result_Get_Academic_year_By_OWNER_ID oResult_Get_Academic_year_By_OWNER_ID = new Result_Get_Academic_year_By_OWNER_ID();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Academic_year_By_OWNER_ID(i_Params_Get_Academic_year_By_OWNER_ID);
oResult_Get_Academic_year_By_OWNER_ID.My_Result = oReturnValue;
oResult_Get_Academic_year_By_OWNER_ID.My_Params_Get_Academic_year_By_OWNER_ID = i_Params_Get_Academic_year_By_OWNER_ID;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Academic_year_By_OWNER_ID.ExceptionMsg = string.Format("Get_Academic_year_By_OWNER_ID : {0}", ex.Message);
}
else
{
oResult_Get_Academic_year_By_OWNER_ID.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Academic_year_By_OWNER_ID;
#endregion
}
#endregion
#region Get_Attendance_By_ENROLLMENT_ID
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Attendance_By_ENROLLMENT_ID Get_Attendance_By_ENROLLMENT_ID(Params_Get_Attendance_By_ENROLLMENT_ID i_Params_Get_Attendance_By_ENROLLMENT_ID)
{
#region Declaration And Initialization Section.
List<Attendance>  oReturnValue = new List<Attendance> ();
string i_Ticket = string.Empty;
Result_Get_Attendance_By_ENROLLMENT_ID oResult_Get_Attendance_By_ENROLLMENT_ID = new Result_Get_Attendance_By_ENROLLMENT_ID();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Attendance_By_ENROLLMENT_ID(i_Params_Get_Attendance_By_ENROLLMENT_ID);
oResult_Get_Attendance_By_ENROLLMENT_ID.My_Result = oReturnValue;
oResult_Get_Attendance_By_ENROLLMENT_ID.My_Params_Get_Attendance_By_ENROLLMENT_ID = i_Params_Get_Attendance_By_ENROLLMENT_ID;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Attendance_By_ENROLLMENT_ID.ExceptionMsg = string.Format("Get_Attendance_By_ENROLLMENT_ID : {0}", ex.Message);
}
else
{
oResult_Get_Attendance_By_ENROLLMENT_ID.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Attendance_By_ENROLLMENT_ID;
#endregion
}
#endregion
#region Get_Distinct_Setup_Tables
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Distinct_Setup_Tables Get_Distinct_Setup_Tables(Params_Get_Distinct_Setup_Tables i_Params_Get_Distinct_Setup_Tables)
{
#region Declaration And Initialization Section.
List<SetupEntry>  oReturnValue = new List<SetupEntry> ();
string i_Ticket = string.Empty;
Result_Get_Distinct_Setup_Tables oResult_Get_Distinct_Setup_Tables = new Result_Get_Distinct_Setup_Tables();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Distinct_Setup_Tables(i_Params_Get_Distinct_Setup_Tables);
oResult_Get_Distinct_Setup_Tables.My_Result = oReturnValue;
oResult_Get_Distinct_Setup_Tables.My_Params_Get_Distinct_Setup_Tables = i_Params_Get_Distinct_Setup_Tables;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Distinct_Setup_Tables.ExceptionMsg = string.Format("Get_Distinct_Setup_Tables : {0}", ex.Message);
}
else
{
oResult_Get_Distinct_Setup_Tables.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Distinct_Setup_Tables;
#endregion
}
#endregion
#region Get_Document_By_REL_KEY_REL_ENTITY
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Document_By_REL_KEY_REL_ENTITY Get_Document_By_REL_KEY_REL_ENTITY(Params_Get_Document_By_REL_KEY_REL_ENTITY i_Params_Get_Document_By_REL_KEY_REL_ENTITY)
{
#region Declaration And Initialization Section.
List<Document>  oReturnValue = new List<Document> ();
string i_Ticket = string.Empty;
Result_Get_Document_By_REL_KEY_REL_ENTITY oResult_Get_Document_By_REL_KEY_REL_ENTITY = new Result_Get_Document_By_REL_KEY_REL_ENTITY();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Document_By_REL_KEY_REL_ENTITY(i_Params_Get_Document_By_REL_KEY_REL_ENTITY);
oResult_Get_Document_By_REL_KEY_REL_ENTITY.My_Result = oReturnValue;
oResult_Get_Document_By_REL_KEY_REL_ENTITY.My_Params_Get_Document_By_REL_KEY_REL_ENTITY = i_Params_Get_Document_By_REL_KEY_REL_ENTITY;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Document_By_REL_KEY_REL_ENTITY.ExceptionMsg = string.Format("Get_Document_By_REL_KEY_REL_ENTITY : {0}", ex.Message);
}
else
{
oResult_Get_Document_By_REL_KEY_REL_ENTITY.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Document_By_REL_KEY_REL_ENTITY;
#endregion
}
#endregion
#region Get_Enrollment_By_Criteria_InList
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Enrollment_By_Criteria_InList Get_Enrollment_By_Criteria_InList(Params_Get_Enrollment_By_Criteria_InList i_Params_Get_Enrollment_By_Criteria_InList)
{
#region Declaration And Initialization Section.
List<Enrollment>  oReturnValue = new List<Enrollment> ();
string i_Ticket = string.Empty;
Result_Get_Enrollment_By_Criteria_InList oResult_Get_Enrollment_By_Criteria_InList = new Result_Get_Enrollment_By_Criteria_InList();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Enrollment_By_Criteria_InList(i_Params_Get_Enrollment_By_Criteria_InList);
oResult_Get_Enrollment_By_Criteria_InList.My_Result = oReturnValue;
oResult_Get_Enrollment_By_Criteria_InList.My_Params_Get_Enrollment_By_Criteria_InList = i_Params_Get_Enrollment_By_Criteria_InList;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Enrollment_By_Criteria_InList.ExceptionMsg = string.Format("Get_Enrollment_By_Criteria_InList : {0}", ex.Message);
}
else
{
oResult_Get_Enrollment_By_Criteria_InList.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Enrollment_By_Criteria_InList;
#endregion
}
#endregion
#region Get_Group_By_Criteria_InList
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Group_By_Criteria_InList Get_Group_By_Criteria_InList(Params_Get_Group_By_Criteria_InList i_Params_Get_Group_By_Criteria_InList)
{
#region Declaration And Initialization Section.
List<Group>  oReturnValue = new List<Group> ();
string i_Ticket = string.Empty;
Result_Get_Group_By_Criteria_InList oResult_Get_Group_By_Criteria_InList = new Result_Get_Group_By_Criteria_InList();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Group_By_Criteria_InList(i_Params_Get_Group_By_Criteria_InList);
oResult_Get_Group_By_Criteria_InList.My_Result = oReturnValue;
oResult_Get_Group_By_Criteria_InList.My_Params_Get_Group_By_Criteria_InList = i_Params_Get_Group_By_Criteria_InList;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Group_By_Criteria_InList.ExceptionMsg = string.Format("Get_Group_By_Criteria_InList : {0}", ex.Message);
}
else
{
oResult_Get_Group_By_Criteria_InList.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Group_By_Criteria_InList;
#endregion
}
#endregion
#region Get_Group_By_OWNER_ID
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Group_By_OWNER_ID Get_Group_By_OWNER_ID(Params_Get_Group_By_OWNER_ID i_Params_Get_Group_By_OWNER_ID)
{
#region Declaration And Initialization Section.
List<Group>  oReturnValue = new List<Group> ();
string i_Ticket = string.Empty;
Result_Get_Group_By_OWNER_ID oResult_Get_Group_By_OWNER_ID = new Result_Get_Group_By_OWNER_ID();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Group_By_OWNER_ID(i_Params_Get_Group_By_OWNER_ID);
oResult_Get_Group_By_OWNER_ID.My_Result = oReturnValue;
oResult_Get_Group_By_OWNER_ID.My_Params_Get_Group_By_OWNER_ID = i_Params_Get_Group_By_OWNER_ID;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Group_By_OWNER_ID.ExceptionMsg = string.Format("Get_Group_By_OWNER_ID : {0}", ex.Message);
}
else
{
oResult_Get_Group_By_OWNER_ID.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Group_By_OWNER_ID;
#endregion
}
#endregion
#region Get_Kg_By_OWNER_ID
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Kg_By_OWNER_ID Get_Kg_By_OWNER_ID(Params_Get_Kg_By_OWNER_ID i_Params_Get_Kg_By_OWNER_ID)
{
#region Declaration And Initialization Section.
List<Kg>  oReturnValue = new List<Kg> ();
string i_Ticket = string.Empty;
Result_Get_Kg_By_OWNER_ID oResult_Get_Kg_By_OWNER_ID = new Result_Get_Kg_By_OWNER_ID();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Kg_By_OWNER_ID(i_Params_Get_Kg_By_OWNER_ID);
oResult_Get_Kg_By_OWNER_ID.My_Result = oReturnValue;
oResult_Get_Kg_By_OWNER_ID.My_Params_Get_Kg_By_OWNER_ID = i_Params_Get_Kg_By_OWNER_ID;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Kg_By_OWNER_ID.ExceptionMsg = string.Format("Get_Kg_By_OWNER_ID : {0}", ex.Message);
}
else
{
oResult_Get_Kg_By_OWNER_ID.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Kg_By_OWNER_ID;
#endregion
}
#endregion
#region Get_Kitchen_By_Criteria_InList
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Kitchen_By_Criteria_InList Get_Kitchen_By_Criteria_InList(Params_Get_Kitchen_By_Criteria_InList i_Params_Get_Kitchen_By_Criteria_InList)
{
#region Declaration And Initialization Section.
List<Kitchen>  oReturnValue = new List<Kitchen> ();
string i_Ticket = string.Empty;
Result_Get_Kitchen_By_Criteria_InList oResult_Get_Kitchen_By_Criteria_InList = new Result_Get_Kitchen_By_Criteria_InList();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Kitchen_By_Criteria_InList(i_Params_Get_Kitchen_By_Criteria_InList);
oResult_Get_Kitchen_By_Criteria_InList.My_Result = oReturnValue;
oResult_Get_Kitchen_By_Criteria_InList.My_Params_Get_Kitchen_By_Criteria_InList = i_Params_Get_Kitchen_By_Criteria_InList;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Kitchen_By_Criteria_InList.ExceptionMsg = string.Format("Get_Kitchen_By_Criteria_InList : {0}", ex.Message);
}
else
{
oResult_Get_Kitchen_By_Criteria_InList.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Kitchen_By_Criteria_InList;
#endregion
}
#endregion
#region Get_LocalDB
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_LocalDB Get_LocalDB(Params_Get_LocalDB i_Params_Get_LocalDB)
{
#region Declaration And Initialization Section.
String oReturnValue = string.Empty;
string i_Ticket = string.Empty;
Result_Get_LocalDB oResult_Get_LocalDB = new Result_Get_LocalDB();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_LocalDB(i_Params_Get_LocalDB);
oResult_Get_LocalDB.My_Result = oReturnValue;
oResult_Get_LocalDB.My_Params_Get_LocalDB = i_Params_Get_LocalDB;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_LocalDB.ExceptionMsg = string.Format("Get_LocalDB : {0}", ex.Message);
}
else
{
oResult_Get_LocalDB.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_LocalDB;
#endregion
}
#endregion
#region Get_Menu_By_OWNER_ID
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Menu_By_OWNER_ID Get_Menu_By_OWNER_ID(Params_Get_Menu_By_OWNER_ID i_Params_Get_Menu_By_OWNER_ID)
{
#region Declaration And Initialization Section.
List<Menu>  oReturnValue = new List<Menu> ();
string i_Ticket = string.Empty;
Result_Get_Menu_By_OWNER_ID oResult_Get_Menu_By_OWNER_ID = new Result_Get_Menu_By_OWNER_ID();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Menu_By_OWNER_ID(i_Params_Get_Menu_By_OWNER_ID);
oResult_Get_Menu_By_OWNER_ID.My_Result = oReturnValue;
oResult_Get_Menu_By_OWNER_ID.My_Params_Get_Menu_By_OWNER_ID = i_Params_Get_Menu_By_OWNER_ID;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Menu_By_OWNER_ID.ExceptionMsg = string.Format("Get_Menu_By_OWNER_ID : {0}", ex.Message);
}
else
{
oResult_Get_Menu_By_OWNER_ID.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Menu_By_OWNER_ID;
#endregion
}
#endregion
#region Get_Notification_By_Criteria_InList
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Notification_By_Criteria_InList Get_Notification_By_Criteria_InList(Params_Get_Notification_By_Criteria_InList i_Params_Get_Notification_By_Criteria_InList)
{
#region Declaration And Initialization Section.
List<Notification>  oReturnValue = new List<Notification> ();
string i_Ticket = string.Empty;
Result_Get_Notification_By_Criteria_InList oResult_Get_Notification_By_Criteria_InList = new Result_Get_Notification_By_Criteria_InList();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Notification_By_Criteria_InList(i_Params_Get_Notification_By_Criteria_InList);
oResult_Get_Notification_By_Criteria_InList.My_Result = oReturnValue;
oResult_Get_Notification_By_Criteria_InList.My_Params_Get_Notification_By_Criteria_InList = i_Params_Get_Notification_By_Criteria_InList;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Notification_By_Criteria_InList.ExceptionMsg = string.Format("Get_Notification_By_Criteria_InList : {0}", ex.Message);
}
else
{
oResult_Get_Notification_By_Criteria_InList.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Notification_By_Criteria_InList;
#endregion
}
#endregion
#region Get_Offline_operation_By_OWNER_ID
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Offline_operation_By_OWNER_ID Get_Offline_operation_By_OWNER_ID(Params_Get_Offline_operation_By_OWNER_ID i_Params_Get_Offline_operation_By_OWNER_ID)
{
#region Declaration And Initialization Section.
List<Offline_operation>  oReturnValue = new List<Offline_operation> ();
string i_Ticket = string.Empty;
Result_Get_Offline_operation_By_OWNER_ID oResult_Get_Offline_operation_By_OWNER_ID = new Result_Get_Offline_operation_By_OWNER_ID();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Offline_operation_By_OWNER_ID(i_Params_Get_Offline_operation_By_OWNER_ID);
oResult_Get_Offline_operation_By_OWNER_ID.My_Result = oReturnValue;
oResult_Get_Offline_operation_By_OWNER_ID.My_Params_Get_Offline_operation_By_OWNER_ID = i_Params_Get_Offline_operation_By_OWNER_ID;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Offline_operation_By_OWNER_ID.ExceptionMsg = string.Format("Get_Offline_operation_By_OWNER_ID : {0}", ex.Message);
}
else
{
oResult_Get_Offline_operation_By_OWNER_ID.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Offline_operation_By_OWNER_ID;
#endregion
}
#endregion
#region Get_Setup_Entries_By_TBL_NAME
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Setup_Entries_By_TBL_NAME Get_Setup_Entries_By_TBL_NAME(Params_Get_Setup_Entries_By_TBL_NAME i_Params_Get_Setup_Entries_By_TBL_NAME)
{
#region Declaration And Initialization Section.
List<SetupEntry>  oReturnValue = new List<SetupEntry> ();
string i_Ticket = string.Empty;
Result_Get_Setup_Entries_By_TBL_NAME oResult_Get_Setup_Entries_By_TBL_NAME = new Result_Get_Setup_Entries_By_TBL_NAME();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Setup_Entries_By_TBL_NAME(i_Params_Get_Setup_Entries_By_TBL_NAME);
oResult_Get_Setup_Entries_By_TBL_NAME.My_Result = oReturnValue;
oResult_Get_Setup_Entries_By_TBL_NAME.My_Params_Get_Setup_Entries_By_TBL_NAME = i_Params_Get_Setup_Entries_By_TBL_NAME;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Setup_Entries_By_TBL_NAME.ExceptionMsg = string.Format("Get_Setup_Entries_By_TBL_NAME : {0}", ex.Message);
}
else
{
oResult_Get_Setup_Entries_By_TBL_NAME.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Setup_Entries_By_TBL_NAME;
#endregion
}
#endregion
#region Get_Startup_Data
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Startup_Data Get_Startup_Data(Params_Get_Startup_Data i_Params_Get_Startup_Data)
{
#region Declaration And Initialization Section.
Startup_Data oReturnValue = new Startup_Data();
string i_Ticket = string.Empty;
Result_Get_Startup_Data oResult_Get_Startup_Data = new Result_Get_Startup_Data();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Startup_Data(i_Params_Get_Startup_Data);
oResult_Get_Startup_Data.My_Result = oReturnValue;
oResult_Get_Startup_Data.My_Params_Get_Startup_Data = i_Params_Get_Startup_Data;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Startup_Data.ExceptionMsg = string.Format("Get_Startup_Data : {0}", ex.Message);
}
else
{
oResult_Get_Startup_Data.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Startup_Data;
#endregion
}
#endregion
#region Get_Startup_Data_Signature
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Startup_Data_Signature Get_Startup_Data_Signature(Params_Get_Startup_Data_Signature i_Params_Get_Startup_Data_Signature)
{
#region Declaration And Initialization Section.
Int64?  oReturnValue = new Int64? ();
string i_Ticket = string.Empty;
Result_Get_Startup_Data_Signature oResult_Get_Startup_Data_Signature = new Result_Get_Startup_Data_Signature();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Startup_Data_Signature(i_Params_Get_Startup_Data_Signature);
oResult_Get_Startup_Data_Signature.My_Result = oReturnValue;
oResult_Get_Startup_Data_Signature.My_Params_Get_Startup_Data_Signature = i_Params_Get_Startup_Data_Signature;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Startup_Data_Signature.ExceptionMsg = string.Format("Get_Startup_Data_Signature : {0}", ex.Message);
}
else
{
oResult_Get_Startup_Data_Signature.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Startup_Data_Signature;
#endregion
}
#endregion
#region Get_Student_By_Criteria_InList
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Student_By_Criteria_InList Get_Student_By_Criteria_InList(Params_Get_Student_By_Criteria_InList i_Params_Get_Student_By_Criteria_InList)
{
#region Declaration And Initialization Section.
List<Student>  oReturnValue = new List<Student> ();
string i_Ticket = string.Empty;
Result_Get_Student_By_Criteria_InList oResult_Get_Student_By_Criteria_InList = new Result_Get_Student_By_Criteria_InList();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Student_By_Criteria_InList(i_Params_Get_Student_By_Criteria_InList);
oResult_Get_Student_By_Criteria_InList.My_Result = oReturnValue;
oResult_Get_Student_By_Criteria_InList.My_Params_Get_Student_By_Criteria_InList = i_Params_Get_Student_By_Criteria_InList;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Student_By_Criteria_InList.ExceptionMsg = string.Format("Get_Student_By_Criteria_InList : {0}", ex.Message);
}
else
{
oResult_Get_Student_By_Criteria_InList.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Student_By_Criteria_InList;
#endregion
}
#endregion
#region Get_Student_By_OWNER_ID
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_Student_By_OWNER_ID Get_Student_By_OWNER_ID(Params_Get_Student_By_OWNER_ID i_Params_Get_Student_By_OWNER_ID)
{
#region Declaration And Initialization Section.
List<Student>  oReturnValue = new List<Student> ();
string i_Ticket = string.Empty;
Result_Get_Student_By_OWNER_ID oResult_Get_Student_By_OWNER_ID = new Result_Get_Student_By_OWNER_ID();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_Student_By_OWNER_ID(i_Params_Get_Student_By_OWNER_ID);
oResult_Get_Student_By_OWNER_ID.My_Result = oReturnValue;
oResult_Get_Student_By_OWNER_ID.My_Params_Get_Student_By_OWNER_ID = i_Params_Get_Student_By_OWNER_ID;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_Student_By_OWNER_ID.ExceptionMsg = string.Format("Get_Student_By_OWNER_ID : {0}", ex.Message);
}
else
{
oResult_Get_Student_By_OWNER_ID.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_Student_By_OWNER_ID;
#endregion
}
#endregion
#region Get_User_By_Criteria
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_User_By_Criteria Get_User_By_Criteria(Params_Get_User_By_Criteria i_Params_Get_User_By_Criteria)
{
#region Declaration And Initialization Section.
List<User>  oReturnValue = new List<User> ();
string i_Ticket = string.Empty;
Result_Get_User_By_Criteria oResult_Get_User_By_Criteria = new Result_Get_User_By_Criteria();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_User_By_Criteria(i_Params_Get_User_By_Criteria);
oResult_Get_User_By_Criteria.My_Result = oReturnValue;
oResult_Get_User_By_Criteria.My_Params_Get_User_By_Criteria = i_Params_Get_User_By_Criteria;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_User_By_Criteria.ExceptionMsg = string.Format("Get_User_By_Criteria : {0}", ex.Message);
}
else
{
oResult_Get_User_By_Criteria.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_User_By_Criteria;
#endregion
}
#endregion
#region Get_User_group_By_USER_ID
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_User_group_By_USER_ID Get_User_group_By_USER_ID(Params_Get_User_group_By_USER_ID i_Params_Get_User_group_By_USER_ID)
{
#region Declaration And Initialization Section.
List<User_group>  oReturnValue = new List<User_group> ();
string i_Ticket = string.Empty;
Result_Get_User_group_By_USER_ID oResult_Get_User_group_By_USER_ID = new Result_Get_User_group_By_USER_ID();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_User_group_By_USER_ID(i_Params_Get_User_group_By_USER_ID);
oResult_Get_User_group_By_USER_ID.My_Result = oReturnValue;
oResult_Get_User_group_By_USER_ID.My_Params_Get_User_group_By_USER_ID = i_Params_Get_User_group_By_USER_ID;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_User_group_By_USER_ID.ExceptionMsg = string.Format("Get_User_group_By_USER_ID : {0}", ex.Message);
}
else
{
oResult_Get_User_group_By_USER_ID.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_User_group_By_USER_ID;
#endregion
}
#endregion
#region Get_User_menu_By_USER_ID
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Get_User_menu_By_USER_ID Get_User_menu_By_USER_ID(Params_Get_User_menu_By_USER_ID i_Params_Get_User_menu_By_USER_ID)
{
#region Declaration And Initialization Section.
List<User_menu>  oReturnValue = new List<User_menu> ();
string i_Ticket = string.Empty;
Result_Get_User_menu_By_USER_ID oResult_Get_User_menu_By_USER_ID = new Result_Get_User_menu_By_USER_ID();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.Get_User_menu_By_USER_ID(i_Params_Get_User_menu_By_USER_ID);
oResult_Get_User_menu_By_USER_ID.My_Result = oReturnValue;
oResult_Get_User_menu_By_USER_ID.My_Params_Get_User_menu_By_USER_ID = i_Params_Get_User_menu_By_USER_ID;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Get_User_menu_By_USER_ID.ExceptionMsg = string.Format("Get_User_menu_By_USER_ID : {0}", ex.Message);
}
else
{
oResult_Get_User_menu_By_USER_ID.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Get_User_menu_By_USER_ID;
#endregion
}
#endregion
#region IsAuthenticated_JSON
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_IsAuthenticated_JSON IsAuthenticated_JSON(Params_IsAuthenticated i_Params_IsAuthenticated)
{
#region Declaration And Initialization Section.
UserInfo oReturnValue = new UserInfo();
string i_Ticket = string.Empty;
Result_IsAuthenticated_JSON oResult_IsAuthenticated_JSON = new Result_IsAuthenticated_JSON();
#endregion
#region Body Section.
try
{


BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oReturnValue = oBLC.IsAuthenticated_JSON(i_Params_IsAuthenticated);
oResult_IsAuthenticated_JSON.My_Result = oReturnValue;
oResult_IsAuthenticated_JSON.My_Params_IsAuthenticated = i_Params_IsAuthenticated;

if (oReturnValue.IsAuthenticated == true)
{
System.Web.HttpContext.Current.Session["TICKET"] = true;
}
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_IsAuthenticated_JSON.ExceptionMsg = string.Format("IsAuthenticated_JSON : {0}", ex.Message);
}
else
{
oResult_IsAuthenticated_JSON.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_IsAuthenticated_JSON;
#endregion
}
#endregion
#region Register_PNS_Token
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Register_PNS_Token Register_PNS_Token(PNS_Token i_PNS_Token)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Register_PNS_Token oResult_Register_PNS_Token = new Result_Register_PNS_Token();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Register_PNS_Token(i_PNS_Token);
oResult_Register_PNS_Token.My_PNS_Token = i_PNS_Token;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Register_PNS_Token.ExceptionMsg = string.Format("Register_PNS_Token : {0}", ex.Message);
}
else
{
oResult_Register_PNS_Token.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Register_PNS_Token;
#endregion
}
#endregion
#region Send_Notification
[OperationContract]
[
WebInvoke
(
Method = "POST",
BodyStyle = WebMessageBodyStyle.Bare,
ResponseFormat = WebMessageFormat.Json,
RequestFormat = WebMessageFormat.Json
)
]
public Result_Send_Notification Send_Notification(Params_Send_Notification i_Params_Send_Notification)
{
#region Declaration And Initialization Section.
string i_Ticket = string.Empty;
Result_Send_Notification oResult_Send_Notification = new Result_Send_Notification();
#endregion
#region Body Section.
try
{

// Ticket Checking
//-------------------
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] != null)
{
if (ConfigurationManager.AppSettings["ENABLE_TICKET"] == "1")
{
if
(
(System.Web.HttpContext.Current.Request.QueryString["Ticket"] != null) &&
(System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString() != "")
)
{
i_Ticket = System.Web.HttpContext.Current.Request.QueryString["Ticket"].ToString();
}
else
{
throw new Exception("Invalid Ticket");
}
}
}
//-------------------

BLC.BLC oBLC_Default = new BLC.BLC();
BLCInitializer oBLCInitializer = new BLCInitializer();
oBLCInitializer.UserID           = Convert.ToInt64(oBLC_Default.ResolveTicket(i_Ticket)["USER_ID"]);
oBLCInitializer.OwnerID          = Convert.ToInt32(oBLC_Default.ResolveTicket(i_Ticket)["OWNER_ID"]);
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
oBLC.Send_Notification(i_Params_Send_Notification);
oResult_Send_Notification.My_Params_Send_Notification = i_Params_Send_Notification;
}
}
catch(Exception ex)
{
if (ex.GetType().FullName != "BLC.BLCException")
{
oResult_Send_Notification.ExceptionMsg = string.Format("Send_Notification : {0}", ex.Message);
}
else
{
oResult_Send_Notification.ExceptionMsg = ex.Message;
}
}
#endregion
#region Return Section
return oResult_Send_Notification;
#endregion
}
#endregion
}

#region Action_Result
public partial class Action_Result
{
#region Properties.
public string ExceptionMsg { get; set; }
#endregion
#region Constructor
public Action_Result()
{
#region Declaration And Initialization Section.
#endregion
#region Body Section.
this.ExceptionMsg = string.Empty;
#endregion
}
#endregion
}
#endregion
#region Result_Delete_Academic_year
public partial class Result_Delete_Academic_year : Action_Result
{
#region Properties.
public Params_Delete_Academic_year My_Params_Delete_Academic_year { get; set; }
#endregion
}
#endregion
#region Result_Delete_Attendance
public partial class Result_Delete_Attendance : Action_Result
{
#region Properties.
public Params_Delete_Attendance My_Params_Delete_Attendance { get; set; }
#endregion
}
#endregion
#region Result_Delete_Document
public partial class Result_Delete_Document : Action_Result
{
#region Properties.
public Params_Delete_Document My_Params_Delete_Document { get; set; }
#endregion
}
#endregion
#region Result_Delete_Enrollment
public partial class Result_Delete_Enrollment : Action_Result
{
#region Properties.
public Params_Delete_Enrollment My_Params_Delete_Enrollment { get; set; }
#endregion
}
#endregion
#region Result_Delete_Group
public partial class Result_Delete_Group : Action_Result
{
#region Properties.
public Params_Delete_Group My_Params_Delete_Group { get; set; }
#endregion
}
#endregion
#region Result_Delete_Kg
public partial class Result_Delete_Kg : Action_Result
{
#region Properties.
public Params_Delete_Kg My_Params_Delete_Kg { get; set; }
#endregion
}
#endregion
#region Result_Delete_Kitchen
public partial class Result_Delete_Kitchen : Action_Result
{
#region Properties.
public Params_Delete_Kitchen My_Params_Delete_Kitchen { get; set; }
#endregion
}
#endregion
#region Result_Delete_Notification
public partial class Result_Delete_Notification : Action_Result
{
#region Properties.
public Params_Delete_Notification My_Params_Delete_Notification { get; set; }
#endregion
}
#endregion
#region Result_Delete_Student
public partial class Result_Delete_Student : Action_Result
{
#region Properties.
public Params_Delete_Student My_Params_Delete_Student { get; set; }
#endregion
}
#endregion
#region Result_Delete_User
public partial class Result_Delete_User : Action_Result
{
#region Properties.
public Params_Delete_User My_Params_Delete_User { get; set; }
#endregion
}
#endregion
#region Result_Delete_User_group
public partial class Result_Delete_User_group : Action_Result
{
#region Properties.
public Params_Delete_User_group My_Params_Delete_User_group { get; set; }
#endregion
}
#endregion
#region Result_Delete_User_menu
public partial class Result_Delete_User_menu : Action_Result
{
#region Properties.
public Params_Delete_User_menu My_Params_Delete_User_menu { get; set; }
#endregion
}
#endregion
#region Result_Download_Offline_Transations
public partial class Result_Download_Offline_Transations : Action_Result
{
#region Properties.
public List<Offline_Transaction>  My_Result { get; set; }
public Params_Download_Offline_Transations My_Params_Download_Offline_Transations { get; set; }
#endregion
}
#endregion
#region Result_Edit_Academic_year
public partial class Result_Edit_Academic_year : Action_Result
{
#region Properties.
public Academic_year My_Academic_year { get; set; }
#endregion
}
#endregion
#region Result_Edit_Attendance
public partial class Result_Edit_Attendance : Action_Result
{
#region Properties.
public Attendance My_Attendance { get; set; }
#endregion
}
#endregion
#region Result_Edit_Device
public partial class Result_Edit_Device : Action_Result
{
#region Properties.
public Device My_Device { get; set; }
#endregion
}
#endregion
#region Result_Edit_Device_contact
public partial class Result_Edit_Device_contact : Action_Result
{
#region Properties.
public Device_contact My_Device_contact { get; set; }
#endregion
}
#endregion
#region Result_Edit_Document
public partial class Result_Edit_Document : Action_Result
{
#region Properties.
public Document My_Document { get; set; }
#endregion
}
#endregion
#region Result_Edit_Enrollment
public partial class Result_Edit_Enrollment : Action_Result
{
#region Properties.
public Enrollment My_Enrollment { get; set; }
#endregion
}
#endregion
#region Result_Edit_Group
public partial class Result_Edit_Group : Action_Result
{
#region Properties.
public Group My_Group { get; set; }
#endregion
}
#endregion
#region Result_Edit_Kg
public partial class Result_Edit_Kg : Action_Result
{
#region Properties.
public Kg My_Kg { get; set; }
#endregion
}
#endregion
#region Result_Edit_Kitchen
public partial class Result_Edit_Kitchen : Action_Result
{
#region Properties.
public Kitchen My_Kitchen { get; set; }
#endregion
}
#endregion
#region Result_Edit_Notification
public partial class Result_Edit_Notification : Action_Result
{
#region Properties.
public Notification My_Notification { get; set; }
#endregion
}
#endregion
#region Result_Edit_Setup
public partial class Result_Edit_Setup : Action_Result
{
#region Properties.
public SetupEntry My_SetupEntry { get; set; }
#endregion
}
#endregion
#region Result_Edit_Student
public partial class Result_Edit_Student : Action_Result
{
#region Properties.
public Student My_Student { get; set; }
#endregion
}
#endregion
#region Result_Edit_User
public partial class Result_Edit_User : Action_Result
{
#region Properties.
public User My_User { get; set; }
#endregion
}
#endregion
#region Result_Edit_User_group
public partial class Result_Edit_User_group : Action_Result
{
#region Properties.
public User_group My_User_group { get; set; }
#endregion
}
#endregion
#region Result_Edit_User_menu
public partial class Result_Edit_User_menu : Action_Result
{
#region Properties.
public User_menu My_User_menu { get; set; }
#endregion
}
#endregion
#region Result_EditSetup
public partial class Result_EditSetup : Action_Result
{
#region Properties.
public SetupEntry My_SetupEntry { get; set; }
#endregion
}
#endregion
#region Result_Forgot_Password
public partial class Result_Forgot_Password : Action_Result
{
#region Properties.
public Params_Forgot_Password My_Params_Forgot_Password { get; set; }
#endregion
}
#endregion
#region Result_Get_Academic_year_By_Criteria_InList
public partial class Result_Get_Academic_year_By_Criteria_InList : Action_Result
{
#region Properties.
public List<Academic_year>  My_Result { get; set; }
public Params_Get_Academic_year_By_Criteria_InList My_Params_Get_Academic_year_By_Criteria_InList { get; set; }
#endregion
}
#endregion
#region Result_Get_Academic_year_By_OWNER_ID
public partial class Result_Get_Academic_year_By_OWNER_ID : Action_Result
{
#region Properties.
public List<Academic_year>  My_Result { get; set; }
public Params_Get_Academic_year_By_OWNER_ID My_Params_Get_Academic_year_By_OWNER_ID { get; set; }
#endregion
}
#endregion
#region Result_Get_Attendance_By_ENROLLMENT_ID
public partial class Result_Get_Attendance_By_ENROLLMENT_ID : Action_Result
{
#region Properties.
public List<Attendance>  My_Result { get; set; }
public Params_Get_Attendance_By_ENROLLMENT_ID My_Params_Get_Attendance_By_ENROLLMENT_ID { get; set; }
#endregion
}
#endregion
#region Result_Get_Distinct_Setup_Tables
public partial class Result_Get_Distinct_Setup_Tables : Action_Result
{
#region Properties.
public List<SetupEntry>  My_Result { get; set; }
public Params_Get_Distinct_Setup_Tables My_Params_Get_Distinct_Setup_Tables { get; set; }
#endregion
}
#endregion
#region Result_Get_Document_By_REL_KEY_REL_ENTITY
public partial class Result_Get_Document_By_REL_KEY_REL_ENTITY : Action_Result
{
#region Properties.
public List<Document>  My_Result { get; set; }
public Params_Get_Document_By_REL_KEY_REL_ENTITY My_Params_Get_Document_By_REL_KEY_REL_ENTITY { get; set; }
#endregion
}
#endregion
#region Result_Get_Enrollment_By_Criteria_InList
public partial class Result_Get_Enrollment_By_Criteria_InList : Action_Result
{
#region Properties.
public List<Enrollment>  My_Result { get; set; }
public Params_Get_Enrollment_By_Criteria_InList My_Params_Get_Enrollment_By_Criteria_InList { get; set; }
#endregion
}
#endregion
#region Result_Get_Group_By_Criteria_InList
public partial class Result_Get_Group_By_Criteria_InList : Action_Result
{
#region Properties.
public List<Group>  My_Result { get; set; }
public Params_Get_Group_By_Criteria_InList My_Params_Get_Group_By_Criteria_InList { get; set; }
#endregion
}
#endregion
#region Result_Get_Group_By_OWNER_ID
public partial class Result_Get_Group_By_OWNER_ID : Action_Result
{
#region Properties.
public List<Group>  My_Result { get; set; }
public Params_Get_Group_By_OWNER_ID My_Params_Get_Group_By_OWNER_ID { get; set; }
#endregion
}
#endregion
#region Result_Get_Kg_By_OWNER_ID
public partial class Result_Get_Kg_By_OWNER_ID : Action_Result
{
#region Properties.
public List<Kg>  My_Result { get; set; }
public Params_Get_Kg_By_OWNER_ID My_Params_Get_Kg_By_OWNER_ID { get; set; }
#endregion
}
#endregion
#region Result_Get_Kitchen_By_Criteria_InList
public partial class Result_Get_Kitchen_By_Criteria_InList : Action_Result
{
#region Properties.
public List<Kitchen>  My_Result { get; set; }
public Params_Get_Kitchen_By_Criteria_InList My_Params_Get_Kitchen_By_Criteria_InList { get; set; }
#endregion
}
#endregion
#region Result_Get_LocalDB
public partial class Result_Get_LocalDB : Action_Result
{
#region Properties.
public String My_Result { get; set; }
public Params_Get_LocalDB My_Params_Get_LocalDB { get; set; }
#endregion
}
#endregion
#region Result_Get_Menu_By_OWNER_ID
public partial class Result_Get_Menu_By_OWNER_ID : Action_Result
{
#region Properties.
public List<Menu>  My_Result { get; set; }
public Params_Get_Menu_By_OWNER_ID My_Params_Get_Menu_By_OWNER_ID { get; set; }
#endregion
}
#endregion
#region Result_Get_Notification_By_Criteria_InList
public partial class Result_Get_Notification_By_Criteria_InList : Action_Result
{
#region Properties.
public List<Notification>  My_Result { get; set; }
public Params_Get_Notification_By_Criteria_InList My_Params_Get_Notification_By_Criteria_InList { get; set; }
#endregion
}
#endregion
#region Result_Get_Offline_operation_By_OWNER_ID
public partial class Result_Get_Offline_operation_By_OWNER_ID : Action_Result
{
#region Properties.
public List<Offline_operation>  My_Result { get; set; }
public Params_Get_Offline_operation_By_OWNER_ID My_Params_Get_Offline_operation_By_OWNER_ID { get; set; }
#endregion
}
#endregion
#region Result_Get_Setup_Entries_By_TBL_NAME
public partial class Result_Get_Setup_Entries_By_TBL_NAME : Action_Result
{
#region Properties.
public List<SetupEntry>  My_Result { get; set; }
public Params_Get_Setup_Entries_By_TBL_NAME My_Params_Get_Setup_Entries_By_TBL_NAME { get; set; }
#endregion
}
#endregion
#region Result_Get_Startup_Data
public partial class Result_Get_Startup_Data : Action_Result
{
#region Properties.
public Startup_Data My_Result { get; set; }
public Params_Get_Startup_Data My_Params_Get_Startup_Data { get; set; }
#endregion
}
#endregion
#region Result_Get_Startup_Data_Signature
public partial class Result_Get_Startup_Data_Signature : Action_Result
{
#region Properties.
public Int64?  My_Result { get; set; }
public Params_Get_Startup_Data_Signature My_Params_Get_Startup_Data_Signature { get; set; }
#endregion
}
#endregion
#region Result_Get_Student_By_Criteria_InList
public partial class Result_Get_Student_By_Criteria_InList : Action_Result
{
#region Properties.
public List<Student>  My_Result { get; set; }
public Params_Get_Student_By_Criteria_InList My_Params_Get_Student_By_Criteria_InList { get; set; }
#endregion
}
#endregion
#region Result_Get_Student_By_OWNER_ID
public partial class Result_Get_Student_By_OWNER_ID : Action_Result
{
#region Properties.
public List<Student>  My_Result { get; set; }
public Params_Get_Student_By_OWNER_ID My_Params_Get_Student_By_OWNER_ID { get; set; }
#endregion
}
#endregion
#region Result_Get_User_By_Criteria
public partial class Result_Get_User_By_Criteria : Action_Result
{
#region Properties.
public List<User>  My_Result { get; set; }
public Params_Get_User_By_Criteria My_Params_Get_User_By_Criteria { get; set; }
#endregion
}
#endregion
#region Result_Get_User_group_By_USER_ID
public partial class Result_Get_User_group_By_USER_ID : Action_Result
{
#region Properties.
public List<User_group>  My_Result { get; set; }
public Params_Get_User_group_By_USER_ID My_Params_Get_User_group_By_USER_ID { get; set; }
#endregion
}
#endregion
#region Result_Get_User_menu_By_USER_ID
public partial class Result_Get_User_menu_By_USER_ID : Action_Result
{
#region Properties.
public List<User_menu>  My_Result { get; set; }
public Params_Get_User_menu_By_USER_ID My_Params_Get_User_menu_By_USER_ID { get; set; }
#endregion
}
#endregion
#region Result_IsAuthenticated_JSON
public partial class Result_IsAuthenticated_JSON : Action_Result
{
#region Properties.
public UserInfo My_Result { get; set; }
public Params_IsAuthenticated My_Params_IsAuthenticated { get; set; }
#endregion
}
#endregion
#region Result_Register_PNS_Token
public partial class Result_Register_PNS_Token : Action_Result
{
#region Properties.
public PNS_Token My_PNS_Token { get; set; }
#endregion
}
#endregion
#region Result_Send_Notification
public partial class Result_Send_Notification : Action_Result
{
#region Properties.
public Params_Send_Notification My_Params_Send_Notification { get; set; }
#endregion
}
#endregion
