import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs/BehaviorSubject';

@Injectable()
export class CommonService {
  public APIUrl = 'http://localhost/TrainigWebAPI/api/Data/';
  public ticket = '';
  constructor() { }

  ShowMessage(message: string, d: number = 1000) {
    alert(message);
  }

  Handle_Exception(msg) {
    if ((msg != null) && (msg !== '')) {
      this.ShowMessage(msg , 3000);
    }
  }
}
