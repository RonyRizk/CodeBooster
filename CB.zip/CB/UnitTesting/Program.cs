﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Reflection;
using System.IO;
using Tools;
using System.Data.OleDb;
using System.Data;
using System.Data.Linq;
using System.Transactions;
using System.Text.RegularExpressions;
using System.Threading;
using System.Data.SqlClient;
using BLC;

namespace UnitTesting
{
    class Program
    {
        #region Main
        [STAThread]
        static void Main(string[] args)
        {
            #region Declaration And Initialization Section.
            string _ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
            BLC.BLCInitializer oBLCInitializer = new BLC.BLCInitializer();
            oBLCInitializer.ConnectionString = _ConnectionString;
            oBLCInitializer.OwnerID = 1;
            oBLCInitializer.UserID = 1;
            oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
            BLC.BLC oBLC = new BLC.BLC(oBLCInitializer);
	    string str_Option = string.Empty;
            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region Body
            
	    // -------------
            if (args != null)
            {
                if (args.Count() > 0)
                {
                    str_Option = args[0].ToString();
                }
            }
            // -------------

            // Option Selection.
            // -------------
            if (string.IsNullOrEmpty(str_Option) == true)
            {
                Console.WriteLine("Please, Select An Option:");
                Console.WriteLine("001 --> ???");               

                str_Option = Console.ReadLine();
            }
            // -------------  

	    // -------------
            switch (str_Option)
            {
                case "001":
                    break;
	        }
            // -------------				
  
            #endregion
        }
        #endregion
    }

}




