﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Reflection;
using System.IO;
using Tools;
using System.Data.OleDb;
using System.Data;
using System.Data.Linq;
using System.Transactions;
using System.Text.RegularExpressions;
using System.Threading;
using System.Data.SqlClient;
using BLC;


namespace UnitTesting
{
    class Program
    {
        #region Main
        [STAThread]
        static void Main(string[] args)
        {
            #region Declaration And Initialization Section.
            string _ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
            BLC.BLCInitializer oBLCInitializer = new BLC.BLCInitializer();
            oBLCInitializer.ConnectionString = _ConnectionString;
            oBLCInitializer.OwnerID = 1;
            oBLCInitializer.UserID = 1;
            oBLCInitializer.Messages_FilePath = ConfigurationManager.AppSettings["BLC_MESSAGES"];
            BLC.BLC oBLC = new BLC.BLC(oBLCInitializer);
	        string str_Option = string.Empty;

            string str_Full_Path = string.Empty;
            Params_Generate_Local_Operations oParams_Generate_Local_Operations = new Params_Generate_Local_Operations();
            string str_Destination_Folder = ConfigurationManager.AppSettings["DESTINATION_FOLDER"].ToString();
            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region Body
            
	        // -------------
            if (args != null)
            {
                if (args.Count() > 0)
                {
                    str_Option = args[0].ToString();
                }
            }
            // -------------

            // Option Selection.
            // -------------
            if (string.IsNullOrEmpty(str_Option) == true)
            {
                Console.WriteLine("Please, Select An Option:");                   
                Console.WriteLine("001 --> Generate Initial Local Data");
                Console.WriteLine("002 --> Generate Local Operations (all)");
                Console.WriteLine("003 --> Generate Local Operations (WebSql)");
                Console.WriteLine("004 --> Generate Local Operations (IndexedDB)");
                             
                str_Option = Console.ReadLine();
            }
            // -------------  

	         // -------------
            switch (str_Option)
            {               
                case "001":
                     Params_Generate_Initial_Local_Data oParams_Generate_Initial_Local_Data = new Params_Generate_Initial_Local_Data();
                     oParams_Generate_Initial_Local_Data.DESTINATION_FOLDER = str_Destination_Folder;
                     oParams_Generate_Initial_Local_Data.My_Extra_LocalDB_Params = new List<Extra_LocalDB_Param>();                   
                     oBLC.Generate_Initial_Local_Data(oParams_Generate_Initial_Local_Data);
                    break;
                case "002":
                    oParams_Generate_Local_Operations = new Params_Generate_Local_Operations();
                    oParams_Generate_Local_Operations.DESTINATION_FOLDER = string.Format(@"{0}\LocalOperations.js",str_Destination_Folder);;
                    oParams_Generate_Local_Operations.My_Enum_LocalOperations_Target = Enum_LocalOperations_Target.All;
                    oBLC.Generate_Local_Operations(oParams_Generate_Local_Operations);
                    break;
                case "003":
                    oParams_Generate_Local_Operations = new Params_Generate_Local_Operations();
                    oParams_Generate_Local_Operations.DESTINATION_FOLDER = string.Format(@"{0}\LocalOperations.js",str_Destination_Folder);;
                    oParams_Generate_Local_Operations.My_Enum_LocalOperations_Target = Enum_LocalOperations_Target.WebSql;
                    oBLC.Generate_Local_Operations(oParams_Generate_Local_Operations);
                    break;
                case "004":
                    oParams_Generate_Local_Operations = new Params_Generate_Local_Operations();
                    oParams_Generate_Local_Operations.DESTINATION_FOLDER = string.Format(@"{0}\LocalOperations.js",str_Destination_Folder);;
                    oParams_Generate_Local_Operations.My_Enum_LocalOperations_Target = Enum_LocalOperations_Target.IndexedDB;
                    oBLC.Generate_Local_Operations(oParams_Generate_Local_Operations);
                    break;                                     

	        }
            // -------------				
  
            #endregion
        }
        #endregion
    }

}




