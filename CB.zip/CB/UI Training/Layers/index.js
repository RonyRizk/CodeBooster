function ViewModel()
	{
      var self = this;
	  self.My_Base_Types = [];
	  
	  self.Get_Data_From_Server = function()
	  {
	    self.My_Base_Types.push(new BaseModel(1,'Square','images/square.png'));
		self.My_Base_Types.push(new BaseModel(2,'Circle','images/circle.png'));
		self.My_Base_Types.push(new BaseModel(3,'BlaBla','images/blabla.png'));
		
		/*
	    self.My_Base_Types.push({id:1,'Description':'Square' , img:'images/square.png'});
		self.My_Base_Types.push({id:2,'Description':'Circle' , img:'images/circle.png'});
		self.My_Base_Types.push({id:3,'Description':'BlaBla' , img:'images/blabla.png'});
		*/
	  }
	  
	  self.Select_Base = function(base){		
		base.Is_HighLighted(true);
		for(var i = 0; i < self.My_Base_Types.length;i++)
		{
		  console.log(self.My_Base_Types[i].id() + '-' + base.id());
		  if(self.My_Base_Types[i].id() != base.id())
		  {
		    self.My_Base_Types[i].Is_HighLighted(false);
		  }
		}
		//Call WCF Method Edit_Base
	  }
	}
	
	function BaseModel(id,description,img)
	{
	  var self = this;
	  self.id = ko.observable(id);
	  self.Description = ko.observable(description);
	  self.img = ko.observable(img);
	  
	  self.Is_HighLighted =ko.observable(false);
	  
	}
	
	var VM = new ViewModel();
	$(document).ready(function(){
		VM.Get_Data_From_Server();
		ko.applyBindings(VM);
	});