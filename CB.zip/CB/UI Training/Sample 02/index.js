/**************************************************/
function PersonModel
(	
	_FIRST_NAME,
	_LAST_NAME,
	_FATHER_NAME
) {
	var self = this;

	self.FIRST_NAME = ko.observable(_FIRST_NAME);
	self.LAST_NAME = ko.observable(_LAST_NAME);
	self.FATHER_NAME = ko.observable(_FATHER_NAME);	
}
/**************************************************/

/**************************************************/
function PersonViewModel() {

	/**************************************************/
	var self = this;
	/**************************************************/

	/**************************************************/
	self.Persons = ko.mapping.fromJS([]);
	/**************************************************/
	
	/**************************************************/
	self.SearchPerson = function(){
		for(var i=1;i<=5;i++)
		{
		   var js_Person = new PersonModel('First_Name_' + i, 'Last_Name_' + i,'Father_Name_' + i);
		   self.Persons.push(js_Person);
		}
	}
	/**************************************************/
	
}
/**************************************************/

/************************************************/
var MyVM = null;
/************************************************/

/************************************************/
$(document).ready
(
	function () {
	MyVM = new PersonViewModel();
	ko.applyBindings(MyVM);
	MyVM.SearchPerson();
});
/************************************************/
