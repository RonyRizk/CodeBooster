﻿
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;

public partial class Proxy
{
    #region Properties
    public string BaseURL { get; set; }
    public string Ticket { get; set; }
    #endregion

    #region CallWebAPI
    public async Task<T> CallWebAPI<T>(string i_MethodName, object i_Input)
    {
        #region Declaration And Initialization Section.
        T toRet = default(T);
        #endregion
        #region Body Section.

        // ------------
        var oProxy = new HttpClient();
        oProxy.BaseAddress = new Uri(this.BaseURL);
        // ------------

        oProxy.DefaultRequestHeaders
                       .Accept
                       .Add(new MediaTypeWithQualityHeaderValue("application/json"));
        oProxy.DefaultRequestHeaders.Add("Ticket", this.Ticket);

        string str_Content = JsonConvert.SerializeObject
                                                    (
                                                        i_Input, Formatting.Indented , 
                                                        new JsonSerializerSettings
                                                        {
                                                            NullValueHandling = NullValueHandling.Ignore
                                                        });

        var content = new StringContent
            (
                str_Content,
                Encoding.UTF8,
                "application/json"
            );

        var response = await oProxy.PostAsync(oProxy.BaseAddress + string.Format("/{0}", i_MethodName), content);
        //var response = await oProxy.PostAsync(oProxy.BaseAddress + string.Format("/{0}?Ticket={1}", i_MethodName, this.Ticket), content);
        if (response.StatusCode == System.Net.HttpStatusCode.OK)
        {
            string responseBody = await response.Content.ReadAsStringAsync();
            toRet = JsonConvert.DeserializeObject<T>(responseBody);
        }
        else
        {
            string responseBody = await response.Content.ReadAsStringAsync();
            ErrorDto oErrorDto = JsonConvert.DeserializeObject<ErrorDto>(responseBody);
            throw new Exception(oErrorDto.Message);
        }
        #endregion

        return toRet;
    }
    #endregion
}

public class ErrorDto
{
    public int Code { get; set; }
    public string Message { get; set; }

    // other fields

    public override string ToString()
    {
        return JsonConvert.SerializeObject(this);
    }
}

