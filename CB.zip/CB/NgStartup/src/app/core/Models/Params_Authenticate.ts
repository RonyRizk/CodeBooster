export class Params_Authenticate {
    username: string;
    password: string;
}
