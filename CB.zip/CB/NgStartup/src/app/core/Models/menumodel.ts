export class menumodel
{
    fa_icon: string;
    title: string;
    route: string;
    IsSetup: boolean;
}