----------------------------
DECLARE @V__MENU_ID AS INT
DECLARE @V__PARENT_ID AS INT

DECLARE @V__ENTRY_USER_ID  AS BIGINT
DECLARE @V__ENTRY_DATE     AS NVARCHAR(20)
DECLARE @V__OWNER_ID       AS INT

SET     @V__MENU_ID			= 0
SET     @V__PARENT_ID		= 0
SET     @V__ENTRY_USER_ID	= 1
SET     @V__ENTRY_DATE      = '2014-10-31'
----------------------------

-- Create Menu Entry.
----------------------------
SELECT @V__PARENT_ID = [DBO].[UDF_GET_MENU_BY_CODE](NULL)
EXEC   [dbo].[UP_EDIT_MENU]  @V__PARENT_ID , @V__MENU_ID OUTPUT,N'FILE',N'',N'File', N'File',N'',N'File',@V__ENTRY_USER_ID,@V__ENTRY_DATE
----------------------------

----------------------------
EXEC [DBO].[UP_EDIT_USER_MENU] -1,@V__ENTRY_USER_ID,@V__MENU_ID
----------------------------