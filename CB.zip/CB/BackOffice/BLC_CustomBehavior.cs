using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.ObjectModel;
using System.Configuration;
using DALC;
using System.Data.Linq;
using System.Text.RegularExpressions;
using System.Transactions;
using System.Reflection;
using System.Data.SqlClient;
using Hasher;
using System.IO;
using Microsoft.SqlServer.Types;
using System.Threading;

namespace BLC
{
    #region Enumeration
    public enum Enum_EntityNameFormat
    {
        FML,
        FLM,
        MFL,
        MLF,
        LFM,
        LMF
    }
    #endregion
    public partial class BLC
    {
        #region Members
        public string _KeyPublic = "<RSAKeyValue><Modulus>2rR6f89bEyTkmmaUu/97+s4nyo6nH14QZ6I60UJlGjdVZB3qOX5/8wt01Sl0sss84q/fU3nsqDh33vS5FEmmRKzdRVBYS+EfDEVh6VDeXi3JQP9E/iNsYusCJUYWhU/6d4e+KgxlAwe/Uu/sIIjY2KUZIBv6fy5JZ8Y3wwC/VQ8=</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>";
        public string _KeySet = "<RSAKeyValue><Modulus>2rR6f89bEyTkmmaUu/97+s4nyo6nH14QZ6I60UJlGjdVZB3qOX5/8wt01Sl0sss84q/fU3nsqDh33vS5FEmmRKzdRVBYS+EfDEVh6VDeXi3JQP9E/iNsYusCJUYWhU/6d4e+KgxlAwe/Uu/sIIjY2KUZIBv6fy5JZ8Y3wwC/VQ8=</Modulus><Exponent>AQAB</Exponent><P>7kNI6DCzqJ6LEK/4ToYwoaAIpmjeeiNpgXqMsBtoJMKfm+H4hwODqXWXnbJBLFj7LOusS8NlJgp9kMPyCG2j3w==</P><Q>6vx37xhAC+yClipDUjipUbYdQgGA2VHRFh2DiKpMxFwP1sj1fWX3/wUc/4SdVFdex1URPm3IF0hdrhJIYnT00Q==</Q><DP>T6Aw51gPUpTZiNQmOafi7MDc4zA82bin89uO1PPz1AUu7huQwR5Ni/5+kvcVjMqX9qU0SYWdch8jY5P4eRSbJQ==</DP><DQ>kCr1Kiumn6orNBYZ14gL2aXxrV1ev/YCYZ8Z4+8XyiDxVsVUV+sHi96HO/0QyX4RGBqIydRwvlgXoYR2BHHdAQ==</DQ><InverseQ>CAafwu1Ko1GiOmDGW6hQniKxHeRghyeUqu/5zn8bAjmYMpZV4kCNVxUsGuTfRpPdDeun3zQyrZ86gdDQ2kjqVQ==</InverseQ><D>qNM01MCeT1LlXQLewZjgfaTyNnyUKbSU+UrUGIEmRmx8cEJfcm5iGp23XG0Z9oLIxzx4Kpotw1WDwwoqbKzFuURdjctduvT+cUiy97LDQXFVNY4YyQtEgU6SzxluTtF3yyXpqSeIVOGHuKej4AsoJ1QgVUawn55g0+4VrjfxI0E=</D></RSAKeyValue>";
        #endregion
        #region Get_Startup_Data
        public Startup_Data Get_Startup_Data(Params_Get_Startup_Data i_Params_Get_Startup_Data)
        {
            #region Declaration And Initialization Section.
            Startup_Data oStartup_Data = new Startup_Data();

            Params_Get_Currency_By_OWNER_ID oParams_Get_Currency_By_OWNER_ID = new Params_Get_Currency_By_OWNER_ID();
            Params_GetMenuItems oParams_GetMenuItems = new Params_GetMenuItems();

            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Get_Startup_Data");
            }
            #endregion
            #region Body Section

            // Get All Setup Entries.
            // --------------------------------
            oStartup_Data.My_SetupEntries = new List<SetupEntry>();
            oStartup_Data.My_SetupEntries = GetAllSetupEntries(i_Params_Get_Startup_Data.OWNER_ID);
            // --------------------------------


            // Get Currencies
            // --------------------------------
            oParams_Get_Currency_By_OWNER_ID = new Params_Get_Currency_By_OWNER_ID();
            oParams_Get_Currency_By_OWNER_ID.OWNER_ID = this.OwnerID;
            oStartup_Data.My_Currencies = Get_Currency_By_OWNER_ID(oParams_Get_Currency_By_OWNER_ID);
            // --------------------------------


            // Get Menu [Hierarcy]
            // --------------------------------
            oStartup_Data.My_Menu = new Menu();
            oParams_GetMenuItems.USER_ID = this.UserID;
            oStartup_Data.My_Menu = GetMenuItems(oParams_GetMenuItems);
            // --------------------------------


            // --------------------------------
            var oQuery_Menu = from oItem in _AppContext.TBL_MENU
                              select oItem;

            if (oQuery_Menu != null)
            {
                oStartup_Data.My_Menu_Entries = new List<Menu>();
                foreach (var oRow_Menu in oQuery_Menu)
                {
                    Menu oMenu = new Menu();
                    oMenu.MENU_ID = oRow_Menu.MENU_ID;
                    oMenu.CODE = oRow_Menu.CODE;
                    oMenu.CAPTION_EN = oRow_Menu.CAPTION_EN;
                    oStartup_Data.My_Menu_Entries.Add(oMenu);
                }
            }
            // --------------------------------

            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Get_Startup_Data");
            }
            #endregion
            #region Return Section.
            return oStartup_Data;
            #endregion
        }
        #endregion
        #region Get_Startup_Data_Signature
        public long? Get_Startup_Data_Signature(Params_Get_Startup_Data_Signature i_Params_Get_Startup_Data_Signature)
        {
            #region Declaration And Initialization Section.
            long? i_Return_Value = 0;
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Get_Startup_Data_Signature");
            }
            #endregion
            #region Body Section.
            var q = string.Format("SELECT DBO.UDF_GET_STARTUP_DATA_SIGNATURE({0},{1})", this.OwnerID.ToString(), this.UserID.ToString());
            i_Return_Value = _AppContext.ExecuteQuery<long>(q, new object[] { }).Single();
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Get_Startup_Data_Signature");
            }
            #endregion
            #region Return Section.
            return i_Return_Value;
            #endregion
        }
        #endregion
        #region Setup
        #region EditSetup
        #region EditSetup
        public void EditSetup(SetupEntry i_SetupEntry)
        {
            #region Declaration And Initialization Section.
            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "EditSetup";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                oMethodInfo.Invoke(this, new object[] { i_SetupEntry });
                return;
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("EditSetup");
            }
            #endregion
            #region Body Section.
            i_SetupEntry.ENTRY_USER_ID = this.UserID;
            i_SetupEntry.OWNER_ID = this.OwnerID;
            i_SetupEntry.ENTRY_DATE = oTools.GetDateString(DateTime.Today); 
            _Tools.InvokeMethod(_AppContext, "UP_EDIT_SETUP", i_SetupEntry);
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("EditSetup");
            }
            #endregion
        }
        #endregion
        #endregion
        #region GetSetupEntry
        public SetupEntry GetSetupEntry(SearchSetupEntry i_SearchSetupEntry)
        {
            #region Declaration And Initialization Section.
            DALC.UP_GET_SETUP_ENTRYResult oResult = null;
            SetupEntry oSetupEntry = null;

            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "GetSetupEntry";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return oMethodInfo.Invoke(this, new object[] { i_SearchSetupEntry }) as SetupEntry;
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("GetSetupEntry");
            }
            #endregion
            #region Body Section.
            // oResult = ((ISingleResult<DALC.UP_GET_SETUP_ENTRYResult>)(_Tools.InvokeMethod(_AppContext, "UP_GET_SETUP_ENTRY", i_SearchSetupEntry))).FirstOrDefault();
            var oQuery = from oItem in _AppContext.UP_GET_SETUP_ENTRY(i_SearchSetupEntry.OwnerID, i_SearchSetupEntry.TblName, i_SearchSetupEntry.CodeName)
                         select oItem;

            if (oQuery != null)
            {
                oSetupEntry = new SetupEntry();
                _Tools.CopyPropValues(oQuery.FirstOrDefault(), oSetupEntry);
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("GetSetupEntry");
            }
            #endregion
            #region Return Section.
            return oSetupEntry;
            #endregion
        }
        #endregion
        #region GetSetupEntries
        public List<SetupEntry> GetSetupEntries(SearchSetupEntries i_SearchSetupEntries)
        {
            #region Declaration And Initialization Section.
            List<SetupEntry> oList = new List<SetupEntry>();

            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "GetSetupEntries";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return oMethodInfo.Invoke(this, new object[] { i_SearchSetupEntries }) as List<SetupEntry>;
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("GetSetupEntries");
            }
            #endregion
            #region Body Section.
            var oQuery = from oItem in _AppContext.UP_GET_SETUP_ENTRIES(i_SearchSetupEntries.OwnerID, i_SearchSetupEntries.TblName, i_SearchSetupEntries.IsDeleted, i_SearchSetupEntries.IsVisible)
                         select oItem;

            foreach (var oRow in oQuery)
            {
                SetupEntry oSetupEntry = new SetupEntry();
                _Tools.CopyPropValues(oRow, oSetupEntry);
                oList.Add(oSetupEntry);
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("GetSetupEntries");
            }
            #endregion
            #region Return Section.
            return oList;
            #endregion
        }
        #endregion
        #region GetAllSetupEntries
        public List<SetupEntry> GetAllSetupEntries(Int32? i_OwnerID)
        {
            #region Declaration And Initialization Section.
            List<SetupEntry> oList = new List<SetupEntry>();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "GetAllSetupEntries";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return oMethodInfo.Invoke(this, new object[] { i_OwnerID }) as List<SetupEntry>;
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("GetAllSetupEntries");
            }
            #endregion
            #region Body Section.
            var oQuery = from oItem in _AppContext.TBL_SETUP
                         where
                         (
                            (oItem.OWNER_ID == i_OwnerID) &&
                            (oItem.ISDELETED == false) &&
                            (oItem.ISVISIBLE == true)
                         )
                         select oItem;

            foreach (var oRow in oQuery)
            {
                SetupEntry oSetupEntry = new SetupEntry();
                _Tools.CopyPropValues(oRow, oSetupEntry);
                oList.Add(oSetupEntry);
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("GetAllSetupEntries");
            }
            #endregion
            #region Return Section.
            return oList;
            #endregion
        }
        #endregion
        #region GetDistinctSetupTables
        public List<string> GetDistinctSetupTables(GetSetupEntriesDistinct i_GetSetupEntriesDistinct)
        {
            #region Declaration And Initialization Section.
            List<String> oList = new List<String>();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "GetDistinctSetupTables";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return oMethodInfo.Invoke(this, new object[] { i_GetSetupEntriesDistinct }) as List<String>;
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("GetDistinctSetupTables");
            }
            #endregion
            #region Body Section.
            var oQuery = from oItem in _AppContext.UP_GET_DISTINCT_SETUP_TBL(i_GetSetupEntriesDistinct.OWNER_ID)
                         select oItem;

            foreach (var oRow in oQuery)
            {
                oList.Add(oRow.TBL_NAME);
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("GetDistinctSetupTables");
            }
            #endregion
            #region Return Section.
            return oList;
            #endregion
        }
        #endregion

        #region Get_All_SetupEntries
        public List<SetupEntry> Get_All_SetupEntries(Params_Get_All_SetupEntries i_Params_Get_All_SetupEntries)
        {
            #region Declaration And Initialization Section.
            List<SetupEntry> oList_SetupEntries = new List<SetupEntry>();
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Get_All_SetupEntries");
            }
            #endregion
            #region Body Section.
            oList_SetupEntries = GetAllSetupEntries(i_Params_Get_All_SetupEntries.OWNER_ID);
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Get_All_SetupEntries");
            }
            #endregion
            #region Return Section.
            return oList_SetupEntries;
            #endregion
        }
        #endregion
        #region Get_Distinct_Setup_Tables
        public List<SetupEntry> Get_Distinct_Setup_Tables(Params_Get_Distinct_Setup_Tables i_Params_Get_Distinct_Setup_Tables)
        {
            #region Declaration And Initialization Section.
            List<SetupEntry> oList_Return = new List<SetupEntry>();
            List<string> oList_Distinct = new List<string>();
            GetSetupEntriesDistinct oGetSetupEntriesDistinct = new GetSetupEntriesDistinct();
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Get_Distinct_Setup_Tables");
            }
            #endregion
            #region Body Section.

            oGetSetupEntriesDistinct.OWNER_ID = this.OwnerID;
            oList_Distinct = GetDistinctSetupTables(oGetSetupEntriesDistinct);

            if (oList_Distinct != null)
            {
                foreach (var oRow_Distinct in oList_Distinct)
                {
                    oList_Return.Add(new SetupEntry() { TBL_NAME = oRow_Distinct });
                }
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Get_Distinct_Setup_Tables");
            }
            #endregion
            #region Return Section.
            return oList_Return;
            #endregion
        }
        #endregion
        #region Delete_SetupEntry
        public void Delete_SetupEntry(Params_Delete_SetupEntry i_Params_Delete_SetupEntry)
        {
            #region Declaration And Initialization Section.
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Delete_SetupEntry");
            }
            #endregion
            #region Body Section.
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Delete_SetupEntry");
            }
            #endregion
        }
        #endregion
        #region Get_Setup_Entries_By_TBL_NAME
        public List<SetupEntry> Get_Setup_Entries_By_TBL_NAME(Params_Get_Setup_Entries_By_TBL_NAME i_Params_Get_Setup_Entries_By_TBL_NAME)
        {
            #region Declaration And Initialization Section.
            List<SetupEntry> oList_SetupEntry = new List<SetupEntry>();
            SearchSetupEntries oSearchSetupEntries = new SearchSetupEntries();
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Get_Setup_Entries_By_TBL_NAME");
            }
            #endregion
            #region Body Sectiobn.

            // --------------
            oSearchSetupEntries.OwnerID = this.OwnerID;
            oSearchSetupEntries.TblName = i_Params_Get_Setup_Entries_By_TBL_NAME.TBL_NAME;
            oSearchSetupEntries.IsDeleted = false;
            oSearchSetupEntries.IsVisible = true;
            oList_SetupEntry = GetSetupEntries(oSearchSetupEntries);
            // --------------

            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Get_Setup_Entries_By_TBL_NAME");
            }
            #endregion
            #region Return Section.
            return oList_SetupEntry;
            #endregion
        }
        #endregion
        #region Edit_Setup
        public void Edit_Setup(SetupEntry i_SetupEntry)
        {
            #region Declaration And Initialization Section.
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Edit_Setup");
            }
            #endregion
            #region Body Section.
            EditSetup(i_SetupEntry);
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Edit_Setup");
            }
            #endregion
        }
        #endregion
        #region Get_SetupEntry_By_Code
        public SetupEntry Get_SetupEntry_By_Code(Params_Get_SetupEntry_By_Code i_Params_Get_SetupEntry_By_Code)
        {
            #region Declaration And Initialization Section.
            SetupEntry oSetupEntry = new SetupEntry();
            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Get_SetupEntry_By_Code");
            }
            #endregion
            #region Body Section.
            var oQuery = from oItem in _AppContext.TBL_SETUP
                         where
                         (
                           (oItem.TBL_NAME == i_Params_Get_SetupEntry_By_Code.TBL_NAME) &&
                           (oItem.CODE_NAME == i_Params_Get_SetupEntry_By_Code.CODE_NAME)
                         )
                         select oItem;

            if (oQuery != null)
            {
                oTools.CopyPropValues(oQuery.FirstOrDefault(), oSetupEntry);
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Get_SetupEntry_By_Code");
            }
            #endregion
            #region Return Section.
            return oSetupEntry;
            #endregion
        }
        #endregion
        #region Handle_StaticData_Status
        public void Handle_StaticData_Status()
        {
            #region Declaration And Initialization Section.
            SetupEntry oSetupEntry = null;
            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Handle_StaticData_Status");
            }
            #endregion
            #region Body Section.
            // IS_MODIFIED
            // -----------------------------
            oSetupEntry = new SetupEntry();
            oSetupEntry.TBL_NAME = "_STATIC_DATA";
            oSetupEntry.CODE_NAME = "IS_MODIFIED";
            oSetupEntry.CODE_VALUE_AR = "1";
            oSetupEntry.CODE_VALUE_EN = "1";
            oSetupEntry.CODE_VALUE_FR = "1";
            oSetupEntry.DISPLAY_ORDER = -1;
            oSetupEntry.ENTRY_DATE = oTools.GetDateString(DateTime.Today);
            oSetupEntry.ENTRY_USER_ID = this.UserID;
            oSetupEntry.ISDELETEABLE = false;
            oSetupEntry.ISDELETED = false;
            oSetupEntry.ISSYSTEM = true;
            oSetupEntry.ISUPDATEABLE = true;
            oSetupEntry.ISVISIBLE = true;
            oSetupEntry.NOTES = ".";
            oSetupEntry.OWNER_ID = this.OwnerID;
            EditSetup(oSetupEntry);
            // -----------------------------
            // LAST_MODIFICATION_DATE
            // -----------------------------
            oSetupEntry = new SetupEntry();
            oSetupEntry.TBL_NAME = "_STATIC_DATA";
            oSetupEntry.CODE_NAME = "LAST_MODIFICATION_DATE";
            oSetupEntry.CODE_VALUE_AR = oTools.GetDateString(DateTime.Today);
            oSetupEntry.CODE_VALUE_EN = oTools.GetDateString(DateTime.Today);
            oSetupEntry.CODE_VALUE_FR = oTools.GetDateString(DateTime.Today);
            oSetupEntry.DISPLAY_ORDER = -1;
            oSetupEntry.ENTRY_DATE = oTools.GetDateString(DateTime.Today);
            oSetupEntry.ENTRY_USER_ID = this.UserID;
            oSetupEntry.ISDELETEABLE = false;
            oSetupEntry.ISDELETED = false;
            oSetupEntry.ISSYSTEM = true;
            oSetupEntry.ISUPDATEABLE = true;
            oSetupEntry.ISVISIBLE = true;
            oSetupEntry.NOTES = ".";
            oSetupEntry.OWNER_ID = this.OwnerID;
            EditSetup(oSetupEntry);
            // -----------------------------
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Handle_StaticData_Status");
            }
            #endregion
        }
        #endregion
        #region Resolve_Setup_Entry
        //public string Resolve_Setup_Entry(Params_Resolve_Setup_Entry i_Params_Resolve_Setup_Entry)
        //{
        //    #region Declaration And Initialization Section.
        //    string str_Return_Value = string.Empty;
        //    #endregion
        //    #region Body Section.
        //    str_Return_Value = _AppContext.UF_RESOLVE_SETUP_ENTRY
        //                        (
        //                            i_Params_Resolve_Setup_Entry.OWNER_ID, 
        //                            i_Params_Resolve_Setup_Entry.TBL_NAME, 
        //                            i_Params_Resolve_Setup_Entry.CODE_NAME, 
        //                            i_Params_Resolve_Setup_Entry.LANGUAGE_ABBREVIATION
        //                        );
        //    #endregion
        //    #region Return Section.
        //    return str_Return_Value;
        //    #endregion
        //}
        #endregion
        #region Resolve_Setup_Entry
        public string Resolve_Setup_Entry(string i_TBL_NAME, string i_CODE_NAME, string i_LANGUAGE_ABBREVIATION)
        {
            #region Declaration And Initialization Section.
            string str_Return_Value = string.Empty;
            Params_Resolve_Setup_Entry oParams_Resolve_Setup_Entry = new Params_Resolve_Setup_Entry();
            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region PreEvent_General
            if (this.OnPreEvent_General != null)
            {
                this.OnPreEvent_General("Resolve_Setup_Entry");
            }
            #endregion            
            #region Body Section.

            if (string.IsNullOrEmpty(i_LANGUAGE_ABBREVIATION))
            {
                i_LANGUAGE_ABBREVIATION = "0";
            }

            var query = string.Format
                        (
                            "SELECT DBO.UF_RESOLVE_SETUP_ENTRY({0},'{1}','{2}','{3}')",
                            this.OwnerID.ToString(),
                            i_TBL_NAME,
                            i_CODE_NAME,
                            i_LANGUAGE_ABBREVIATION
                        );
            str_Return_Value = _AppContext.ExecuteQuery<string>(query, new object[] { }).Single();
            #endregion
            #region PostEvent_General
            if (this.OnPostEvent_General != null)
            {
                this.OnPostEvent_General("Resolve_Setup_Entry");
            }
            #endregion            
            #region Return Section.
            return str_Return_Value;
            #endregion
        }
        #endregion
        #endregion       
        #region User
        #region CheckUserExistence
        public bool? CheckUserExistence(Params_CheckUserExistence i_Params_CheckUserExistence)
        {
            #region Declaration And Initialization Section.
            bool? Is_ReturnValue = false;
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "CheckUserExistence";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return oMethodInfo.Invoke(this, new object[] { i_Params_CheckUserExistence }) as Boolean?;
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("CheckUserExistence");
            }
            #endregion
            #region Body Section.
            _AppContext.UP_CHECK_USER_EXISTENCE(i_Params_CheckUserExistence.OwnerID, i_Params_CheckUserExistence.UserName, ref Is_ReturnValue);
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("CheckUserExistence");
            }
            #endregion
            #region Return Section.
            return Is_ReturnValue;
            #endregion
        }
        #endregion
        #region GetUserByCredentials
        public User GetUserByCredentials(SearchUserByCredentials i_SearchUserByCredentials)
        {
            #region Declaration And Initialization Section.
            DALC.UP_GET_USER_BY_CREDENTIALSResult oResult = null;
            User oUser = null;
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "GetUserByCredentials";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return oMethodInfo.Invoke(this, new object[] { i_SearchUserByCredentials }) as User;
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("GetUserByCredentials");
            }
            #endregion
            #region Body Section.
            oResult = ((ISingleResult<DALC.UP_GET_USER_BY_CREDENTIALSResult>)(_Tools.InvokeMethod(_AppContext, "UP_GET_USER_BY_CREDENTIALS", i_SearchUserByCredentials))).FirstOrDefault();

            if (oResult != null)
            {
                if (Hasher.Hasher.VerifyHash(i_SearchUserByCredentials.PASSWORD, "SHA256", oResult.PASSWORD))
                {
                    oUser = new User();
                    _Tools.CopyPropValues(oResult, oUser);
                }
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("GetUserByCredentials");
            }
            #endregion
            #region Return Section.
            return oUser;
            #endregion
        }
        #endregion
        #region Set_Credentials
        public void Set_Credentials(Params_Set_Credentials i_Params_Set_Credentials)
        {
            #region Declaration And Initialization Section.
            User oUser = new User();
            Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();

            Crypto.Crypto oCrypto = new Crypto.Crypto();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "Set_Credentials";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                oMethodInfo.Invoke(this, new object[] { i_Params_Set_Credentials });
                return;
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("Set_Credentials");
            }
            #endregion
            #region Body Section.

            // ------------------
            oParams_Get_User_By_USER_ID.USER_ID = i_Params_Set_Credentials.USER_ID;
            oUser = Get_User_By_USER_ID(oParams_Get_User_By_USER_ID);
            // ------------------

            // ------------------
            if (oUser != null)
            {
                oUser.PASSWORD = oCrypto.Encrypt(i_Params_Set_Credentials.Password, _KeyPublic);
                Edit_User(oUser);
            }
            // ------------------

            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("Set_Credentials");
            }
            #endregion
        }
        #endregion        
        #region Get_Connected_User
        public User Get_Connected_User()
        {
            #region Declaration And Initialization Section.
            User oUser = new User();
            Params_Get_User_By_USER_ID oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
            #endregion
            #region Body Section.
            oParams_Get_User_By_USER_ID = new Params_Get_User_By_USER_ID();
            oParams_Get_User_By_USER_ID.USER_ID = this.UserID;
            oUser = Get_User_By_USER_ID(oParams_Get_User_By_USER_ID);
            #endregion

            #region Return Section.
            return oUser;
            #endregion
        }
        #endregion
        #endregion        
        #region Menu
        #region GetMenuItems
        public Menu GetMenuItems(Params_GetMenuItems i_Params_GetMenuItems)
        {
            #region Declaration And Initialization Section.
            string str_ConnectionString = ConfigurationManager.AppSettings["CONN_STR"].ToString();
            SqlCommand oSqlCommand = null;
            List<Menu> oResult = new List<Menu>();
            string str_Command = string.Empty;
            SqlParameter oSqlParameter = null;
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("GetMenuItems");
            }
            #endregion
            #region Body Section.
            using (SqlConnection oConn = new SqlConnection(str_ConnectionString))
            {
                oConn.Open();

                oSqlCommand = new SqlCommand();
                oSqlCommand.Connection = oConn;
                oSqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                oSqlCommand.CommandText = "[UP_GET_USER_MENU]";

                oSqlParameter = new SqlParameter();
                oSqlParameter.ParameterName = "P__USER_ID";
                oSqlParameter.SqlDbType = System.Data.SqlDbType.BigInt;
                oSqlParameter.Value = i_Params_GetMenuItems.USER_ID;

                oSqlCommand.Parameters.Add(oSqlParameter);

                using (var oSqlDataReader = oSqlCommand.ExecuteReader())
                {
                    while (oSqlDataReader.Read())
                    {
                        Menu oMenu = new Menu
                        {
                            HID = SqlHierarchyId.Parse(oSqlDataReader.GetSqlString(0)),
                            MENU_ID = oSqlDataReader.GetInt32(1),
                            CODE = oSqlDataReader.GetString(2),
                            ACTION = oSqlDataReader.GetString(3),
                            ICON = oSqlDataReader.GetString(4),
                            CAPTION_EN = oSqlDataReader.GetString(5),
                            CAPTION_FR = oSqlDataReader.GetString(6),
                            CAPTION_AR = oSqlDataReader.GetString(7)
                        };

                        oResult.Add(oMenu);

                        foreach (Menu parent in oResult.Where(r => r.HID.Equals(oMenu.HID.GetAncestor(1))))
                        {
                            parent.Children.Add(oMenu);
                        }
                    }
                }
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("GetMenuItems");
            }
            #endregion
            #region Return Section.
            return oResult.Count() > 0 ? oResult[0] : null;
            #endregion
        }
        #endregion
        #endregion
        #region Inc
        public long? GetNextValue(Int32? i_OwnerID, string i_StarterCode)
        {
            #region Declaration And Initialization Section.
            long? l_ReturnValue = -1;
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "GetNextValue";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return oMethodInfo.Invoke(this, new object[] { i_OwnerID, i_StarterCode }) as Int64?;
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("GetNextValue");
            }
            #endregion
            #region Body Section.
            _AppContext.UP_GET_NEXT_VALUE(i_StarterCode, ref l_ReturnValue);
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("GetNextValue");
            }
            #endregion
            #region Return Section.
            return l_ReturnValue;
            #endregion
        }
        #endregion
        #region Authentication
        #region IsAuthenticated
        public void IsAuthenticated(UserInfo i_UserInfo)
        {
            #region Declaration And Initialization Section.
            Crypto.Crypto oCrypto = new Crypto.Crypto();
            string str_Ticket_PlainText = string.Empty;
            string str_Ticket_Encrypted = string.Empty;
            Int32? i_ExpiryPeriod = 240; // In Minutes
            long? i_MinutesElapsedSinceMidnight = 0;
            Tools.Tools oTools = new Tools.Tools();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "IsAuthenticated";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                oMethodInfo.Invoke(this, new object[] { i_UserInfo });
                return;
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("IsAuthenticated");
            }
            #endregion
            #region Body Section.
            var oQuery = from oItem in _AppContext.TBL_USER
                         where
                            (
                                (oItem.USERNAME == i_UserInfo.UserName)
                            )
                         select oItem;

            if (oQuery.Count() == 1)
            {
                var oResult = oQuery.First();
                if (oCrypto.Decrypt(oResult.PASSWORD, _KeySet) == i_UserInfo.Password)
                {
                    // ------------------------------
                    i_UserInfo.IsAuthenticated = true;
                    i_UserInfo.UserID = oResult.USER_ID;
                    i_UserInfo.OwnerID = oResult.OWNER_ID;
                    // ------------------------------
                                     


                    // ------------------------------
                    this.UserID = i_UserInfo.UserID;
                    this.OwnerID = i_UserInfo.OwnerID;
                    // ------------------------------


                    // ------------------------------
                    i_MinutesElapsedSinceMidnight = (long?)(DateTime.Now - DateTime.Today).TotalMinutes;
                    str_Ticket_PlainText = string.Format("USER_ID:{0}[~!@]OWNER_ID:{1}[~!@]START_DATE:{2}[~!@]START_MINUTE:{3}[~!@]SESSION_PERIOD:{4}", i_UserInfo.UserID.ToString(), i_UserInfo.OwnerID.ToString(), oTools.GetDateString(DateTime.Today), i_MinutesElapsedSinceMidnight.ToString(), i_ExpiryPeriod.ToString());
                    str_Ticket_Encrypted = oCrypto.Encrypt(str_Ticket_PlainText, _KeyPublic);
                    i_UserInfo.Ticket = str_Ticket_Encrypted;
                    // ------------------------------

                }
                else
                {
                    throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_9999));
                }
            }
            else
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_9999));
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("IsAuthenticated");
            }
            #endregion
        }
        #endregion
        #region IsAuthenticated_JSON
        public UserInfo IsAuthenticated_JSON(Params_IsAuthenticated i_Params_IsAuthenticated)
        {
            #region Declaration And Initialization Section.
            Crypto.MiniCryptoHelper oCrypto = new Crypto.MiniCryptoHelper();
            string str_Ticket_PlainText = string.Empty;
            string str_Ticket_Encrypted = string.Empty;
            Int32? i_ExpiryPeriod = 240; // In Minutes
            long? i_MinutesElapsedSinceMidnight = 0;
            Tools.Tools oTools = new Tools.Tools();

            #endregion
            #region Body Section.
            var oQuery = from oItem in _AppContext.TBL_USER
                         where
                            (
                                (oItem.USERNAME == i_Params_IsAuthenticated.My_UserInfo.UserName)
                            )
                         select oItem;

            if (oQuery.Count() == 1)
            {
                var oResult = oQuery.First();
                if 
                    (                                       
                        (oCrypto.Decrypt(oResult.PASSWORD) == i_Params_IsAuthenticated.My_UserInfo.Password)
                    )
                {
                    // ------------------------------
                    i_Params_IsAuthenticated.My_UserInfo.IsAuthenticated = true;
                    i_Params_IsAuthenticated.My_UserInfo.UserID = oResult.USER_ID;
                    i_Params_IsAuthenticated.My_UserInfo.OwnerID = oResult.OWNER_ID;
                    // ------------------------------


                    // ------------------------------
                    this.UserID = i_Params_IsAuthenticated.My_UserInfo.UserID;
                    this.OwnerID = i_Params_IsAuthenticated.My_UserInfo.OwnerID;
                    // ------------------------------


                    // ------------------------------
                    i_MinutesElapsedSinceMidnight = (long?)(DateTime.Now - DateTime.Today).TotalMinutes;
                    str_Ticket_PlainText = string.Format("USER_ID:{0}[~!@]OWNER_ID:{1}[~!@]START_DATE:{2}[~!@]START_MINUTE:{3}[~!@]SESSION_PERIOD:{4}", i_Params_IsAuthenticated.My_UserInfo.UserID.ToString(), i_Params_IsAuthenticated.My_UserInfo.OwnerID.ToString(), oTools.GetDateString(DateTime.Today), i_MinutesElapsedSinceMidnight.ToString(), i_ExpiryPeriod.ToString());
                    //str_Ticket_Encrypted = oCrypto.Encrypt(str_Ticket_PlainText, _KeyPublic);
                    str_Ticket_Encrypted = str_Ticket_PlainText;
                    i_Params_IsAuthenticated.My_UserInfo.Ticket = str_Ticket_Encrypted;
                    // ------------------------------


                }
                else
                {
                    throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_9999));
                }
            }
            else
            {
                throw new BLCException(GetMessageContent(Enum_BR_Codes.BR_9999));
            }
            #endregion
            #region Return Section.
            return i_Params_IsAuthenticated.My_UserInfo;
            #endregion
        }
        #endregion        
        #region ResolveTicket
        public Dictionary<string, string> ResolveTicket(string i_Input)
        {
            #region Declaration And Initialization Section.
            Dictionary<string, string> oList = new Dictionary<string, string>();
            string str_Ticket_PlainText = string.Empty;
            Crypto.Crypto oCrypto = new Crypto.Crypto();
            string[] oMainTempList = null;
            string[] oSubTempList = null;
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("ResolveTicket");
            }
            #endregion
            #region Body Section.
            if (!string.IsNullOrEmpty(i_Input))
            {
                //str_Ticket_PlainText = oCrypto.Decrypt(i_Input, _KeySet);
                str_Ticket_PlainText = i_Input;

                if (!string.IsNullOrEmpty(str_Ticket_PlainText))
                {
                    oMainTempList = str_Ticket_PlainText.Split(new string[] { "[~!@]" }, StringSplitOptions.RemoveEmptyEntries);

                    var oQuery = from oItem in oMainTempList
                                 select oItem;

                    foreach (var oRow in oQuery)
                    {
                        oSubTempList = oRow.Split(new string[] { ":" }, StringSplitOptions.None);
                        oList.Add(oSubTempList[0], oSubTempList[1]);
                    }
                }
            }
            else
            {
                oList.Add("USER_ID", "1");
                oList.Add("OWNER_ID", "1");
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("ResolveTicket");
            }
            #endregion
            #region Return Section.
            return oList;
            #endregion
        }
        #endregion
        #region IsValidTicket
        public bool IsValidTicket(string i_Input)
        {
            #region Declaration And Initialization Section.
            bool Is_ValidTicket = false;
            long? i_MinutesElapsedSinceMidnight = 0;
            string str_CurrentDate = string.Empty;
            Tools.Tools oTools = new Tools.Tools();
            Dictionary<string, string> oTicketParts = new Dictionary<string, string>();
            #endregion
            #region Environment Related Code Handling
            Params_GetEnvCode oParams_GetEnvCode = new Params_GetEnvCode();
            oParams_GetEnvCode.My_Environment = this.Environment;
            oParams_GetEnvCode.My_MethodName = "IsValidTicket";
            oParams_GetEnvCode.My_Type = typeof(BLC);
            MethodInfo oMethodInfo = EnvCode.GetEnvCode(oParams_GetEnvCode);
            if (oMethodInfo != null)
            {
                return Convert.ToBoolean(oMethodInfo.Invoke(this, new object[] { i_Input }));
                // Intentially Left Empty.
            }
            #endregion
            #region PreEvent_General
            if (OnPreEvent_General != null)
            {
                OnPreEvent_General("IsValidTicket");
            }
            #endregion
            #region Body Section.
            try
            {
                oTicketParts = ResolveTicket(i_Input);
                str_CurrentDate = oTools.GetDateString(DateTime.Today);

                if (oTicketParts["START_DATE"] == str_CurrentDate) // Session Started In Different Day.
                {
                    i_MinutesElapsedSinceMidnight = (long?)(DateTime.Now - DateTime.Today).TotalMinutes;

                    if (i_MinutesElapsedSinceMidnight <= Convert.ToInt32(oTicketParts["START_MINUTE"]) + Convert.ToInt32(oTicketParts["SESSION_PERIOD"]))
                    {
                        Is_ValidTicket = true;
                    }
                }

            }
            catch (Exception ex)
            {
                Is_ValidTicket = false;
            }
            #endregion
            #region PostEvent_General
            if (OnPostEvent_General != null)
            {
                OnPostEvent_General("IsValidTicket");
            }
            #endregion
            #region Return Section.
            return Is_ValidTicket;
            #endregion
        }
        #endregion
        #endregion        
    }
    #region Business Entities
    #region Setup
    #region SetupEntry
    public class SetupEntry
    {
        #region Properties
        public Int32? OWNER_ID { get; set; }
        public string TBL_NAME { get; set; }
        public string CODE_NAME { get; set; }
        public bool? ISSYSTEM { get; set; }
        public bool? ISDELETEABLE { get; set; }
        public bool? ISUPDATEABLE { get; set; }
        public bool? ISVISIBLE { get; set; }
        public bool? ISDELETED { get; set; }
        public Int32? DISPLAY_ORDER { get; set; }
        public string CODE_VALUE_EN { get; set; }
        public string CODE_VALUE_FR { get; set; }
        public string CODE_VALUE_AR { get; set; }
        public string ENTRY_DATE { get; set; }
        public long? ENTRY_USER_ID { get; set; }
        public string NOTES { get; set; }

        public string INVARIANT_VALUE { get; set; }
        #endregion
    }
    #endregion
    #region SearchSetupEntry
    public class SearchSetupEntry
    {
        #region Properties
        public Int32? OwnerID { get; set; }
        public string TblName { get; set; }
        public string CodeName { get; set; }
        #endregion
    }
    #endregion
    #region SearchSetupEntries
    public class SearchSetupEntries
    {
        #region Properties
        public Int32? OwnerID { get; set; }
        public string TblName { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? IsVisible { get; set; }
        #endregion
    }
    #endregion
    #region GetSetupEntriesDistinct
    public class GetSetupEntriesDistinct
    {
        #region Properties
        public Int32? OWNER_ID { get; set; }
        #endregion
    }
    #endregion
    #region Params_Get_Distinct_Setup_Tables
    public partial class Params_Get_Distinct_Setup_Tables
    {
        #region Properties.
        #endregion
    }
    #endregion
    #region Params_Delete_SetupEntry
    public partial class Params_Delete_SetupEntry
    {
        #region Properties.
        #endregion
    }
    #endregion
    #region Params_Get_Setup_Entries_By_TBL_NAME
    public partial class Params_Get_Setup_Entries_By_TBL_NAME
    {
        #region Properties.
        public string TBL_NAME { get; set; }
        #endregion
    }
    #endregion
    #region Params_Get_SetupEntry_By_Code
    public partial class Params_Get_SetupEntry_By_Code
    {
        #region Properties.
        public string TBL_NAME { get; set; }
        public string CODE_NAME { get; set; }
        #endregion
    }
    #endregion
    #region Params_Get_All_SetupEntries
    public partial class Params_Get_All_SetupEntries
    {
        #region Properties.
        public Int32? OWNER_ID { get; set; }
        #endregion
    }
    #endregion
    #region Params_Resolve_Setup_Entry
    public partial class Params_Resolve_Setup_Entry
    {
        #region Properties.
        public Int32? OWNER_ID { get; set; }
        public string TBL_NAME { get; set; }
        public string CODE_NAME { get; set; }
        public string LANGUAGE_ABBREVIATION { get; set; }
        #endregion
    }
    #endregion
    #endregion
    #region Currency
    #region Params_Get_Reference_Currency
    public partial class Params_Get_Reference_Currency
    {
        #region Properties.
        public string DATE_REFERENCE { get; set; }
        #endregion
    }
    #endregion
    #region Params_Get_Local_Currency
    public partial class Params_Get_Local_Currency
    {
        #region Properties.
        public string DATE_REFERENCE { get; set; }
        #endregion
    }
    #endregion
    #region Params_Get_Exchange_Rate
    public partial class Params_Get_Exchange_Rate
    {
        #region Properties.
        public Int32? SRC_CURRENCY_ID { get; set; }
        public Int32? DEST_CURRENCY_ID { get; set; }
        #endregion
    }
    #endregion
    #region Params_Get_Currency_Light
    public partial class Params_Get_Currency_Light
    {
        #region Properties.
        #endregion
    }
    #endregion
    #region Params_Update_Currencies_Rate
    public partial class Params_Update_Currencies_Rate
    {
        #region Properties.
        #endregion
    }
    #endregion
    #endregion
    #region User
    #region User
    public partial class User
    {
        #region Properties
        public Owner My_Owner { get; set; }
        #endregion
    }
    #endregion
    #region UserInfo
    public class UserInfo
    {
        #region Properties
        public long? UserID { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public bool IsAuthenticated { get; set; }
        public BLC.Enum_Language Language { get; set; }
        public Int32? OwnerID { get; set; }
        public string Ticket { get; set; }
        //public List<User_type> My_User_Type { get; set; }
        #endregion
    }
    #endregion
    #region SearchUserByCredentials
    public class SearchUserByCredentials
    {
        #region Properties
        public Int32? OWNER_ID { get; set; }
        public string USERNAME { get; set; }
        public string PASSWORD { get; set; }
        #endregion
    }
    #endregion
    #region Params_CheckUserExistence
    public class Params_CheckUserExistence
    {
        #region Properties
        public Int32? OwnerID { get; set; }
        public string UserName { get; set; }
        #endregion
    }
    #endregion
    #region Params_Set_Credentials
    public partial class Params_Set_Credentials
    {
        #region Properties.
        public Int64? USER_ID { get; set; }
        public string Password { get; set; }
        #endregion
    }
    #endregion
    #region Params_ReIssue_Password
    public partial class Params_ReIssue_Password
    {
        #region Properties.
        public Int64? PERSON_ID { get; set; }
        #endregion
    }
    #endregion
    #endregion    
    #region Menu
    #region Params_GetMenuItems
    public partial class Params_GetMenuItems
    {
        #region Properties.
        public Int64? USER_ID { get; set; }
        #endregion
    }
    #endregion
    #endregion
    #region Startup_Data
    #region Startup_Data
    public partial class Startup_Data
    {
        #region Properties.
        public List<SetupEntry> My_SetupEntries { get; set; }
        public List<User> My_Users { get; set; }
        public List<Currency> My_Currencies { get; set; }
        public Menu My_Menu { get; set; }
        public List<Menu> My_Menu_Entries { get; set; }
        #endregion
    }
    #endregion
    #region Params_Get_Startup_Data
    public partial class Params_Get_Startup_Data
    {
        #region Properties.
        public Int32? OWNER_ID { get; set; }
        public Int32? FISCAL_YEAR_ID { get; set; }
        #endregion
    }
    #endregion
    #region Params_Get_Startup_Data_Signature
    public partial class Params_Get_Startup_Data_Signature
    {
        #region Properties.
        public Int32 OWNER_ID { get; set; }
        #endregion
    }
    #endregion
    #endregion
    #region Authentication
    #region Params_IsAuthenticated
    public partial class Params_IsAuthenticated
    {
        #region Properties.
        public UserInfo My_UserInfo { get; set; }
        #endregion
    }
    #endregion
    #region Params_Forgot_Password
    public partial class Params_Forgot_Password
    {
        #region Properties.
        public string USERNAME { get; set; }
        #endregion
    }
    #endregion
    #endregion    
    #region Enumerations
    #region Enum_Value_Mode
    public enum Enum_Value_Mode
    {
        VALUE,
        PERCENTAGE
    }
    #endregion/    
    #endregion
    #endregion
}


