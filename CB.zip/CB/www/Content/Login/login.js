﻿/**************************************************/
var _Startup_Data_Signature = "";
/**************************************************/


/**************************************************/
var _Params_IsAuthenticated = new Object();

var lbl_ErrorMessage = $("#lbl_ErrorMessage");


var _Params_Get_Startup_Data_Signature = new Object();
_Params_Get_Startup_Data_Signature.OWNER_ID = 1;

var _Params_Get_Startup_Data = new Object();
_Params_Get_Startup_Data.OWNER_ID = 1;
_Params_Get_Startup_Data.FISCAL_YEAR_ID = 1;

_Params_IsAuthenticated.My_UserInfo = new Object();
/**************************************************/


/**************************************************/
$(document).ready(function () {

    if (localStorage["_USER_NAME"] != null) {
        $("#Login1_UserName").val(localStorage["_USER_NAME"]);
        $("#Cbx_RememberMe").attr('checked', true);
    }

    $("#Lk_ForgotPwd").click(function () {
        $("#Lk_ForgotPwd").hide();
        $("#Login1_LoginButton").hide();
        $("#Lbl_RemeberMe").hide();
        $("#Login1_Password").hide();
        $("#Lbl_Password").hide();
        $("#Btn_ForgotPwd").show();
        $("#Lk_Return_To_Login").show();
    });

    $("#Lk_Return_To_Login").click(function () {
        $("#Lk_ForgotPwd").show();
        $("#Login1_LoginButton").show();
        $("#Lbl_RemeberMe").show();
        $("#Login1_Password").show();
        $("#Lbl_Password").show();
        $("#Btn_ForgotPwd").hide();
        $("#Lk_Return_To_Login").hide();
    });


    $("#Login1_UserName").keyup(function (event) {
        if (event.keyCode == 13) {
            $("#Login1_LoginButton").click();
        }
    });

    $("#Login1_Password").keyup(function (event) {
        if (event.keyCode == 13) {
            $("#Login1_LoginButton").click();
        }
    });

    $("#Login1_LoginButton").click
      (
         function () {
             var IsReady = true;
             if ($("#Login1_UserName").val().trim() == "") {
                 $("#Login1_UserNameRequired").show();
                 IsReady = false;
             }
             else {
                 $("#Login1_UserNameRequired").hide();
             }

             if ($("#Login1_Password").val().trim() == "") {
                 $("#Login1_PasswordRequired").show();
                 IsReady = false;
             }
             else {
                 $("#Login1_PasswordRequired").hide();
             }
             if (IsReady) {
                 IsAuthenticated_JSON();
             }
             return false;
         }
      );

    $("#Btn_ForgotPwd").click(function () {
        var Params_Forgot_Password = new Object();
        Params_Forgot_Password.USERNAME = $("#Login1_UserName").val();

        _Params = JSON.stringify(Params_Forgot_Password);        
        _Service_Method = "Forgot_Password";

        var Forgot_Password_Success = function (i_Result) {
            alert("An email has been sent you to containing your password");
        }

        CallService_Element(Forgot_Password_Success, null);
    });
}
);
/**************************************************/

/**************************************************/
function IsAuthenticated_JSON() {
    try {
        _Params_IsAuthenticated.My_UserInfo = new Object();

        _Params_IsAuthenticated.My_UserInfo.UserName = $("#Login1_UserName").val();
        _Params_IsAuthenticated.My_UserInfo.Password = $("#Login1_Password").val();

        _Params = JSON.stringify(_Params_IsAuthenticated);

        _Service_Method = "IsAuthenticated_JSON";
        CallService(IsAuthenticated_JSON_Completed, Service_Call_InCompleted);

    }
    catch (e) {
        alert("IsAuthenticated_JSON: " + e.Message);
    }
}
/**************************************************/


/**************************************************/
function Get_Startup_Data_Signature(i_OWNER_ID) {
    try {

        _Params_Get_Startup_Data_Signature.OWNER_ID = i_OWNER_ID;

        _Params = JSON.stringify(_Params_Get_Startup_Data_Signature);

        _Service_Method = "Get_Startup_Data_Signature";

        CallService(Get_Startup_Data_Signature_Completed, Service_Call_InCompleted);
    }
    catch (e) {
        alert("Get_Startup_Data_Signature: " + e.Message);
    }
}
/**************************************************/



/**************************************************/
function Get_Startup_Data(i_OWNER_ID, i_FISCAL_YEAR_ID) {
    try {
        _Params_Get_Startup_Data.OWNER_ID = i_OWNER_ID;
        _Params_Get_Startup_Data.FISCAL_YEAR_ID = i_FISCAL_YEAR_ID;

        _Params = JSON.stringify(_Params_Get_Startup_Data);

        _Service_Method = "Get_Startup_Data";

        CallService(Get_Startup_Data_Completed, Service_Call_InCompleted);
    }
    catch (e) {
        alert("Get_Startup_Data: " + e.Message);
    }
}
/**************************************************/

/**************************************************/
function IsAuthenticated_JSON_Completed(i_Input) {
    try {        
        localStorage.setItem("UserInfo", JSON.stringify(i_Input.My_Result));
        if (localStorage.getItem('UserInfo') != null) {
            _UserInfo = JSON.parse(localStorage.getItem('UserInfo'));
            _Ticket = _UserInfo.Ticket;

            if ($("#Cbx_RememberMe").is(':checked') == true) {
                localStorage.setItem("_USER_NAME", $("#Login1_UserName").val());
            }
            else {
                localStorage.removeItem("_USER_NAME");
            }

        }
        Get_Startup_Data_Signature(_UserInfo.OwnerID);
    }
    catch (e) {
        alert("IsAuthenticated_JSON_Completed :" + e.Message);
    }
}
/**************************************************/



/**************************************************/
function Get_Startup_Data_Signature_Completed(i_Input) {
    try {
        _Startup_Data_Signature = i_Input.My_Result;
        localStorage.setItem("_Startup_Data_Signature", null)
        if (localStorage.getItem("_Startup_Data_Signature") != _Startup_Data_Signature) {
            localStorage.setItem("_Startup_Data_Signature", _Startup_Data_Signature)
            Get_Startup_Data(_UserInfo.OwnerID, _UserInfo.UserID);
        }
        else {
            window.location.href = "../index.html";
        }

    }
    catch (e) {
        alert("Get_Startup_Data_Signature_Completed: " + e.Message);
    }
}
/**************************************************/


/**************************************************/
function Get_Startup_Data_Completed(i_Input) {
    try {

        // Setup Entries
        // ---------------       
        localStorage.setItem("SetupEntries", JSON.stringify(i_Input.My_Result.My_SetupEntries));
        // ---------------
              

        // Menu [Single Object Hierarchy]
        // ---------------
        localStorage.setItem("Menu", JSON.stringify(i_Input.My_Result.My_Menu));
        // ---------------

        // Menu [Flat]
        // ---------------
        localStorage.setItem("Menu_Entries", JSON.stringify(i_Input.My_Result.My_Menu_Entries));
        // ---------------     

        // ---------------
        window.location.href = "../Default/Default.aspx";
        // ---------------        


    }
    catch (e) {
        alert("Get_Startup_Data_Completed: " + e.Message);
    }
}
/* --------------------------------------------------------------- */
