/**************************************************/
function DocumentSearchModel
(
	_REL_KEY,
	_REL_ENTITY) {
    var self = this;

    self.REL_KEY = ko.observable(_REL_KEY);
    self.REL_ENTITY = ko.observable(_REL_ENTITY);
}
/**************************************************/

/**************************************************/
function DocumentModel
(
	_DOCUMENT_ID,
	_NAME,
	_REL_KEY,
	_REL_ENTITY,
	_PATH,
    _My_Virtual_Path,
	_DESCRIPTION,
	_ENTRY_USER_ID,
	_ENTRY_DATE,
	_OWNER_ID) {
    var self = this;

    self.DOCUMENT_ID = ko.observable(_DOCUMENT_ID);
    self.NAME = ko.observable(_NAME);
    self.REL_KEY = ko.observable(_REL_KEY);
    self.REL_ENTITY = ko.observable(_REL_ENTITY);
    self.PATH = ko.observable(_PATH);
    self.My_Virtual_Path = ko.observable(_My_Virtual_Path);
    self.DESCRIPTION = ko.observable(_DESCRIPTION);
    self.ENTRY_USER_ID = ko.observable(_ENTRY_USER_ID);
    self.ENTRY_DATE = ko.observable(_ENTRY_DATE);
    self.OWNER_ID = ko.observable(_OWNER_ID);

    self.errors = ko.validation.group(self);
}
/**************************************************/

/**************************************************/
function DocumentViewModel() {

    /**************************************************/
    var self = this;
    /**************************************************/

    /**************************************************/
    self.Documents = ko.mapping.fromJS([]);
    /**************************************************/

    /**************************************************/
    self.Exceeds_Limit = ko.mapping.fromJS(false);
    /**************************************************/

    
    /**************************************************/
    self.DocumentSM = new DocumentSearchModel
		(
			sessionStorage["selected_REL_KEY"] /* REL_KEY */
		,
			sessionStorage["selected_REL_ENTITY"] /* REL_ENTITY */
		);
    /**************************************************/

    /**************************************************/
    self.uploadDocument = function () {
        
    }
    /**************************************************/

    /**************************************************/
    self.Check_Building_Documents_Size_Exceedence = function () {

        /* ---------------- */
        var Params_Check_Building_Documents_Size_Exceedence_Success = new Object();
        Params_Check_Building_Documents_Size_Exceedence_Success.BUILDING_ID = sessionStorage["selected_REL_KEY"];
        /* ---------------- */

        /* ---------------- */
        var Check_Building_Documents_Size_Exceedence_Success = function () {
            self.Exceeds_Limit(false);
        }

        var Check_Building_Documents_Size_Exceedence_Failure = function () {           
            self.Exceeds_Limit(true);
        }
        /* ---------------- */

        /* ---------------- */
        _Params = ko.mapping.toJSON(Params_Check_Building_Documents_Size_Exceedence_Success);
        _Service_Method = "Check_Building_Documents_Size_Exceedence";
        CallService_Element(Check_Building_Documents_Size_Exceedence_Success, Check_Building_Documents_Size_Exceedence_Failure);
        /* ---------------- */

    }
    /**************************************************/

    /**************************************************/
    self.SearchDocument = function () {
        /* ---------------- */
        var Get_Document_By_REL_KEY_REL_ENTITY_Success = function (i_Response) {

            self.Documents
			(
				ko.utils.arrayMap(i_Response.My_Result, function (Document) {
				    return new DocumentModel
					(
						Document.DOCUMENT_ID,
						Document.NAME,
						Document.REL_KEY,
						Document.REL_ENTITY,
						Document.PATH,
                        Document.My_Virtual_Path,
						Document.DESCRIPTION,
						Document.ENTRY_USER_ID,
						Document.ENTRY_DATE,
						Document.OWNER_ID)
				}));
        }
        /* ---------------- */

        /* ---------------- */
        var Get_Document_By_REL_KEY_REL_ENTITY_Failure = function () { }
        /* ---------------- */

        /* ---------------- */
        _Params = ko.mapping.toJSON(self.DocumentSM);        
        _Service_Method = "Get_Document_By_REL_KEY_REL_ENTITY";
        CallService_Element(Get_Document_By_REL_KEY_REL_ENTITY_Success, Get_Document_By_REL_KEY_REL_ENTITY_Failure);
        /* ---------------- */

    }
    /**************************************************/

    /**************************************************/
    self.addDocument = function () {

        var js_Close_Handler = function () { self.SearchDocument(); };
        jq_OpenUIDialog('../FileUploader/FileUploader.html', "Uploader", 450, 150, js_Close_Handler);
        return;

        var match = ko.utils.arrayFirst(self.Documents(), function (item) {
            return item.DOCUMENT_ID() == -1;
        });

        if (match == null) {
            var document = new DocumentModel
				(
					-1,
					'' /* NAME */
				,
					0 /* REL_KEY */
				,
					'' /* REL_ENTITY */
				,
					'' /* PATH */
				,
					'' /* DESCRIPTION */
				,
					0 /* ENTRY_USER_ID */
				,
					'' /* ENTRY_DATE */
				,
					0 /* OWNER_ID */
				);
            self.Documents.unshift(document);
        }
    }
    /**************************************************/

    /**************************************************/
    self.saveDocument = function (document) {
        if (document.errors().length == 0) {
            _Params = ko.toJSON(document);
            _Service_Method = "Edit_Document";
            var Edit_SuccessHandler = function (Srv_Response) {
                var index = self.Documents.indexOf(document);
                self.Documents.splice
				(
					index,
					1,
					new DocumentModel
					(
						Srv_Response.My_Document.DOCUMENT_ID,
						Srv_Response.My_Document.NAME,
						Srv_Response.My_Document.REL_KEY,
						Srv_Response.My_Document.REL_ENTITY,
						Srv_Response.My_Document.PATH,
                        "",
						Srv_Response.My_Document.DESCRIPTION,
						Srv_Response.My_Document.ENTRY_USER_ID,
						Srv_Response.My_Document.ENTRY_DATE,
						Srv_Response.My_Document.OWNER_ID));
            };
            CallService_Element(Edit_SuccessHandler, null);
        } else {
            document.errors.showAllMessages();
        }
    };
    /**************************************************/

    /**************************************************/
    self.removeDocument = function (document) {
        /* Prepare OK & CANCEL handlers for Confirmation Message */
        /* ------------------------------------------------------------------*/
        var OK_Handler = function () {
            if (document.DOCUMENT_ID != -1) {
                var _Params_Delete_Document = new Object();
                _Params_Delete_Document.DOCUMENT_ID = document.DOCUMENT_ID;
                _Params = ko.toJSON(_Params_Delete_Document);
                _Service_Method = "Delete_Document";

                var Delete_SuccessHandler = function () {
                    self.Documents.remove(document);
                };
                CallService_Element(Delete_SuccessHandler, null);
            } else {
                self.Documents.remove(document);
            }
        };

        var CANCEL_Handler = function () { };
        /* ------------------------------------------------------------------*/

        /* Display Confirmation Message */
        /* ------------------------------------------------------------------*/
        if (confirm(_GLB_MSG_DELETE_CONFIRM)) {
            OK_Handler();
        } else {
            CANCEL_Handler();
        }
        /* ------------------------------------------------------------------*/
    };

    /**************************************************/
}
/**************************************************/

/************************************************/
var MyVM = null;
/************************************************/

/************************************************/
$(document).ready
(
	function () {
	    MyVM = new DocumentViewModel();
	    ko.applyBindings(MyVM);
	    setTimeout
        (
        function () {

            // ---------------          
            MyVM.SearchDocument();
            // ---------------          

            // ---------------          
            if (sessionStorage["selected_REL_ENTITY"] == "TBL_BUILDING") {
                MyVM.Check_Building_Documents_Size_Exceedence();
            }
            // ---------------
         }, 
        500
        );
	});
/************************************************/
