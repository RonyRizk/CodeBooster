
/**************************************************/
function Login_historySearchModel
(
	_OWNER_ID,
	_USERNAME,
	_PASSWORD,
	_LOGIN_STATUS_CODE,
	_START_ROW,
	_END_ROW,
	_TOTAL_COUNT) {
    var self = this;

    self.OWNER_ID = ko.observable(_OWNER_ID);
    self.USERNAME = ko.observable(_USERNAME);
    self.PASSWORD = ko.observable(_PASSWORD);
    self.LOGIN_STATUS_CODE = ko.observable(_LOGIN_STATUS_CODE);
    self.START_ROW = ko.observable(_START_ROW);
    self.END_ROW = ko.observable(_END_ROW);
    self.TOTAL_COUNT = ko.observable(_TOTAL_COUNT);
}
/**************************************************/

/**************************************************/
function Login_historyModel
(
	_LOGIN_HISTORY_ID,
	_USERNAME,
	_PASSWORD,
	_LOGIN_STATUS_CODE,
	_LOGIN_DATE,
	_LOGIN_HOUR,
	_LOGIN_MINUTE,
	_LOGIN_SECOND,
	_ENTRY_USER_ID,
	_ENTRY_DATE,
	_OWNER_ID) {
    var self = this;

    self.LOGIN_HISTORY_ID = ko.observable(_LOGIN_HISTORY_ID);
    self.USERNAME = ko.observable(_USERNAME);
    self.PASSWORD = ko.observable(_PASSWORD);
    self.LOGIN_STATUS_CODE = ko.observable(_LOGIN_STATUS_CODE);
    self.LOGIN_DATE = ko.observable(_LOGIN_DATE);
    self.LOGIN_HOUR = ko.observable(_LOGIN_HOUR);
    self.LOGIN_MINUTE = ko.observable(_LOGIN_MINUTE);
    self.LOGIN_SECOND = ko.observable(_LOGIN_SECOND);
    self.ENTRY_USER_ID = ko.observable(_ENTRY_USER_ID);
    self.ENTRY_DATE = ko.observable(_ENTRY_DATE);
    self.OWNER_ID = ko.observable(_OWNER_ID);

    self.errors = ko.validation.group(self);
}
/**************************************************/

/**************************************************/
function Login_historyViewModel() {

    /**************************************************/
    var self = this;
    /**************************************************/

    /**************************************************/
    self.Login_historys = ko.mapping.fromJS([]);
    /**************************************************/

    /**************************************************/
    self.Login_historySM = new Login_historySearchModel
		(
			0 /* OWNER_ID */
		,
			'' /* USERNAME */
		,
			'' /* PASSWORD */
		,
			'' /* LOGIN_STATUS_CODE */
		,
			0 /* START_ROW */
		,
			0 /* END_ROW */
		,
			0 /* TOTAL_COUNT */
		);
    /**************************************************/

    /**************************************************/
    self.PAGINATION_NBR = ko.observable(_List_Pagination()[0].CODE_VALUE_EN);
    self.Login_historySM.END_ROW(self.PAGINATION_NBR());

    self.PAGINATION_NBR.subscribe(function (newVal) {
        if (newVal != null) {
            self.Login_historySM.END_ROW(newVal);
            self.SearchLogin_history();
        }
    });
    /**************************************************/

    /**************************************************/
    self.SearchLogin_history = function () {
        /* ---------------- */
        var Get_Login_history_By_Criteria_Success = function (i_Response) {
            self.Login_historys
			(
				ko.utils.arrayMap(i_Response.My_Result, function (Login_history) {
				    return new Login_historyModel
					(
						Login_history.LOGIN_HISTORY_ID,
						Login_history.USERNAME,
						Login_history.PASSWORD,
						Login_history.LOGIN_STATUS_CODE,
						Login_history.LOGIN_DATE,
						Login_history.LOGIN_HOUR,
						Login_history.LOGIN_MINUTE,
						Login_history.LOGIN_SECOND,
						Login_history.ENTRY_USER_ID,
						Login_history.ENTRY_DATE,
						Login_history.OWNER_ID)
				}));
        }
        /* ---------------- */

        /* ---------------- */
        var Get_Login_history_By_Criteria_Failure = function () { }
        /* ---------------- */

        /* ---------------- */
        _Params = ko.mapping.toJSON(self.Login_historySM);
        _Service_Method = "Get_Login_history_By_Criteria";
        CallService_Element(Get_Login_history_By_Criteria_Success, Get_Login_history_By_Criteria_Failure);
        /* ---------------- */

    }
    /**************************************************/

    /**************************************************/
    self.addLogin_history = function () {
        var match = ko.utils.arrayFirst(self.Login_historys(), function (item) {
            return item.LOGIN_HISTORY_ID() == -1;
        });

        if (match == null) {
            var login_history = new Login_historyModel
				(
					-1,
					'' /* USERNAME */
				,
					'' /* PASSWORD */
				,
					'' /* LOGIN_STATUS_CODE */
				,
					'' /* LOGIN_DATE */
				,
					0 /* LOGIN_HOUR */
				,
					0 /* LOGIN_MINUTE */
				,
					0 /* LOGIN_SECOND */
				,
					0 /* ENTRY_USER_ID */
				,
					'' /* ENTRY_DATE */
				,
					0 /* OWNER_ID */
				);
            self.Login_historys.unshift(login_history);
        }
    }
    /**************************************************/

    /**************************************************/
    self.saveLogin_history = function (login_history) {
        if (login_history.errors().length == 0) {
            _Params = ko.toJSON(login_history);
            _Service_Method = "Edit_Login_history";
            var Edit_SuccessHandler = function (Srv_Response) {
                var index = self.Login_historys.indexOf(login_history);
                self.Login_historys.splice
				(
					index,
					1,
					new Login_historyModel
					(
						Srv_Response.My_Login_history.LOGIN_HISTORY_ID,
						Srv_Response.My_Login_history.USERNAME,
						Srv_Response.My_Login_history.PASSWORD,
						Srv_Response.My_Login_history.LOGIN_STATUS_CODE,
						Srv_Response.My_Login_history.LOGIN_DATE,
						Srv_Response.My_Login_history.LOGIN_HOUR,
						Srv_Response.My_Login_history.LOGIN_MINUTE,
						Srv_Response.My_Login_history.LOGIN_SECOND,
						Srv_Response.My_Login_history.ENTRY_USER_ID,
						Srv_Response.My_Login_history.ENTRY_DATE,
						Srv_Response.My_Login_history.OWNER_ID));
            };
            CallService_Element(Edit_SuccessHandler, null);
        } else {
            login_history.errors.showAllMessages();
        }
    };
    /**************************************************/

    /**************************************************/
    self.removeLogin_history = function (login_history) {
        /* Prepare OK & CANCEL handlers for Confirmation Message */
        /* ------------------------------------------------------------------*/
        var OK_Handler = function () {
            if (login_history.LOGIN_HISTORY_ID != -1) {
                var _Params_Delete_Login_history = new Object();
                _Params_Delete_Login_history.LOGIN_HISTORY_ID = login_history.LOGIN_HISTORY_ID;
                _Params = ko.toJSON(_Params_Delete_Login_history);
                _Service_Method = "Delete_Login_history";

                var Delete_SuccessHandler = function () {
                    self.Login_historys.remove(login_history);
                };
                CallService_Element(Delete_SuccessHandler, null);
            } else {
                self.Login_historys.remove(login_history);
            }
        };

        var CANCEL_Handler = function () { };
        /* ------------------------------------------------------------------*/

        /* Display Confirmation Message */
        /* ------------------------------------------------------------------*/
        if (confirm(_GLB_MSG_DELETE_CONFIRM)) {
            OK_Handler();
        } else {
            CANCEL_Handler();
        }
        /* ------------------------------------------------------------------*/
    };

    /**************************************************/
}
/**************************************************/

/************************************************/
var MyVM = null;
/************************************************/

/************************************************/
$(document).ready
(
	function () {
	    MyVM = new Login_historyViewModel();
	    ko.applyBindings(MyVM);
	});
/************************************************/
