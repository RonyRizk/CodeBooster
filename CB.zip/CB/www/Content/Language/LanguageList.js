
/**************************************************/
function LanguageSearchModel
(
	_OWNER_ID) {
    var self = this;

    self.OWNER_ID = ko.observable(_OWNER_ID);
}
/**************************************************/

/**************************************************/
function LanguageModel
(
	_LANGUAGE_ID,
	_CODE,
	_DESCRIPTION,
	_DESCRIPTION_FR,
	_DESCRIPTION_AR,
	_IS_ACTIVE,
	_IS_ACTIVE_ONLINE,
	_IS_DEFAULT,
	_LANGUAGE_DIRECTION_CODE,
	_ENTRY_USER_ID,
	_ENTRY_DATE,
	_OWNER_ID) {
    var self = this;

    self.LANGUAGE_ID = ko.observable(_LANGUAGE_ID);
    self.CODE = ko.observable(_CODE).extend({ required: true });
    self.DESCRIPTION = ko.observable(_DESCRIPTION).extend({ required: true });
    self.DESCRIPTION_FR = ko.observable(_DESCRIPTION_FR);
    self.DESCRIPTION_AR = ko.observable(_DESCRIPTION_AR);
    self.IS_ACTIVE = ko.observable(_IS_ACTIVE);
    self.IS_ACTIVE_ONLINE = ko.observable(_IS_ACTIVE_ONLINE);
    self.IS_DEFAULT = ko.observable(_IS_DEFAULT);
    self.LANGUAGE_DIRECTION_CODE = ko.observable(_LANGUAGE_DIRECTION_CODE).extend({ required: true });
    self.ENTRY_USER_ID = ko.observable(_ENTRY_USER_ID);
    self.ENTRY_DATE = ko.observable(_ENTRY_DATE);
    self.OWNER_ID = ko.observable(_OWNER_ID);

    self.errors = ko.validation.group(self);
}
/**************************************************/

/**************************************************/
function LanguageViewModel() {

    /**************************************************/
    var self = this;
    /**************************************************/

    /**************************************************/
    self.Languages = ko.mapping.fromJS([]);
    /**************************************************/

    /**************************************************/
    self.LanguageSM = new LanguageSearchModel
		(
			1 /* OWNER_ID */
		);
    /**************************************************/

    /**************************************************/
    self.SearchLanguage = function () {
        /* ---------------- */
        var Get_Language_By_OWNER_ID_Success = function (i_Response) {
            self.Languages
			(
				ko.utils.arrayMap(i_Response.My_Result, function (Language) {
				    return new LanguageModel
					(
						Language.LANGUAGE_ID,
						Language.CODE,
						Language.DESCRIPTION,
						Language.DESCRIPTION_FR,
						Language.DESCRIPTION_AR,
						Language.IS_ACTIVE,
						Language.IS_ACTIVE_ONLINE,
						Language.IS_DEFAULT,
						Language.LANGUAGE_DIRECTION_CODE,
						Language.ENTRY_USER_ID,
						Language.ENTRY_DATE,
						Language.OWNER_ID)
				}));
        }
        /* ---------------- */

        /* ---------------- */
        var Get_Language_By_OWNER_ID_Failure = function () { }
        /* ---------------- */

        /* ---------------- */
        _Params = ko.mapping.toJSON(self.LanguageSM);
        _Service_Method = "Get_Language_By_OWNER_ID";
        CallService_Element(Get_Language_By_OWNER_ID_Success, Get_Language_By_OWNER_ID_Failure);
        /* ---------------- */

    }
    /**************************************************/

    /**************************************************/
    self.addLanguage = function () {
        var match = ko.utils.arrayFirst(self.Languages(), function (item) {
            return item.LANGUAGE_ID() == -1;
        });

        if (match == null) {
            var language = new LanguageModel
				(
					-1,
					'' /* CODE */
				,
					'' /* DESCRIPTION */
				,
					'' /* DESCRIPTION_FR */
				,
					'' /* DESCRIPTION_AR */
				,
					false /* IS_ACTIVE */
				,
					false /* IS_ACTIVE_ONLINE */
				,
					false /* IS_DEFAULT */
				,
					'' /* LANGUAGE_DIRECTION_CODE */
				,
					0 /* ENTRY_USER_ID */
				,
					'' /* ENTRY_DATE */
				,
					0 /* OWNER_ID */
				);
            self.Languages.unshift(language);
        }
    }
    /**************************************************/

    /**************************************************/
    self.saveLanguage = function (language) {
        if (language.errors().length == 0) {
            _Params = ko.toJSON(language);
            _Service_Method = "Edit_Language";
            var Edit_SuccessHandler = function (Srv_Response) {
                var index = self.Languages.indexOf(language);
                self.Languages.splice
				(
					index,
					1,
					new LanguageModel
					(
						Srv_Response.My_Language.LANGUAGE_ID,
						Srv_Response.My_Language.CODE,
						Srv_Response.My_Language.DESCRIPTION,
						Srv_Response.My_Language.DESCRIPTION_FR,
						Srv_Response.My_Language.DESCRIPTION_AR,
						Srv_Response.My_Language.IS_ACTIVE,
						Srv_Response.My_Language.IS_ACTIVE_ONLINE,
						Srv_Response.My_Language.IS_DEFAULT,
						Srv_Response.My_Language.LANGUAGE_DIRECTION_CODE,
						Srv_Response.My_Language.ENTRY_USER_ID,
						Srv_Response.My_Language.ENTRY_DATE,
						Srv_Response.My_Language.OWNER_ID));
            };
            CallService_Element(Edit_SuccessHandler, null);
        } else {
            language.errors.showAllMessages();
        }
    };
    /**************************************************/

    /**************************************************/
    self.removeLanguage = function (language) {
        /* Prepare OK & CANCEL handlers for Confirmation Message */
        /* ------------------------------------------------------------------*/
        var OK_Handler = function () {
            if (language.LANGUAGE_ID != -1) {
                var _Params_Delete_Language = new Object();
                _Params_Delete_Language.LANGUAGE_ID = language.LANGUAGE_ID;
                _Params = ko.toJSON(_Params_Delete_Language);
                _Service_Method = "Delete_Language";

                var Delete_SuccessHandler = function () {
                    self.Languages.remove(language);
                };
                CallService_Element(Delete_SuccessHandler, null);
            } else {
                self.Languages.remove(language);
            }
        };

        var CANCEL_Handler = function () { };
        /* ------------------------------------------------------------------*/

        /* Display Confirmation Message */
        /* ------------------------------------------------------------------*/
        if (confirm(_GLB_MSG_DELETE_CONFIRM)) {
            OK_Handler();
        } else {
            CANCEL_Handler();
        }
        /* ------------------------------------------------------------------*/
    };

    /**************************************************/
}
/**************************************************/

/************************************************/
var MyVM = null;
/************************************************/

/************************************************/
$(document).ready
(
	function () {
	    MyVM = new LanguageViewModel();
	    ko.applyBindings(MyVM);
	    setTimeout(function () {
	        MyVM.SearchLanguage();
	    }, 300);
	});
/************************************************/
