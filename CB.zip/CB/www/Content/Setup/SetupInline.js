/* Members */
/* --------------------------------------------------------------- */
var _StartRow = 0;
var _Current_Page = 1;
var _Pages_Count = 0;
var _ChildWindow = "";
var js_Selected_Setup = null;
var _Setup_Grid_Data = "";
var _Setup_List = [];

var Setup = new Object();
Setup.OWNER_ID = _UserInfo.OwnerID;
Setup.TBL_NAME = "";
Setup.CODE_NAME = "";
Setup.ISSYSTEM = true;
Setup.ISDELETEABLE = true;
Setup.ISUPDATEABLE = true
Setup.ISDELETED = false;
Setup.ISVISIBLE = true;
Setup.DISPLAY_ORDER = 0;
Setup.CODE_VALUE_EN = "";
Setup.CODE_VALUE_FR = ""
Setup.CODE_VALUE_AR = ""
Setup.NOTES = "";
Setup.ENTRY_USER_ID = _UserInfo.UserID;
Setup.ENTRY_DATE = $.format.date(new Date(), "yyyy-MM-dd");

var Params_Get_Distinct_Setup_Tables = new Object();
Params_Get_Distinct_Setup_Tables.OWNER_ID = _UserInfo.OwnerID;

var _Params_Get_Distinct_Setup_Tables = ko.mapping.fromJS(Params_Get_Distinct_Setup_Tables);

var _List_Setup = ko.mapping.fromJS([]);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var Params_Get_Setup_Entries_By_TBL_NAME = new Object();
Params_Get_Setup_Entries_By_TBL_NAME.OWNER_ID = _UserInfo.OwnerID;
Params_Get_Setup_Entries_By_TBL_NAME.TBL_NAME = "";

var _Params_Get_Setup_Entries_By_TBL_NAME = ko.mapping.fromJS(Params_Get_Setup_Entries_By_TBL_NAME);
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* --------------------------------------------------------------- */
/* On Document Ready. */
/* --------------------------------------------------------------- */
$(document).ready
(
	function () {
	$("title", $(window.parent.document)).html($("title").html());
	SetControlsProperties();
});
/* --------------------------------------------------------------- */

/* SetControlsProperties */
/* --------------------------------------------------------------- */
function SetControlsProperties() {
	try {
		/* ----------------- */
		ko.applyBindings(_Params_Get_Setup_Entries_By_TBL_NAME);
		/* ----------------- */

		/* Fill Setup Tables DropDown */
		// ----------------------------------
		Get_Distinct_Setup_Tables();
		// ----------------------------------

		// ----------------------------------
		$("#ddl_Setup").change(function () {
			if ($(this).val() != '')
				/* Trigger Search click */
				Btn_Search_Click();
			else {
				$('#Grd_Setup').jqGrid('GridUnload');
			}
		});
		// ----------------------------------
	} catch (e) {
		alert("SetControlsProperties: " + e.message);
	}
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function Get_Distinct_Setup_Tables() {
	try {
		/* Call the Service. */
		/* ---------------- */
		_Params = JSON.stringify(_Params_Get_Distinct_Setup_Tables);
		_Service_Method = "Get_Distinct_Setup_Tables";

		CallService(Get_Distinct_Setup_Tables_Completed, null);
		/* ---------------- */
	} catch (e) {
		alert("Get_Setup_Entries_By_TBL_NAME: " + e.message);
	}
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function Get_Distinct_Setup_Tables_Completed(i_Response) {
	try {
		ko.mapping.fromJS(i_Response.My_Result, _List_Setup);
	} catch (e) {
		alert("Get_Distinct_Setup_Tables_Completed: " + e.message);
	}
}
/* --------------------------------------------------------------- */

/* Btn_Search_Click. */
/* --------------------------------------------------------------- */
function Btn_Search_Click() {
	try {
		_StartRow = 0;
		_Current_Page = 1;

		GetData(_StartRow, _StartRow + _LIST_ITEMS_PER_PAGE);
	} catch (e) {
		alert("Btn_Search_Click: " + e.message);
	}
}
/* --------------------------------------------------------------- */

/* GatherUIData */
/* --------------------------------------------------------------- */
function GatherUIData(i_StartRow, i_EndRow) {
	try {
		// To Collect Non Visual Data.
	} catch (e) {
		alert("GatherUIData: " + e.message);
	}
}
/* --------------------------------------------------------------- */

/* GetData */
/* --------------------------------------------------------------- */
function GetData(i_Start_Row, i_End_Row) {
	try {

		/* ---------------- */
		_Setup_List = [];
		/* ---------------- */

		/* ---------------- */
		GatherUIData(i_Start_Row, i_End_Row);
		/* ---------------- */

		/* ---------------- */
		_Params = ko.mapping.toJSON(_Params_Get_Setup_Entries_By_TBL_NAME);

		_Service_Method = "Get_Setup_Entries_By_TBL_NAME";
		CallService(Get_Setup_Entries_By_TBL_NAME_Completed, null);
		/* ---------------- */
	} catch (e) {
		alert("GetData: " + e.message);
	}
}
/* --------------------------------------------------------------- */

// Get_Setup_Entries_By_TBL_NAME
/* --------------------------------------------------------------- */
function Get_Setup_Entries_By_TBL_NAME_Completed(i_Input) {
	try {
		// ---------------
		Handle_Setup_Grid(i_Input);
		// ---------------
	} catch (e) {
		alert("Get_Setup_Entries_By_TBL_NAME_Completed: " + e.message);
	}
}
/* --------------------------------------------------------------- */

//Handle_Setup_Grid
var _Grd_Setup_Glb_iRow = -1;
var _Grd_Setup_Glb_iCol = -1;
var _Grd_Setup_Allow_Add = 1;
var _Grd_Setup_InlineMode = "";
var _Grd_Setup_EmptyObj = new Object();
/* --------------------------------------------------------------- */
function Handle_Setup_Grid(i_Input) {
	try {

		/* Reset Grid Global Params */
		// --------------------
		_Grd_Setup_Glb_iRow = -1;
		_Grd_Setup_Glb_iCol = -1;
		_Grd_Setup_Allow_Add = 1;
		_Grd_Setup_InlineMode = "";
		_Grd_Setup_EmptyObj = new Object();
		// --------------------

		_Pages_Count = 1;

		// Fill Collection With Records to Preserve the Paging Mechanism.
		// --------------------
		i_Input.My_Result = $.Enumerable.From(i_Input.My_Result)
			.OrderBy("$.REF")
			.ToArray();

		for (var i = 0; i < i_Input.My_Result.length; i++) {
			_Setup_List.push(i_Input.My_Result[i]);
		}

		// Unload the Grid In order To Re-Construct it.
		// --------------------
		$("#Grd_Setup").jqGrid('GridUnload');
		// --------------------

		//Prepare Grid Options.
		// --------------------
		_Setup_Grid_Data = {
			rows : _Setup_List,
			page : _Current_Page,
			records : parseInt(JSON.stringify(i_Input.My_Result.length)),
			total : _Pages_Count
		};
		// --------------------

		// Build Grid.
		// --------------------
		$("#Grd_Setup").jqGrid({
		    datastr: _Setup_Grid_Data,
		    datatype: 'jsonstring',
		    colNames:
			[
				'Tbl name *',
				'Code name',
				'Visible?',
				'Deleted?',
				'Display order',
				'Code value En.',
				'Code value Fr.',
				'Code value Ar.',
				''
			],
		    colModel:
			[
                {
                    name: 'TBL_NAME',
                    editable: true,
                    editrules: {
                        required: true
                    }
                },
                {
                    name: 'CODE_NAME',
                    editable: false
                },
                {
                    name: 'ISVISIBLE',
                    width: '75',
                    align: 'center',
                    stype: 'select',
                    searchoptions: {
                        value: ":No filter;true:True;false:False"
                    },
                    editable: true,
                    edittype: 'checkbox',
                    editoptions: {
                        value: "true:false"
                    },
                    formatter: checkboxFormat,
                    unformat: checkboxUnFormat
                },
                {
                    name: 'ISDELETED',
                    width: '75',
                    align: 'center',
                    stype: 'select',
                    searchoptions: {
                        value: ":No filter;true:True;false:False"
                    },
                    editable: true,
                    edittype: 'checkbox',
                    editoptions: {
                        value: "true:false"
                    },
                    formatter: checkboxFormat,
                    unformat: checkboxUnFormat
                },
                {
                    name: 'DISPLAY_ORDER',
                    align: 'center',
                    width: '70',
                    editable: true,
                    editrules: {
                        required: true,
                        integer: true
                    }
                },
                {
                    name: 'CODE_VALUE_EN',
                    editable: true,
                    editrules: {
                        required: true
                    }
                },
                {
                    name: 'CODE_VALUE_FR',
                    editable: true,
                    editrules: {
                        required: true
                    }
                },
                 {
                     name: 'CODE_VALUE_AR',
                     editable: true,
                     editrules: {
                         required: true
                     }
                 },
                 {
                     name: 'Actions',
                     align: 'center',
                     width: '50',
                     search: false,
                     editable: false,
                     sortable: false,
                     formatter: actionsFormatter
                 }
						],
		    jsonReader: {
		        root: 'rows',
		        total: 'total',
		        page: 'page',
		        records: 'records',
		        repeatitems: false,
		        id: 'id'
		    },
		    cellEdit: true,
		    cellsubmit: "clientArray",
		    multiselect: false,
		    multiboxonly: false,
		    subGrid: false,
		    cache: false,
		    rowNum: 1000000,
		    rownumbers: false,
		    viewrecords: false,
		    pgbuttons: false,
		    pginput: false,
		    recordpos: 'left',
		    loadtext: "Loading....",
		    emptyrecords: "No records to view",
		    height: 'auto',
		    altRows: true,
		    altclass: 'jqgridAltRowClass',
		    toppager: true,
		    ignoreCase: true, // To be able to search without casing
		    afterInsertRow:
						function (rowid, rowdata, rowelem) {
						    // Client added row //
						    if (rowid == "-1") {
						        // To handle delete Click event //
						        $('img.save[class*="action-trigger"]', $("#Grd_Setup")).click(function () {
						            /* Set global rowid to use in validation */
						            _Grd_Glb_rowid = -1;

						            /* Set InlineMode to Add in order to catch it in the Completed event and update rowid */
						            /* ------------------------------- */
						            _Grd_Setup_InlineMode = "Add";
						            /* ------------------------------- */

						            /* Save Row localy and submit to server if validation passed */
						            /* ------------------------------- */
						            jQuery("#Grd_Setup").jqGrid('saveRow', "-1", {
						                url: 'clientArray',
						                aftersavefunc: function (rowid, response) {
						                    /* ---------------- */
						                    var obj_LocalRow = jQuery("#Grd_Setup").jqGrid('getLocalRow', rowid);
						                    $.each(_Grd_Setup_EmptyObj, function (key, value) {
						                        if (obj_LocalRow[key]) {
						                            _Grd_Setup_EmptyObj[key] = obj_LocalRow[key];
						                        }
						                    });

						                    js_Selected_Setup = _Grd_Setup_EmptyObj;
						                    sessionStorage.setItem("_Selected_Setup", JSON.stringify(js_Selected_Setup));
						                    /* ---------------- */

						                    /* ---------------- */
						                    Service_Call_InCompleted = function () {
						                        jQuery('#Grd_Setup').jqGrid('editRow', -1, true);
						                    };

						                    _Params = sessionStorage["_Selected_Setup"];
						                    _Service_Method = "Edit_Setup";
						                    CallService(Edit_setup_Completed);
						                    /* ---------------- */
						                }
						            });
						        });

						        $('img.cancel[class*="action-trigger"]', $("#Grd_Setup")).click(function () {
						            var rowid = $(this).parent().parent().attr('id');
						            /* Set global rowid to use in validation */
						            _Grd_Glb_rowid = -1;

						            /* Remove any Active qtip */
						            $(".qtip").remove();

						            /* Remove Client side added row */
						            /* ---------------- */
						            $("#Grd_Setup").jqGrid('restoreRow', rowid);
						            $("#Grd_Setup").jqGrid('delRowData', rowid);

						            /*  Reset InlineMode & Enable Add */
						            /* ---------------- */
						            _Grd_Setup_InlineMode = "";
						            _Grd_Setup_Allow_Add = 1;
						            /* ---------------- */
						        });
						    }
						},
		    afterEditCell:
						function (rowid, cellname, value, iRow, iCol) {
						    /* Set global rowid to use in validation */
						    _Grd_Glb_rowid = rowid;

						    _Grd_Setup_Glb_iRow = iRow;
						    _Grd_Setup_Glb_iCol = iCol;
						},
		    afterSaveCell:
						function (rowid, cellname, value, iRow, iCol) {
						    Btn_Search_Click();
//						    if ((_Err != null) && (_Err == 1)) {
//						        $("#Grd_Setup").jqGrid('restoreCell', iRow, iCol);
//						    }
						},
		    beforeSubmitCell:
						function (rowid, cellname, value, iRow, iCol) {
						    js_Selected_Setup = $.Enumerable.From(_Setup_List).Where("$.TBL_NAME=='" + $("#Grd_Setup").getLocalRow(rowid)["TBL_NAME"] + "' && " + "$.CODE_NAME=='" + $("#Grd_Setup").getLocalRow(rowid)["CODE_NAME"] + "'").Single();
						    /*Get_Grid_Selected_Object
						    (
						    "SETUP_ID",
						    $("#Grd_Setup").getRowData(rowid)["SETUP_ID"],
						    _Setup_List
						    );*/
						    js_Selected_Setup[cellname] = value;
						    sessionStorage.setItem("_Selected_Setup", JSON.stringify(js_Selected_Setup));

						    /* -------------------------------------------- */
						    Service_Call_InCompleted = function () {
						        _Err = 1;
						    }
						    /* -------------------------------------------- */

						    _Params = sessionStorage["_Selected_Setup"];
						    _Service_Method = "Edit_Setup";
						    _Async = false;
						    CallService();
						},
		    loadComplete: function (data) {
		        $("#Grd_Setup").setGridParam({
		            datatype: 'local'
		        });
		        Attach_Setup_Actions_Trigger();
		    },
		    onPaging: function (which_button) {
		        $("#Grd_Setup").setGridParam({
		            datatype: 'json'
		        });
		        _Current_Page = $('#Grd_Setup').getGridParam('page');
		        _Current_Page = parseInt(_Current_Page);
		        _StartRow = (_Current_Page - 1) * _LIST_ITEMS_PER_PAGE;

		        GetData(_StartRow, _StartRow + _LIST_ITEMS_PER_PAGE);
		    }
		}).jqGrid("navGrid", "#Grd_Setup_toppager", {
		    edit: false,
		    add: false,
		    del: false,
		    search: false,
		    refresh: false,
		    position: 'right'
		}).jqGrid("navButtonAdd", "#Grd_Setup_toppager", {
		    caption: "<img alt='Add row' title='Add row' src='../../images/Add_16x16.png' class='action-trigger add' style='cursor:pointer; vertical-align:middle; padding:0px 5px 0px 5px;' />",
		    buttonicon: "none",
		    onClickButton: function () {
		        Add_Setup_Entry();
		    },
		    position: "last",
		    title: "Add"
		});

					// Set Navbuttons position to right.
					// ---------------------------------
					$('td#Grd_Setup_toppager_right').find('table.navtable').attr('style', 'float:right;table-layout:auto;');
					// ---------------------------------

					// Grab click outside grid in order to save unsaved cells
					// ---------------------------------
					$("#Grd_Setup").click(function (e) {
						if (e.target.tagName != 'A') {
							e.stopPropagation();
						}
					});

					$(document).click(function (e) {
						Grd_Setup_Cell_Save_Handler();
					});

					$(parent.document).click(function (e) {
						Grd_Setup_Cell_Save_Handler();
					});
					// ---------------------------------

					// jq_Post_Handle_Grid //
					jq_Post_Handle_Grid();
					// --------------------
				}
				catch (e) {
					alert('Handle_Setup_Grid :' + e.message);
				}
			}
				/* --------------------------------------------------------------- */

				// Grd_Setup_Cell_Save_Handler()
				/* --------------------------------------------------------------- */
				function Grd_Setup_Cell_Save_Handler() {
				if (_Grd_Setup_Glb_iRow != -1 && _Grd_Setup_Glb_iCol != -1) {
					$("#Grd_Setup").jqGrid('saveCell', _Grd_Setup_Glb_iRow, _Grd_Setup_Glb_iCol);
				}
			}
				/* --------------------------------------------------------------- */

				// Attach_Setup_Actions_Trigger()
				/* --------------------------------------------------------------- */
				function Attach_Setup_Actions_Trigger() {
				try {
					// To handle delete Click event //
					$('img.delete[class*="action-trigger"]', $("#Grd_Setup")).on('click', function () {
						if (_Grd_Setup_Glb_iRow != -1 && _Grd_Setup_Glb_iCol != -1) {
							$("#Grd_Setup").jqGrid('saveCell', _Grd_Setup_Glb_iRow, _Grd_Setup_Glb_iCol);
						}
						var rowId = $(this).parent().parent().attr('id');
						$("#Grd_Setup").jqGrid('resetSelection');
						$("#Grd_Setup").jqGrid('setSelection', rowId, false);

						Remove_Setup_Entry();
					});
				} catch (e) {
					alter('Attach_Setup_Actions_Trigger :' + e.message);
				}
			}
				/* --------------------------------------------------------------- */
				// Add_Setup_Entry()
				/* --------------------------------------------------------------- */
				function Add_Setup_Entry() {
				try {
					/* Save any cell in edit mode before Adding new row */
					Grd_Setup_Cell_Save_Handler();
					/* ------------------------------------------------ */

					sessionStorage.setItem("_Selected_Setup", null);
					if (_Grd_Setup_Allow_Add == 1) {
						_Grd_Setup_EmptyObj = jQuery.extend({}, Setup); // Shallow Copy

						var parameters = {
							rowID : "-1", //new_row
							initdata : _Grd_Setup_EmptyObj,
							position : "first",
							useDefValues : true,
							useFormatter : true
						};

						jQuery("#Grd_Setup").jqGrid('addRow', parameters);
						jQuery('#Grd_Setup').jqGrid('editRow', -1, false);

						/* Disable Add */
						/* ------------------------ */
						_Grd_Setup_Allow_Add = 0;
						/* ------------------------ */
					} else {
						alert("There is an already added row. Please SAVE it or CANCEL it to add another one.");
					}
				} catch (e) {
					alert("Add_Setup_Entry:" + e.message);
				}
			}
				/* --------------------------------------------------------------- */

				// Remove_Setup_Entry
				/* --------------------------------------------------------------- */
				function Remove_Setup_Entry() {
				try {
					/* Prepare OK & CANCEL handlers for Confirmation Message */
					/* ------------------------------------------------------------------*/
					var OK_Handler = function () {
						//_Params_Delete_Setup.SETUP_ID = $("#Grd_Setup").getGridParam('selrow');
						_Params_Delete_Setup.TBL_NAME = "";
						_Params_Delete_Setup.CODE_NAME = "";
						_Params = JSON.stringify(_Params_Delete_Setup);
						_Service_Method = "Delete_Setup";
						CallService();
					};

					var CANCEL_Handler = function () {
						$("#Grd_Setup").jqGrid('resetSelection');
					};
					/* ------------------------------------------------------------------*/

					/* Display Confirmation Message */
					/* ------------------------------------------------------------------*/
					jq_ConfirmationMessage(ResolveSetupEntry("_GENERAL_MSG", "CONFIRM_DELETE"), OK_Handler, CANCEL_Handler);
					/* ------------------------------------------------------------------*/
				} catch (e) {
					alert("Remove_Setup_Entry: " + e.message);
				}
			}
				/* --------------------------------------------------------------- */

				/* --------------------------------------------------------------- */
				function Service_Call_Completed(i_Response) {
				try {
					switch (_Service_Method) {
					case "Get_Setup_Entries_By_TBL_NAME":
						Get_Setup_Entries_By_TBL_NAME_Completed(i_Response);
						break;
					case "Get_Distinct_Setup_Tables":
						Get_Distinct_Setup_Tables_Completed(i_Response);
						break;
					case "Delete_Setup":
						GetData(0, _LIST_ITEMS_PER_PAGE);
						jq_DisplayNotification('Deleted.', 'success');
						break;
					case "Edit_Setup":
						jq_DisplayNotification('Saved.', 'success');

						if (_Grd_Setup_InlineMode == "Add") {
							/* Reset InlineMode & Enable Add */
							/* ------------------------------------------------------------------*/
							_Grd_Setup_InlineMode = "";
							_Grd_Setup_Allow_Add = 1;
							/* ------------------------------------------------------------------*/

							GetData(0, _LIST_ITEMS_PER_PAGE);
						} else {
							//$("#Grd_Setup").jqGrid('setRowData', i_Response.My_Setup["SETUP_ID"], i_Response.My_SetupEntry);

							/* Reset Global cell params indicating edit mode */
							_Grd_Setup_Glb_iRow = -1;
							_Grd_Setup_Glb_iCol = -1;
						}

						break;
					}
				} catch (e) {
					alert("Service_Call_Completed:" + e.message);
				}
			}
				/* --------------------------------------------------------------- */

				/* --------------------------------------------------------------- */
				function Edit_setup_Completed() {
				jq_DisplayNotification('Saved.', 'success');

				if (_Grd_Setup_InlineMode == "Add") {
					/* Reset InlineMode & Enable Add */
					/* ------------------------------------------------------------------*/
					_Grd_Setup_InlineMode = "";
					_Grd_Setup_Allow_Add = 1;
					/* ------------------------------------------------------------------*/

					GetData(0, _LIST_ITEMS_PER_PAGE);
				} else {
					//$("#Grd_Setup").jqGrid('setRowData', i_Response.My_Setup["SETUP_ID"], i_Response.My_SetupEntry);

					/* Reset Global cell params indicating edit mode */
					_Grd_Setup_Glb_iRow = -1;
					_Grd_Setup_Glb_iCol = -1;
				}
			}
				/* --------------------------------------------------------------- */
