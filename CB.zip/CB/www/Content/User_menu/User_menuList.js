
/**************************************************/
var _List_Menu = ko.mapping.fromJSON(localStorage["MENU"]);
/**************************************************/

/**************************************************/
function User_menuSearchModel
(
_USER_ID
) {
    var self = this;

    self.USER_ID = ko.observable(_USER_ID);
}
/**************************************************/

/**************************************************/
function User_menuModel
(
_USER_MENU_ID,
_MENU_ID,
_USER_ID,
_IS_ACTIVE,
_DESCRIPTION,
_OWNER_ID
) {
    var self = this;

    self.USER_MENU_ID = ko.observable(_USER_MENU_ID);
    self.MENU_ID = ko.observable(_MENU_ID).extend({ required: true });
    self.USER_ID = ko.observable(_USER_ID);
    self.IS_ACTIVE = ko.observable(_IS_ACTIVE);
    self.DESCRIPTION = ko.observable(_DESCRIPTION);
    self.OWNER_ID = ko.observable(_OWNER_ID);

    self.errors = ko.validation.group(self);
}
/**************************************************/

/**************************************************/
function User_menuViewModel() {

    /**************************************************/
    var self = this;
    /**************************************************/

    /**************************************************/
    self.User = ko.mapping.fromJSON(sessionStorage["selected_User"]);
    /**************************************************/

    /**************************************************/
    self.User_menus = ko.mapping.fromJS([]);
    /**************************************************/

    /**************************************************/
    self.User_menuSM = new User_menuSearchModel
(
''  /* USER_ID */
);
    self.User_menuSM.USER_ID(self.User.USER_ID());
    /**************************************************/

    /**************************************************/
    self.GetMenus = function () {

        /* ---------------- */
        var Params_Get_Menu_By_OWNER_ID = new Object();
        Params_Get_Menu_By_OWNER_ID.OWNER_ID = _UserInfo.OwnerID;
        /* ---------------- */

        /* ---------------- */
        var Get_Menu_By_OWNER_ID_Success = function (i_Response) {
            if (i_Response.My_Result != null) {
                localStorage.setItem("MENU", JSON.stringify(i_Response.My_Result));
                ko.mapping.fromJSON(localStorage["MENU"], _List_Menu);
            }
        }
        /* ---------------- */

        /* ---------------- */
        var Get_Menu_By_OWNER_ID_Failure = function () {
        }
        /* ---------------- */

        /* ---------------- */
        _Params = ko.mapping.toJSON(Params_Get_Menu_By_OWNER_ID);
        _Service_Method = "Get_Menu_By_OWNER_ID";
        CallService_Element(Get_Menu_By_OWNER_ID_Success, Get_Menu_By_OWNER_ID_Failure);
        /* ---------------- */

    }
    /**************************************************/

    /**************************************************/
    self.SearchUser_menu = function () {
        /* ---------------- */
        var Get_User_menu_By_USER_ID_Success = function (i_Response) {
            self.User_menus
(
ko.utils.arrayMap(i_Response.My_Result, function (User_menu) {
    return new User_menuModel
(
User_menu.USER_MENU_ID,
User_menu.MENU_ID,
User_menu.USER_ID,
User_menu.IS_ACTIVE,
User_menu.DESCRIPTION,
User_menu.OWNER_ID
)
}));
        }
        /* ---------------- */

        /* ---------------- */
        var Get_User_menu_By_USER_ID_Failure = function () {
        }
        /* ---------------- */

        /* ---------------- */
        _Params = ko.mapping.toJSON(self.User_menuSM);
        _Service_Method = "Get_User_menu_By_USER_ID";
        CallService_Element(Get_User_menu_By_USER_ID_Success, Get_User_menu_By_USER_ID_Failure);
        /* ---------------- */

    }
    /**************************************************/

    /**************************************************/
    self.addUser_menu = function () {
        var match = ko.utils.arrayFirst(self.User_menus(), function (item) {
            return item.USER_MENU_ID() == -1;
        });

        if (match == null) {
            var user_menu = new User_menuModel
(
-1,
0 /* MENU_ID */,
0 /* USER_ID */,
false /* IS_ACTIVE */,
'' /* DESCRIPTION */,
0 /* OWNER_ID */
);
            user_menu.USER_ID(self.User.USER_ID());
            self.User_menus.unshift(user_menu);
        }
    }
    /**************************************************/

    /**************************************************/
    self.saveUser_menu = function (user_menu) {
        if (user_menu.errors().length == 0) {
            _Params = ko.toJSON(user_menu);
            _Service_Method = "Edit_User_menu";
            var Edit_SuccessHandler = function (Srv_Response) {
                var index = self.User_menus.indexOf(user_menu);
                self.User_menus.splice
(
index,
1,
new User_menuModel
(
Srv_Response.My_User_menu.USER_MENU_ID,
Srv_Response.My_User_menu.MENU_ID,
Srv_Response.My_User_menu.USER_ID,
Srv_Response.My_User_menu.IS_ACTIVE,
Srv_Response.My_User_menu.DESCRIPTION,
Srv_Response.My_User_menu.OWNER_ID
));
            };
            CallService_Element(Edit_SuccessHandler, null);
        }
        else {
            user_menu.errors.showAllMessages();
        }
    };
    /**************************************************/

    /**************************************************/
    self.removeUser_menu = function (user_menu) {
        /* Prepare OK & CANCEL handlers for Confirmation Message */
        /* ------------------------------------------------------------------*/
        var OK_Handler = function () {
            if (user_menu.USER_MENU_ID != -1) {
                var _Params_Delete_User_menu = new Object();
                _Params_Delete_User_menu.USER_MENU_ID = user_menu.USER_MENU_ID;
                _Params = ko.toJSON(_Params_Delete_User_menu);
                _Service_Method = "Delete_User_menu";

                var Delete_SuccessHandler = function () {
                    self.User_menus.remove(user_menu);
                };
                CallService_Element(Delete_SuccessHandler, null);
            } else {
                self.User_menus.remove(user_menu);
            }
        };

        var CANCEL_Handler = function () { };
        /* ------------------------------------------------------------------*/

        /* Display Confirmation Message */
        /* ------------------------------------------------------------------*/
        if (confirm(_GLB_MSG_DELETE_CONFIRM)) {
            OK_Handler();
        }
        else {
            CANCEL_Handler();
        }
        /* ------------------------------------------------------------------*/
    };

    /**************************************************/
}
/**************************************************/

/************************************************/
var MyVM = null;
/************************************************/

/************************************************/
$(document).ready
(
function () {
    MyVM = new User_menuViewModel();
    ko.applyBindings(MyVM);
    setTimeout(function () { MyVM.SearchUser_menu(); }, 300);
    MyVM.GetMenus();
}
);
/************************************************/
