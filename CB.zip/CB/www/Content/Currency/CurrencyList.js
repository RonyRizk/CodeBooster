
/**************************************************/
function CurrencySearchModel
(
	_OWNER_ID) {
	var self = this;

	self.OWNER_ID = ko.observable(_OWNER_ID);
}
/**************************************************/

/**************************************************/
function CurrencyModel
(
	_CURRENCY_ID,
	_CODE,
	_SYMBOL,
	_DECIMAL_NBR,
	_IS_REFERENCE,
	_IS_LOCAL,
	_TO_USD_RATE,
	_NOTES,
	_ENTRY_USER_ID,
	_ENTRY_DATE,
	_OWNER_ID) {
	var self = this;

	self.CURRENCY_ID = ko.observable(_CURRENCY_ID);
	self.CODE = ko.observable(_CODE).extend({ required: true });
	self.SYMBOL = ko.observable(_SYMBOL).extend({ required: true });
	self.DECIMAL_NBR = ko.observable(_DECIMAL_NBR).extend({ required: true });
	self.IS_REFERENCE = ko.observable(_IS_REFERENCE);
	self.IS_LOCAL = ko.observable(_IS_LOCAL);
	self.TO_USD_RATE = ko.observable(_TO_USD_RATE).extend({ required: true });
	self.NOTES = ko.observable(_NOTES);
	self.ENTRY_USER_ID = ko.observable(_ENTRY_USER_ID);
	self.ENTRY_DATE = ko.observable(_ENTRY_DATE);
	self.OWNER_ID = ko.observable(_OWNER_ID);

	self.errors = ko.validation.group(self);
}
/**************************************************/

/**************************************************/
function CurrencyViewModel() {

	/**************************************************/
	var self = this;
	/**************************************************/

	/**************************************************/
	self.Currencys = ko.mapping.fromJS([]);
	/**************************************************/

	/**************************************************/
	self.CurrencySM = new CurrencySearchModel
		(
			1 /* OWNER_ID */
		);
	/**************************************************/

	/**************************************************/
	self.Update_Currencies_Rate = function () {

	    /* ---------------- */
	    var Params_Update_Currencies_Rate = new Object();
	    /* ---------------- */

	    /* ---------------- */
	    var Update_Currencies_Rate_Success = function () {
	        self.SearchCurrency();
	    }
	    /* ---------------- */

	    /* ---------------- */
	    _Params = ko.mapping.toJSON(Params_Update_Currencies_Rate);
	    _Service_Method = "Update_Currencies_Rate";
	    CallService_Element(Update_Currencies_Rate_Success, null);
	    /* ---------------- */

	}
	/**************************************************/


	/**************************************************/
	self.SearchCurrency = function () {
		/* ---------------- */
		var Get_Currency_By_OWNER_ID_Success = function (i_Response) {
			self.Currencys
			(
				ko.utils.arrayMap(i_Response.My_Result, function (Currency) {
					return new CurrencyModel
					(
						Currency.CURRENCY_ID,
						Currency.CODE,
						Currency.SYMBOL,
						Currency.DECIMAL_NBR,
						Currency.IS_REFERENCE,
						Currency.IS_LOCAL,
						Currency.TO_USD_RATE,
						Currency.NOTES,
						Currency.ENTRY_USER_ID,
						Currency.ENTRY_DATE,
						Currency.OWNER_ID)
				}));
		}
		/* ---------------- */

		/* ---------------- */
		var Get_Currency_By_OWNER_ID_Failure = function () {}
		/* ---------------- */

		/* ---------------- */
		_Params = ko.mapping.toJSON(self.CurrencySM);
		_Service_Method = "Get_Currency_By_OWNER_ID";
		CallService_Element(Get_Currency_By_OWNER_ID_Success, Get_Currency_By_OWNER_ID_Failure);
		/* ---------------- */

	}
	/**************************************************/

	/**************************************************/
	self.addCurrency = function () {
		var match = ko.utils.arrayFirst(self.Currencys(), function (item) {
				return item.CURRENCY_ID() == -1;
			});

		if (match == null) {
			var currency = new CurrencyModel
				(
					-1,
					'' /* CODE */
				,
					'' /* SYMBOL */
				,
					0 /* DECIMAL_NBR */
				,
					false /* IS_REFERENCE */
				,
					false /* IS_LOCAL */
				,
					0 /* TO_USD_RATE */
				,
					'' /* NOTES */
				,
					0 /* ENTRY_USER_ID */
				,
					'' /* ENTRY_DATE */
				,
					0 /* OWNER_ID */
				);
			self.Currencys.unshift(currency);
		}
	}
	/**************************************************/

	/**************************************************/
	self.saveCurrency = function (currency) {
		if (currency.errors().length == 0) {
			_Params = ko.toJSON(currency);
			_Service_Method = "Edit_Currency";
			var Edit_SuccessHandler = function (Srv_Response) {
				var index = self.Currencys.indexOf(currency);
				self.Currencys.splice
				(
					index,
					1,
					new CurrencyModel
					(
						Srv_Response.My_Currency.CURRENCY_ID,
						Srv_Response.My_Currency.CODE,
						Srv_Response.My_Currency.SYMBOL,
						Srv_Response.My_Currency.DECIMAL_NBR,
						Srv_Response.My_Currency.IS_REFERENCE,
						Srv_Response.My_Currency.IS_LOCAL,
						Srv_Response.My_Currency.TO_USD_RATE,
						Srv_Response.My_Currency.NOTES,
						Srv_Response.My_Currency.ENTRY_USER_ID,
						Srv_Response.My_Currency.ENTRY_DATE,
						Srv_Response.My_Currency.OWNER_ID));
			};
			CallService_Element(Edit_SuccessHandler, null);
		} else {
			currency.errors.showAllMessages();
		}
	};
	/**************************************************/

	/**************************************************/
	self.removeCurrency = function (currency) {
		/* Prepare OK & CANCEL handlers for Confirmation Message */
		/* ------------------------------------------------------------------*/
		var OK_Handler = function () {
			if (currency.CURRENCY_ID != -1) {
				var _Params_Delete_Currency = new Object();
				_Params_Delete_Currency.CURRENCY_ID = currency.CURRENCY_ID;
				_Params = ko.toJSON(_Params_Delete_Currency);
				_Service_Method = "Delete_Currency";

				var Delete_SuccessHandler = function () {
					self.Currencys.remove(currency);
				};
				CallService_Element(Delete_SuccessHandler, null);
			} else {
				self.Currencys.remove(currency);
			}
		};

		var CANCEL_Handler = function () {};
		/* ------------------------------------------------------------------*/

		/* Display Confirmation Message */
		/* ------------------------------------------------------------------*/
		if (confirm(_GLB_MSG_DELETE_CONFIRM)) {
			OK_Handler();
		} else {
			CANCEL_Handler();
		}
		/* ------------------------------------------------------------------*/
	};

	/**************************************************/
}
/**************************************************/

/************************************************/
var MyVM = null;
/************************************************/

/************************************************/
$(document).ready
(
	function () {
	MyVM = new CurrencyViewModel();
	ko.applyBindings(MyVM);
	setTimeout(function () {
		MyVM.SearchCurrency();
	}, 300);
});
/************************************************/
