﻿/* ---------------------------------------------------------------*/
var _aspnet_handler = '';
var str_REL_KEY = sessionStorage["selected_REL_KEY"];
var str_REL_ENTITY = sessionStorage["selected_REL_ENTITY"];
/* ---------------------------------------------------------------*/

/* ---------------------------------------------------------------*/
function SetControlsProperties() {

    /* ------------------------------------------ */
    var fileInput = $('#fileToUpload');
    var maxSize = 150000000; // 150 Mb
    var allowedExtensions = ['bmp','jpb','png','gif'];
    _aspnet_handler = '../../DocumentUploader.ashx?REL_ENTITY=' + str_REL_ENTITY + '&REL_KEY=' + str_REL_KEY;

    str_UploadInfo = "Allowed file types: " + allowedExtensions.join(", ") + "<br>" +
			         "Maximum file size: "  + parseInt(maxSize / 1000000) + " Mb";

    $("#td_UploadInfo").html(str_UploadInfo);
    /* ------------------------------------------ */


    /* ------------------------------------------ */
    $('#Btn_Upload').click(function (e) {
        if (fileInput.get(0).files.length) {
            var fileSize = fileInput.get(0).files[0].size; // in bytes
            var fileExt = fileInput.get(0).files[0].name.split('.')[1].toLowerCase();
            $("#img_Upload").attr("src", fileInput.get(0).files[0].name);

            if ($.inArray(fileExt, allowedExtensions) == -1) {
                alert('Invalid file extension. Allowed extensions are \"' + allowedExtensions.join('|') + '\"');
                return false;
            } else if (fileSize > maxSize) {
                alert('File size is more than ' + parseInt(maxSize / 1000) + ' kb');
                return false;
            } else {
                return ajaxFileUpload();
            }
        } else {
            alert('Please choose a file!');
            return false;
        }
    });
    /* ------------------------------------------ */
}
/* ---------------------------------------------------------------*/

$(document).ready(function () {
    setTimeout(function () { SetControlsProperties(); }, 500);
});

function ajaxFileUpload() {
    //starting setting some animation when the ajax starts and completes
    $("#loading").show();
    $('#Btn_Upload').attr("disabled", "disabled");

    /*
    prepareing ajax file upload
    url: the url of script file handling the uploaded files
    fileElementId: the file type of input element id and it will be the index of  $_FILES Array()
    dataType: it support json, xml
    secureuri:use secure protocol
    success: call back function when the ajax complete
    error: callback function when the ajax failed
    */
    var jsonData;


    $.ajaxFileUpload({
        url: _aspnet_handler,
        secureuri: false,
        fileElementId: 'fileToUpload',
        dataType: 'json',
        data: jsonData,
        success: function (data, status) {
            $("#loading").hide();
            $('#Btn_Upload').removeAttr("disabled");           
            if (typeof (data.error) != 'undefined') {
                if (data.error != '') {
                    alert(data.error);
                } else {
                    parent.MyVM.SearchDocument();
                }
                alert('File successfully uploaded.', 1);
            }
        },
        error: function (data, status, e) {
            $("#loading").hide();
            $('#Btn_Upload').removeAttr("disabled");
        }
    });

    return false;
}
