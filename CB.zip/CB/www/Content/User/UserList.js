
/**************************************************/
function UserSearchModel
(
	_OWNER_ID,
	_USERNAME,
	_PASSWORD,
	_USER_TYPE_CODE,
	_START_ROW,
	_END_ROW,
	_TOTAL_COUNT) {
	var self = this;

	self.OWNER_ID = ko.observable(_OWNER_ID);
	self.USERNAME = ko.observable(_USERNAME);
	self.PASSWORD = ko.observable(_PASSWORD);
	self.USER_TYPE_CODE = ko.observable(_USER_TYPE_CODE);
	self.START_ROW = ko.observable(_START_ROW);
	self.END_ROW = ko.observable(_END_ROW);
	self.TOTAL_COUNT = ko.observable(_TOTAL_COUNT);
}
/**************************************************/

/**************************************************/
function UserModel
(
	_USER_ID,
	_OWNER_ID,
	_USERNAME,
	_PASSWORD,
	_USER_TYPE_CODE,
	_IS_ACTIVE,
	_ENTRY_DATE) {
	var self = this;

	self.USER_ID = ko.observable(_USER_ID);
	self.OWNER_ID = ko.observable(_OWNER_ID);
	self.USERNAME = ko.observable(_USERNAME).extend({ required: true });
	self.PASSWORD = ko.observable(_PASSWORD).extend({ required: true });
	self.USER_TYPE_CODE = ko.observable(_USER_TYPE_CODE).extend({ required: true });
	self.IS_ACTIVE = ko.observable(_IS_ACTIVE);
	self.ENTRY_DATE = ko.observable(_ENTRY_DATE);

	self.errors = ko.validation.group(self);
}
/**************************************************/

/**************************************************/
function UserViewModel() {

	/**************************************************/
	var self = this;
	/**************************************************/

	/**************************************************/
	self.Users = ko.mapping.fromJS([]);
	/**************************************************/

	/**************************************************/
	self.UserSM = new UserSearchModel
		(
			0 /* OWNER_ID */
		,
			'' /* USERNAME */
		,
			'' /* PASSWORD */
		,
			'' /* USER_TYPE_CODE */
		,
			0 /* START_ROW */
		,
			0 /* END_ROW */
		,
			0 /* TOTAL_COUNT */
		);
	/**************************************************/

	/**************************************************/
	self.PAGINATION_NBR = ko.observable(_List_Pagination()[0].CODE_VALUE_EN);
	self.UserSM.END_ROW(self.PAGINATION_NBR());

	self.PAGINATION_NBR.subscribe(function (newVal) {
		if (newVal != null) {
			self.UserSM.END_ROW(newVal);
			self.SearchUser();
		}
	});
    /**************************************************/


    /**************************************************/
    self.getAllowedMenus = function (user) {
        var js_Title = user.USERNAME();
        sessionStorage["selected_User"] = ko.mapping.toJSON(user);
        jq_OpenUIDialog('../User_menu/User_menuList.aspx', js_Title, 500, 450);
    }
    /**************************************************/
    
	/**************************************************/
	self.SearchUser = function () {
		/* ---------------- */
		var Get_User_By_Criteria_Success = function (i_Response) {
			self.Users
			(
				ko.utils.arrayMap(i_Response.My_Result, function (User) {
					return new UserModel
					(
						User.USER_ID,
						User.OWNER_ID,
						User.USERNAME,
						User.PASSWORD,
						User.USER_TYPE_CODE,
						User.IS_ACTIVE,
						User.ENTRY_DATE)
				}));
		}
		/* ---------------- */

		/* ---------------- */
		var Get_User_By_Criteria_Failure = function () {}
		/* ---------------- */

		/* ---------------- */
		_Params = ko.mapping.toJSON(self.UserSM);
		_Service_Method = "Get_User_By_Criteria";
		CallService_Element(Get_User_By_Criteria_Success, Get_User_By_Criteria_Failure);
		/* ---------------- */

	}
	/**************************************************/

	/**************************************************/
	self.addUser = function () {
		var match = ko.utils.arrayFirst(self.Users(), function (item) {
				return item.USER_ID() == -1;
			});

		if (match == null) {
			var user = new UserModel
				(
					-1,
					0 /* OWNER_ID */
				,
					'' /* USERNAME */
				,
					'' /* PASSWORD */
				,
					'' /* USER_TYPE_CODE */
				,
					false /* IS_ACTIVE */
				,
					'' /* ENTRY_DATE */
				);
			self.Users.unshift(user);
		}
	}
	/**************************************************/

	/**************************************************/
	self.saveUser = function (user) {
	    if (user.errors().length == 0) {
	        _Params = ko.toJSON(user);
	        _Service_Method = "Edit_User";
	        var Edit_SuccessHandler = function (Srv_Response) {
	            self.SearchUser();
	            /*
                var index = self.Users.indexOf(user);
	            self.Users.splice
				(
					index,
					1,
					new UserModel
					(
						Srv_Response.My_User.USER_ID,
						Srv_Response.My_User.OWNER_ID,
						Srv_Response.My_User.USERNAME,
						Srv_Response.My_User.PASSWORD,
						Srv_Response.My_User.USER_TYPE_CODE,
						Srv_Response.My_User.IS_ACTIVE,
						Srv_Response.My_User.ENTRY_DATE));
                */
	        };
	        CallService_Element(Edit_SuccessHandler, null);
	    } else {
	        user.errors.showAllMessages();
	    }
	};
	/**************************************************/

	/**************************************************/
	self.removeUser = function (user) {
		/* Prepare OK & CANCEL handlers for Confirmation Message */
		/* ------------------------------------------------------------------*/
		var OK_Handler = function () {
			if (user.USER_ID != -1) {
				var _Params_Delete_User = new Object();
				_Params_Delete_User.USER_ID = user.USER_ID;
				_Params = ko.toJSON(_Params_Delete_User);
				_Service_Method = "Delete_User";

				var Delete_SuccessHandler = function () {
					self.Users.remove(user);
				};
				CallService_Element(Delete_SuccessHandler, null);
			} else {
				self.Users.remove(user);
			}
		};

		var CANCEL_Handler = function () {};
		/* ------------------------------------------------------------------*/

		/* Display Confirmation Message */
		/* ------------------------------------------------------------------*/
		if (confirm(_GLB_MSG_DELETE_CONFIRM)) {
			OK_Handler();
		} else {
			CANCEL_Handler();
		}
		/* ------------------------------------------------------------------*/
	};

	/**************************************************/
}
/**************************************************/

/************************************************/
var MyVM = null;
/************************************************/

/************************************************/
$(document).ready
(
	function () {
	MyVM = new UserViewModel();
	ko.applyBindings(MyVM);
});
/************************************************/
