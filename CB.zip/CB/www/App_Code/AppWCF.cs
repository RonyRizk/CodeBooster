using System;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Collections.Generic;
using System.Text;
using System.Configuration;
using System.IO;
using System.Web.Hosting;
using System.ServiceModel.Web;
using System.ServiceModel.Channels;
using System.Web.Script.Serialization;
using System.Net;
using BLC;
[ServiceContract(Namespace = "")]
[AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
public partial class AppWCF
{
#region Members
#endregion
#region Extract_Ticket
private string Extract_Ticket()
{
#region Declaration And Initialization Section.
string str_Ticket = string.Empty;
#endregion
#region Body Section.
// --------------------
var oIncomingMessageProperties = OperationContext.Current.IncomingMessageProperties;
if (oIncomingMessageProperties != null)
{
var oHttpRequestMessageProperty = oIncomingMessageProperties[HttpRequestMessageProperty.Name] as HttpRequestMessageProperty;
if (oHttpRequestMessageProperty != null)
{
string str_QueryString = oHttpRequestMessageProperty.QueryString;
if (string.IsNullOrEmpty(str_QueryString) == false)
{
string[] oQueryString_Parts = str_QueryString.Split(new char[] { '&' });
if
(
(oQueryString_Parts != null) &&
(oQueryString_Parts.Count() > 0)
)
{
foreach(var oRow_QueryString_Part in oQueryString_Parts)
{
if (oRow_QueryString_Part.ToUpper().StartsWith("TICKET") == true)
{
string[] oTicket_Parts  = oRow_QueryString_Part.Split(new char[] {'='});
if
(
(oTicket_Parts != null) &&
(oTicket_Parts.Count() > 0)
)
{
str_Ticket = oTicket_Parts[1].ToString();
str_Ticket = str_Ticket + "=";
}
}
}
}
}
}
}
// --------------------
#endregion
#region Return Section.
return str_Ticket;
#endregion
}
#endregion
#region IsValidWebTicket
private bool IsValidWebTicket(string i_Input)
{
#region Declaration And Initialization Section.
bool Is_Valid = false;
BLCInitializer oBLCInitializer = new BLCInitializer();
#endregion
#region Body Section.
BLC.BLC oBLC_Default = new BLC.BLC();
oBLCInitializer.ConnectionString = ConfigurationManager.AppSettings["CONN_STR"];
using (BLC.BLC oBLC = new BLC.BLC(oBLCInitializer))
{
Is_Valid = oBLC.IsValidTicket(i_Input);
}
#endregion
#region Return Section.
return Is_Valid;
#endregion
}
#endregion
}

#region Action_Result
public partial class Action_Result
{
#region Properties.
public string ExceptionMsg { get; set; }
#endregion
#region Constructor
public Action_Result()
{
#region Declaration And Initialization Section.
#endregion
#region Body Section.
this.ExceptionMsg = string.Empty;
#endregion
}
#endregion
}
#endregion


