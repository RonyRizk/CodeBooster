using System;
using System.Web.UI;
using System.Web.UI.HtmlControls;

public class BasePage : Page
{
    protected override void OnInit(EventArgs e)
    {        
        base.OnInit(e);
    }
}
