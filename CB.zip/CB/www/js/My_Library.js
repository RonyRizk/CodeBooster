﻿
// KO Validation //
/***********************************/
ko.validation.configure({
    registerExtenders: true,
    messagesOnModified: true,
    decorateInputElement: true,
    insertMessages: true,
    parseInputAttributes: true,
    messageTemplate: null,
    grouping: { deep: true, observable: true }
});
/***********************************/

/***********************************/
var _GLB_MSG_DELETE_CONFIRM = 'Are you sure you want to delete it ?';
/***********************************/

// ---------------------------------------------------------------
$(document).ready(function () {

});
// ---------------------------------------------------------------

// ---------------------------------------------------------------
$(document).ajaxStart
(
    function () {
        $.blockUI({ message: '<img src="../../Images/ajax-loading.gif" />' });
    }
).ajaxStop
    (
        function () {
            $.unblockUI();
        }
    );
// ---------------------------------------------------------------

// ---------------------------------------------------------------
//"/AppWCF.svc";
var _WCF_Base_Url = 'http://localhost/Training/AppWCF.svc';
var _Service_Method = "";
var _Params = "";
var _Ticket = "";
var _Content_Type = "application/json; charset=utf-8";
var _Type = "POST";
var _Data_Type = "json";
var _ProcessData = false;
var _Async = true;
var _LIST_ITEMS_PER_PAGE = 50;
var _UserInfo = "";
var SuccessMsg = "Successfully saved.";

if (localStorage.getItem('UserInfo') != null) {
    _UserInfo = JSON.parse(localStorage.getItem('UserInfo'));
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
var Type = _Type;
var Url = "";
var ContentType = _Content_Type;
var DataType = _Data_Type;
var ProcessData = _ProcessData;
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function js_Prepare_WCF_Url_For_Call() {
    try {
        var js_Return = "";

        if (_Ticket != null) {
            _Ticket = _UserInfo.Ticket;
        }
        else {
            _Ticket = "";
        }

        js_Return = _WCF_Base_Url + "/" + _Service_Method + "?" + "Ticket=" + encodeURIComponent(_Ticket);

        return js_Return;
    }
    catch (e) {
        toastr.error("js_Prepare_WCF_Url_For_Call");
    }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function CallService(i_Success_Method, i_Failure_Method) {
    $.ajax({
        type: Type,
        url: js_Prepare_WCF_Url_For_Call(),
        data: _Params,
        method: _Service_Method,
        contentType: ContentType,
        dataType: DataType,
        processdata: ProcessData,
        async: _Async,
        success: function (i_Srv_Response) {
            _Async = true;
            if (i_Srv_Response.ExceptionMsg != '') {
                if (i_Failure_Method) {
                    if (i_Failure_Method == Service_Call_InCompleted)
                        Service_Call_InCompleted(i_Srv_Response.ExceptionMsg);
                    else
                        i_Failure_Method();
                }
            }
            else {
                //Service_Call_Completed(i_Service_Method, i_Srv_Response)
                if (i_Success_Method) {
                    i_Success_Method(i_Srv_Response);
                }
            }
        },
        error: ServiceFailed
    });
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function Service_Call_InCompleted(ExceptionMsg) {
    try {
        if (parent != undefined)
            parent.toastr.error(ExceptionMsg, 'Error');
        else
            toastr.error(ExceptionMsg, 'Error');
    } catch (e) {

    }

}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function ServiceFailed(xhr, textStatus, errorThrown) {
    try {
        // ----------
        toastr.error("System Error!", textStatus + '~' + errorThrown);
        // ----------

        // ----------       
        return false;
        // ----------
    }
    catch (e) {
        //toastr.error("ServiceFailed: " + e.Message);
        return false;
    }

}
// ---------------------------------------------------------------


// ---------------------------------------------------------------
function CallService_Element(i_Success_Method, i_Failure_Method, i_Silent) {
    $.ajax({
        type: Type,
        url: js_Prepare_WCF_Url_For_Call(),
        data: _Params,
        contentType: ContentType,
        dataType: DataType,
        processdata: ProcessData,
        success: function (i_Srv_Response) {
            if (i_Srv_Response.ExceptionMsg != '') {
                alert(i_Srv_Response.ExceptionMsg);
                if (i_Failure_Method) {
                    i_Failure_Method();
                }
            }
            else {
                if (i_Success_Method) {
                    i_Success_Method(i_Srv_Response);
                }
            }
        },
        error: function (xhr, textStatus, errorThrown) {           
            if (i_Failure_Method) {
                i_Failure_Method();
            }
        }
    });
}
// ---------------------------------------------------------------


// ---------------------------------------------------------------
function Fill_Setup_DDL(js_DDL_ID, js_SetupEntries, js_Tbl_name, js_Dest_Object, js_Dest_Property, js_Add_Default_Entry) {
    try {

        // ------------------                                
        var js_List_Items = "";
        if (js_Add_Default_Entry == 1) {
            js_List_Items += "<option value=''>--------------------------</option>";
        }
        // ------------------                                


        // ------------------                                
        for (var i = 0; i < js_SetupEntries.length; i++) {
            if (js_SetupEntries[i].TBL_NAME == js_Tbl_name) {
                js_List_Items +=
                                    "<option value='" +
                                    js_SetupEntries[i].CODE_NAME +
                                    "'>" +
                                    js_SetupEntries[i].CODE_VALUE_EN +
                                    "</option>";
            }
        }
        // ------------------                                

        // ------------------                                
        $(js_DDL_ID).html(js_List_Items);
        // ------------------                                

        // ------------------                                
        $(js_DDL_ID).change(function () {
            js_Dest_Object[js_Dest_Property] = $(this).val();
        });
        // ------------------
    }
    catch (e) {
        toastr.error("Fill_Setup_DDL:" + e.Message);
    }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function Get_Setup_List(js_Tbl_name, js_Add_Default_Entry) {
    try {
        // ------------------
        var js_List_Items = [];
        // ------------------ 

        // ------------------                                        
        if (js_Add_Default_Entry == 1) {
            var oSetupEntry = new Object();
            oSetupEntry.CODE_NAME = "";
            oSetupEntry.TBL_NAME = js_Tbl_name;
            oSetupEntry.CODE_VALUE_EN = "--------------------------";
            oSetupEntry.CODE_VALUE_FR = "--------------------------";
            oSetupEntry.CODE_VALUE_AR = "--------------------------";

            js_List_Items.push(oSetupEntry);
        }
        // ------------------  

        // ------------------ 
        js_SetupEntries = JSON.parse(localStorage.getItem("SetupEntries"));
        // ------------------ 

        // ------------------
        if (js_SetupEntries != null) {
            for (var i = 0; i < js_SetupEntries.length; i++) {
                if (js_SetupEntries[i].TBL_NAME == js_Tbl_name) {
                    js_List_Items.push(js_SetupEntries[i]);
                }
            }
        }
        // ------------------                                

        // ------------------                                
        return js_List_Items;
        // ------------------                                

    }
    catch (e) {
        toastr.error("Get_Setup_List:" + e.Message);
    }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function Get_Related_List_From_Storage(js_Storage_Key) {
    try {

        // ------------------
        var js_List_Items = [];
        // ------------------ 

        // ------------------ 
        js_Related_Entries = JSON.parse(localStorage.getItem(js_Storage_Key));
        // ------------------ 

        // ------------------
        if (js_Related_Entries != null) {
            for (var i = 0; i < js_Related_Entries.length; i++) {
                js_List_Items.push(js_Related_Entries[i]);
            }
        }
        // ------------------                                
        // ------------------                               
        return js_List_Items;
        // ------------------                                

    }
    catch (e) {
        toastr.error("Get_Related_List_From_Storage:" + e.Message);
    }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function Fill_AutoComplete(js_AutoComplete_ID, js_Source, js_Code_Field, js_Desc_Field, js_Dest_Object, js_Dest_Property) {
    try {

        // ------------------------
        $(js_AutoComplete_ID).autocomplete
            (
                {
                    selectFirst: true,
                    minLength: 0,
                    source: js_Source,
                    select: function (event, ui) {
                        js_Dest_Object[js_Dest_Property] = eval("ui.item." + js_Code_Field);
                        $(js_AutoComplete_ID).val(eval("ui.item." + js_Desc_Field));
                        return false;
                    }
                })
                    .data("autocomplete")._renderItem = function (ul, item) {
                        return $("<li></li>")
		                .data("item.autocomplete", item)
		                .append("<a>" + eval("item." + js_Desc_Field) + "</a>")
		                .appendTo(ul);
                    };
        // ------------------------
    }
    catch (e) {
        toastr.error("Fill_AutoComplete : " + e.Message);
    }
}
// ---------------------------------------------------------------

// ---------------------------------------------------------------
function ResolveSetupEntry(i_Table_Name, i_Code_Name) {
    try {

        // --------------        
        var js_SetupEntries = JSON.parse(localStorage.getItem("SetupEntries"));
        var js_Return_Value = "Not Resolved";
        // --------------


        // --------------
        if (js_SetupEntries != null) {
            for (var i = 0; i < js_SetupEntries.length; i++) {
                if
                (
                    (js_SetupEntries[i]["TBL_NAME"] == i_Table_Name) &&
                    (js_SetupEntries[i]["CODE_NAME"] == i_Code_Name)
                ) {
                    js_Return_Value = js_SetupEntries[i].CODE_VALUE_EN;
                }
            }
        }
        // --------------

        // --------------
        return js_Return_Value;
        // --------------

    }
    catch (e) {
        toastr.error("ResolveSetupEntry: " + e.Message);
    }
}
// ---------------------------------------------------------------



/* --------------------------------------------------------------- */
function Setup_Converter(i_Cell_Value, i_Col_Definition, i_RowObject) {
    try {

        if (i_Cell_Value != "") {
            var js_TBL_NAME = i_Col_Definition["colModel"]["formatoptions"]["TBL_NAME"];
            return ResolveSetupEntry(js_TBL_NAME, i_Cell_Value);
        }
        else {
            return "";
        }
    }
    catch (e) {
        toastr.error("Setup_Converter:" + e.Message);
    }
}
/* --------------------------------------------------------------- */


/* --------------------------------------------------------------- */
function Decimal_Converter(i_Cell_Value, i_Col_Definition, i_RowObject) {
    try {

        if (i_Cell_Value != "") {
            var js_FORMAT = i_Col_Definition["colModel"]["formatoptions"]["FORMAT"];
            return $.formatNumber(i_Cell_Value, { format: js_FORMAT, locale: "us" }); ;
        }
        else {
            return "";
        }
    }
    catch (e) {
        toastr.error("Decimal_Converter:" + e.Message);
    }
}

/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function Show_Dialog(i_Url, i_Title, i_Width, i_Height) {
    try {

        var js_Dialog_Properties = 'dialogHeight=' + i_Height + ';' + 'dialogWidth=' + i_Width + 'status=no;help=no';
        return js_Popup(i_Url, js_Dialog_Properties, i_Title);

    }
    catch (e) {
        toastr.error("Show_Dialog: " + e.Message);
    }
}
/* --------------------------------------------------------------- */



/* --------------------------------------------------------------- */
function Get_Grid_Selected_Object(i_Object_ID, i_Selected_ID, i_Data_List) {
    try {
        // ------------------------
        var js_Return = "";
        // ------------------------

        // ------------------------
        if (i_Data_List != null) {
            for (oItem in i_Data_List) {
                if (i_Data_List[oItem][i_Object_ID] == i_Selected_ID) {
                    js_Return = i_Data_List[oItem];
                }
            }
        }
        // ------------------------

        // ------------------------
        return js_Return;
        // ------------------------
    }
    catch (e) {
        toastr.error("Get_Grid_Selected_Object: " + e.Message);
    }
}
/* --------------------------------------------------------------- */

/* --------------------------------------------------------------- */
function js_Popup(url, properties, jsTitle) {
    try {
        var winref;
        var Arguments = new Array();
        var sRoot;
        Arguments[0] = window;
        Arguments[1] = url;
        Arguments[2] = jsTitle;
        winref = window.showModalDialog(url, Arguments, properties);
        return winref;
    }
    catch (e) {
        toastr.error("js_Popup: " + e.message);
    }
}
/* --------------------------------------------------------------- */


/* --------------------------------------------------------------- */
function js_GetReference() {
    try {
        var Arguments = new Array();
        var MyParent;
        Arguments = window.dialogArguments;
        if (Arguments != null) {
            MyParent = Arguments[0];
            return MyParent;
        }
        else {
            return window.self.opener;
        }
    }
    catch (e) {
        toastr.error("js_GetReference:" + e.message);
    }
}
/* --------------------------------------------------------------- */


/* --------------------------------------------------------------- */
function Set_AutoComplete(i_Control_Id, i_Data_List, i_Value_Field, i_Text_Field, i_Selected_Value) {
    try {

        var js_Corresponding_Item = null;

        if (i_Data_List != null) {
            for (oItem in i_Data_List) {
                if (i_Data_List[oItem][i_Value_Field] == i_Selected_Value) {
                    js_Corresponding_Item = i_Data_List[oItem];
                    $(i_Control_Id).autocomplete("search", js_Corresponding_Item[i_Text_Field]);
                }
            }
        }
        if (js_Corresponding_Item != null) {
            $(i_Control_Id).val(js_Corresponding_Item[i_Text_Field]);
        }
    }
    catch (e) {
        toastr.error("Set_AutoComplete: " + e.Message);
    }
}
/* --------------------------------------------------------------- */


/* --------------------------------------------------------------- */
function Get_AutoComplete(i_Control_Id, i_Data_List, i_Value_Field, i_Text_Field) {
    try {

        // ---------------------/* --------------------------------------------------------------- */
        //jqAuto -- main binding (should contain additional options to pass to autocomplete)
        //jqAutoSource -- the array of choices
        //jqAutoValue -- where to write the selected value
        //jqAutoSourceLabel -- the property that should be displayed in the possible choices
        //jqAutoSourceInputValue -- the property that should be displayed in the input box
        //jqAutoSourceValue -- the property to use for the value
        ko.bindingHandlers.jqAuto = {
            init: function (element, valueAccessor, allBindingsAccessor, viewModel) {
                var options = valueAccessor() || {},
            allBindings = allBindingsAccessor(),
            unwrap = ko.utils.unwrapObservable,
            modelValue = allBindings.jqAutoValue,
            source = allBindings.jqAutoSource,
            valueProp = allBindings.jqAutoSourceValue,
            inputValueProp = allBindings.jqAutoSourceInputValue || valueProp,
            labelProp = allBindings.jqAutoSourceLabel || valueProp;

                //function that is shared by both select and change event handlers
                function writeValueToModel(valueToWrite) {
                    if (ko.isWriteableObservable(modelValue)) {
                        modelValue(valueToWrite);
                    } else {  //write to non-observable
                        if (allBindings['_ko_property_writers'] && allBindings['_ko_property_writers']['jqAutoValue'])
                            allBindings['_ko_property_writers']['jqAutoValue'](valueToWrite);
                    }
                }

                //on a selection write the proper value to the model
                options.select = function (event, ui) {
                    writeValueToModel(ui.item ? ui.item.actualValue : null);
                };

                //on a change, make sure that it is a valid value or clear out the model value
                options.change = function (event, ui) {
                    var currentValue = $(element).val();
                    var matchingItem = ko.utils.arrayFirst(unwrap(source), function (item) {
                        return unwrap(item[inputValueProp]) === currentValue;
                    });

                    if (!matchingItem) {
                        writeValueToModel(null);
                    }
                }


                //handle the choices being updated in a DO, to decouple value updates from source (options) updates
                var mappedSource = ko.dependentObservable(function () {
                    mapped = ko.utils.arrayMap(unwrap(source), function (item) {
                        var result = {};
                        result.label = labelProp ? unwrap(item[labelProp]) : unwrap(item).toString();  //show in pop-up choices
                        result.value = inputValueProp ? unwrap(item[inputValueProp]) : unwrap(item).toString();  //show in input box
                        result.actualValue = valueProp ? unwrap(item[valueProp]) : item;  //store in model
                        return result;
                    });
                    return mapped;
                });

                //whenever the items that make up the source are updated, make sure that autocomplete knows it
                mappedSource.subscribe(function (newValue) {
                    $(element).autocomplete("option", "source", newValue);
                });

                options.source = mappedSource();

                //initialize autocomplete
                $(element).autocomplete(options);
            },
            update: function (element, valueAccessor, allBindingsAccessor, viewModel) {
                //update value based on a model change
                var allBindings = allBindingsAccessor(),
           unwrap = ko.utils.unwrapObservable,
           modelValue = unwrap(allBindings.jqAutoValue) || '',
           valueProp = allBindings.jqAutoSourceValue,
           inputValueProp = allBindings.jqAutoSourceInputValue || valueProp;

                //if we are writing a different property to the input than we are writing to the model, then locate the object
                if (valueProp && inputValueProp !== valueProp) {
                    var source = unwrap(allBindings.jqAutoSource) || [];
                    var modelValue = ko.utils.arrayFirst(source, function (item) {
                        return unwrap(item[valueProp]) === modelValue;
                    }) || {};  //probably don't need the || {}, but just protect against a bad value          
                }

                //update the element with the value that should be shown in the input
                $(element).val(modelValue && inputValueProp !== valueProp ? unwrap(modelValue[inputValueProp]) : modelValue.toString());
            }
        };
        var js_Corresponding_Item = null;
        var js_Selected_Value = null;
        var js_Return_Value = null;
        // ---------------------

        // ---------------------
        js_Selected_Value = $(i_Control_Id).val();
        // ---------------------

        // ---------------------
        if (i_Data_List != null) {
            for (oItem in i_Data_List) {
                if (i_Data_List[oItem][i_Text_Field] == js_Selected_Value) {
                    js_Corresponding_Item = i_Data_List[oItem];
                }
            }
        }
        // ---------------------

        // ---------------------        
        if (js_Corresponding_Item != null) {
            js_Return_Value = js_Corresponding_Item[i_Value_Field];
        }
        // ---------------------

        // ---------------------
        return js_Return_Value;
        // ---------------------

    }
    catch (e) {
        toastr.error("Get_AutoComplete: " + e.Message);
    }
}
/* --------------------------------------------------------------- */


/* --------------------------------------------------------------- */
//jqAuto -- main binding (should contain additional options to pass to autocomplete)
//jqAutoSource -- the array of choices
//jqAutoValue -- where to write the selected value
//jqAutoSourceLabel -- the property that should be displayed in the possible choices
//jqAutoSourceInputValue -- the property that should be displayed in the input box
//jqAutoSourceValue -- the property to use for the value
ko.bindingHandlers.jqAuto = {
    init: function (element, valueAccessor, allBindingsAccessor, viewModel) {
        var options = valueAccessor() || {},
            allBindings = allBindingsAccessor(),
            unwrap = ko.utils.unwrapObservable,
            modelValue = allBindings.jqAutoValue,
            source = allBindings.jqAutoSource,
            valueProp = allBindings.jqAutoSourceValue,
            inputValueProp = allBindings.jqAutoSourceInputValue || valueProp,
            labelProp = allBindings.jqAutoSourceLabel || valueProp;

        //function that is shared by both select and change event handlers
        function writeValueToModel(valueToWrite) {
            if (ko.isWriteableObservable(modelValue)) {
                modelValue(valueToWrite);
            } else {  //write to non-observable
                if (allBindings['_ko_property_writers'] && allBindings['_ko_property_writers']['jqAutoValue'])
                    allBindings['_ko_property_writers']['jqAutoValue'](valueToWrite);
            }
        }

        //on a selection write the proper value to the model
        options.select = function (event, ui) {
            writeValueToModel(ui.item ? ui.item.actualValue : null);
        };

        //on a change, make sure that it is a valid value or clear out the model value
        options.change = function (event, ui) {
            var currentValue = $(element).val();
            var matchingItem = ko.utils.arrayFirst(unwrap(source), function (item) {
                return unwrap(item[inputValueProp]) === currentValue;
            });

            if (!matchingItem) {
                writeValueToModel(null);
            }
        }


        //handle the choices being updated in a DO, to decouple value updates from source (options) updates
        var mappedSource = ko.dependentObservable(function () {
            mapped = ko.utils.arrayMap(unwrap(source), function (item) {
                var result = {};
                result.label = labelProp ? unwrap(item[labelProp]) : unwrap(item).toString();  //show in pop-up choices
                result.value = inputValueProp ? unwrap(item[inputValueProp]) : unwrap(item).toString();  //show in input box
                result.actualValue = valueProp ? unwrap(item[valueProp]) : item;  //store in model
                return result;
            });
            return mapped;
        });

        //whenever the items that make up the source are updated, make sure that autocomplete knows it
        mappedSource.subscribe(function (newValue) {
            $(element).autocomplete("option", "source", newValue);
        });

        options.source = mappedSource();

        //initialize autocomplete
        $(element).autocomplete(options);
    },
    update: function (element, valueAccessor, allBindingsAccessor, viewModel) {
        //update value based on a model change
        var allBindings = allBindingsAccessor(),
           unwrap = ko.utils.unwrapObservable,
           modelValue = unwrap(allBindings.jqAutoValue) || '',
           valueProp = allBindings.jqAutoSourceValue,
           inputValueProp = allBindings.jqAutoSourceInputValue || valueProp;

        //if we are writing a different property to the input than we are writing to the model, then locate the object
        if (valueProp && inputValueProp !== valueProp) {
            var source = unwrap(allBindings.jqAutoSource) || [];
            var modelValue = ko.utils.arrayFirst(source, function (item) {
                return unwrap(item[valueProp]) === modelValue;
            }) || {};  //probably don't need the || {}, but just protect against a bad value          
        }

        //update the element with the value that should be shown in the input
        $(element).val(modelValue && inputValueProp !== valueProp ? unwrap(modelValue[inputValueProp]) : modelValue.toString());
    }
};
/* --------------------------------------------------------------- */



/* --------------------------------------------------------------- */
/* --------------------------------------------------------------- */
// Used for getting querystring variables
$.urlParam = function (name) {
    try {
        var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(window.location.href);
        if (results != null) {
            return results[1] || '';
        }
    }
    catch (e) {
        toastr.error('urlParam: ' + e.message);
    }
}
/* --------------------------------------------------------------- */
/* --------------------------------------------------------------- */
var _dlg = null;
function jq_OpenUIDialog(i_src, i_title, i_width, i_height,i_Close_Handler) {
    _dlg = $('<iframe>').dialog({
        show: "drop",
        hide: "drop",
        modal: true,
        position: "middle",
        dialogClass: 'dialogWithDropShadow',
        open: function () {
            $(this).attr({ src: i_src });
            $(this).css({ width: i_width + 'px', height: i_height + 'px' });
        },
        close: function (e, i) { $(this).dialog('destroy').remove(); _dlg = null; if (i_Close_Handler != null) { i_Close_Handler(); } },
        width: i_width + 25,
        //height: 300,            
        title: i_title
    });
}
/* --------------------------------------------------------------- */


/* --------------------------------------------------------------- */
function jq_CloseUIDialog(i_message, i_status) {
    _dlg.dialog('close');

    if (i_status) {
        switch (i_status) {
            case 0:
                /* Display Notification */
                /* ------------------------------------------------------------------*/
                jq_DisplayNotification(i_message, 'fail');
                /* ------------------------------------------------------------------*/
                break;
            case 1:
                /* Display Notification */
                /* ------------------------------------------------------------------*/
                jq_DisplayNotification(i_message, 'success');
                /* ------------------------------------------------------------------*/
                break;
        }
    }
}
/* --------------------------------------------------------------- */
/* JqGrid_Validation_Override */
/* --------------------------------------------------------------- */
function jq_Post_Handle_Grid() {
    try {
        /* Check logged in UserType to set related _editableColM = true/false, _hidden_Trans_ColM = true/false */
        if (_UserInfo) {
            if (_UserInfo.USER_TYPE_CODE == 3) { // 3 = TRANSLATOR                                
                $('img.add[class*="action-trigger"]').hide();
                $('img.delete[class*="action-trigger"]').hide();
            }
        }
        /* --------------------------------------------------------------- */
    }
    catch (e) {
        toastr.error('jq_Post_Handle_Grid: ' + e.messages);
    }
}
/* --------------------------------------------------------------- */

//----------------------------------------------------------------
function jq_DisplayNotification(message, status) {
    if (!status) {
        status = 'success';
    }
    if (message == '') {
        switch (status) {
            case "success":
                message = "Successfully saved.";
                break;
            case "fail":
                message = "Error.";
                break;
        }
    }

    var waitholder = $("<div id=\"notification\"/>");
    $("body").prepend(waitholder);
    //$(window.parent.document.body).prepend(waitholder);

    var $waitholder = $("#notification");
    //var $waitholder = $("#notification", parent.document.body);    

    if (status == 'success') {
        $(waitholder).removeClass('err').html(message).addClass('succ');
        $(waitholder).fadeIn(100).delay(2000).slideUp();
    }
    else if (status == 'fail') {
        $(waitholder).removeClass('succ').html(message).addClass('err').append($('<br><span style="cursor:pointer">[Dismiss]</span>').click(function (e) { $(waitholder).slideUp(); }));
        $(waitholder).fadeIn(100);
    }
    /*else if (status == 'wait') {
    $(waitholder).html(waitnote);
    }*/
}
//----------------------------------------------------------------



if (!String.prototype.trim) {
    String.prototype.trim = function () {
        return this.replace(/^\s+|\s+$/g, '');
    };
}

function sortOn(property) {
    return function (a, b) {
        if (a[property].toUpperCase() < b[property].toUpperCase()) {
            return -1;
        } else if (a[property].toUpperCase() > b[property].toUpperCase()) {
            return 1;
        } else {
            return 0;
        }
    }
}

function LogOut() {
    localStorage.removeItem('UserInfo');
    window.location.href = "../Login/Login.html";
}

function getDateDiff(date1, date2, interval) {
    var second = 1000,
    minute = second * 60,
    hour = minute * 60,
    day = hour * 24,
    week = day * 7;
    date1 = new Date(date1).getTime();
    date2 = (date2 == 'now') ? new Date().getTime() : new Date(date2).getTime();
    var timediff = date2 - date1;
    if (isNaN(timediff)) return NaN;
    switch (interval) {
        case "years":
            return date2.getFullYear() - date1.getFullYear();
        case "months":
            return ((date2.getFullYear() * 12 + date2.getMonth()) - (date1.getFullYear() * 12 + date1.getMonth()));
        case "weeks":
            return Math.floor(timediff / week);
        case "days":
            return Math.floor(timediff / day);
        case "hours":
            return Math.floor(timediff / hour);
        case "minutes":
            return Math.floor(timediff / minute);
        case "seconds":
            return Math.floor(timediff / second);
        default:
            return undefined;
    }
}

function getTimeDiff(date1, date2) {
    try {
        var second = 1000,
    minute = second * 60,
    hour = minute * 60,
    day = hour * 24,
    week = day * 7;
        date1 = new Date(date1);
        date2 = (date2 == 'now') ? new Date() : new Date(date2);
        var timediff = date2 - date1;
        if (isNaN(timediff)) return NaN;
        var years = date2.getFullYear() - date1.getFullYear();
        var months = ((date2.getFullYear() * 12 + date2.getMonth()) - (date1.getFullYear() * 12 + date1.getMonth()));
        var weeks = Math.floor(timediff / week);
        var days = Math.floor(timediff / day);
        var hours = Math.floor(timediff / hour);
        var minutes = Math.floor(timediff / minute);
        var seconds = Math.floor(timediff / second);

        if (seconds <= 60)
            return "Just now";
        else
            if (minutes < 60)
                return minutes + " mns";
            else
                if (hours < 24)
                    return hours + " hrs";
                else
                    if (days < 7)
                        return days + " dys";
                    else
                        if (weeks < 4)
                            return weeks + " wks";
                        else
                            if (months < 12)
                                return months + " mnths";
                            else
                                return years + " years";
    } catch (e) {
        return "NaN";
    }

}
function GetActionsMessage(cellvalue, options, rowObject) {
    if (cellvalue == "")
        return "";
    return "<center><a class='ico ico-edit' title='Edit me' onclick='EditItem(" + cellvalue + ")' /><a class='ico ico-delete' title='delete me' onclick='DeleteItem(" + cellvalue + ")' /></center>";
};


if (jQuery.jgrid != undefined) {
    (function ($) {
        jQuery.jgrid.fluid =
  {
      fluidGrid: function (options) {
          var grid = $(this);
          var settings = $.extend(
                        {
                            example: grid.closest('.ui-jqgrid').parent(),
                            offset: 0
                        }, options || {});

          var width = $(settings.example).innerWidth() + settings.offset;
          grid.setGridWidth(width);
      }
  }
    })(jQuery);
    jQuery.fn.extend({ fluidGrid: jQuery.jgrid.fluid.fluidGrid });
}


function scrollTop() {
    window.scrollTo(0, 0);
}


// Pagination Data
/**************************************************/
var _List_Pagination = ko.mapping.fromJS([]);
_List_Pagination.push({ "CODE_NAME": '50', "CODE_VALUE_EN": '50' });
_List_Pagination.push({ "CODE_NAME": '100', "CODE_VALUE_EN": '100' });
_List_Pagination.push({ "CODE_NAME": '1000', "CODE_VALUE_EN": '1000' });
/**************************************************/

/**************************************************/
ko.virtualElements.allowedBindings.jqmRefreshList = true;
ko.bindingHandlers.jqmRefreshList = {
    update: function (element, valueAccessor) {
        try {
            ko.utils.unwrapObservable(valueAccessor()); // make this update fire each time the array is updated.
            // locate the listview
            var listview = $(element).parents().andSelf().filter("[data-role='listview']");

            if (listview) {
                try {
                    $(listview).listview('refresh').enhanceWithin();
                }
                catch (e) { console.log(e.message); }
            }
        }
        catch (e) { console.log(e.message); }
    }
};
/**************************************************/


/**************************************************/
function checkboxFormat(cellvalue, options, rowObject) {
    var op = $.extend({}, $.jgrid.formatter.checkbox, options.colModel.formatoptions),
                        ds = op.disabled === true ? 'disabled="disabled"' : '';
    if ($.fmatter.isEmpty(cellvalue) || typeof cellvalue === 'undefined') { //$.fmatter.isUndefined(cellvalue)
        cellvalue = $.fn.fmatter.defaultFormat(cellvalue, op);
    }
    cellvalue = String(cellvalue).toLowerCase();
    return '<div style="position:relative"><input type="checkbox" ' +
                        (cellvalue.search(/(false|0|no|off)/i) < 0 ? " checked='checked' " : "") +
                        ' value="' + cellvalue + '" offval="no" ' + ds +
                        '/><div style="position:absolute;top:0px;left:0px;right:100%;bottom:100%;background:white;width:100%;height:100%;zoom:1;filter:alpha(opacity=0);opacity:0;"></div></div>';
}

function checkboxUnFormat(cellvalue, options, cell) {
    var cbv = (options.colModel.editoptions) ? options.colModel.editoptions.value.split(":") : ["Yes", "No"];
    return $('input', cell).is(":checked") ? cbv[0] : cbv[1];
}
/**************************************************/

/**************************************************/
function actionsFormatter(cellvalue, options, rowObject) {
    var str_Img = '';

    if (options.rowId) {
        if (options.rowId == "-1") {
            str_Img = '<img alt="Save row" title="Save row" src="../../images/Save_16x16.png" class="action-trigger save" style="cursor:pointer" />' + ' ' +
               '<img alt="Cancel row" title="Cancel row" src="../../images/Cancel_16x16.png" class="action-trigger cancel" style="cursor:pointer" />';
        }
        else {
            str_Img = '<img alt="Delete row" title="Delete row" src="../../images/Delete_16x16.png" class="action-trigger delete" style="cursor:pointer" />';
            switch (options.gid) {
                case "Grd_City":
                case "Grd_Travel_agency":
                case "Grd_Pois":
                case "Grd_Affiliate":
                case "Grd_Ac":
                case "Grd_Mpo":
                case "Grd_Bh":
                    str_Img += ' <img alt="Edit details" title="Edit details" src="../../images/Edit_16x16.png" class="action-trigger edit" style="cursor:pointer" />';
                    break;
                case "Grd_Person":
                    if (_UserInfo) {
                        if (_UserInfo.USER_TYPE_CODE != 1) {    // 1 = SUPER ADMIN - Can only delete Person
                            str_Img = '';
                        }
                    }
                    str_Img += ' <img alt="Edit details" title="Edit details" src="../../images/Edit_16x16.png" class="action-trigger edit" style="cursor:pointer" />';
                    break;
                case "Grd_Setup":
                    str_Img = '';
            }
        }
    }

    return str_Img;
}
/**************************************************/


/**************************************************/
function defaultActionFormatter() {
    return '<img alt="Delete row" title="Delete row" src="../../images/Delete_16x16.png" class="action-trigger delete" style="cursor:pointer" />';
}
/**************************************************/


/**************************************************/
function Get_Apartments_By_Building(i_List_Apartment, i_BUILDING_ID) {
    var js_Apartments = [];
    if (i_List_Apartment.length > 0) {
        for (var i = 0; i < i_List_Apartment.length; i++) {
            if (i_List_Apartment[i].BUILDING_ID == i_BUILDING_ID) {
                js_Apartments.push(i_List_Apartment[i]);
            }
        }
    }
}
/**************************************************/

/**************************************************/
function getBaseURL() {
    var url = _WCF_Base_Url.replace("AppWCF.svc", "");
    return url;
}
/**************************************************/