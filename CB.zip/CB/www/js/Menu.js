﻿/* --------------------------------------------------------------- */
function Build_Menu_Content() {
    try {

        // ---------------
        var js_UL_Main = $("#floatMenu");       
        var oMenu = JSON.parse(localStorage["Menu"]);        
        var str_LI_Content = "";
        // ---------------

       
        // ---------------
        if (oMenu != null) {

            for (i = 0; i < oMenu.Children.length; i++) {               
                str_LI_Content = "";


                if ((oMenu.Children[i].Children != null) && (oMenu.Children[i].Children.length > 0)) {
                    str_LI_Content += '<li>';
                    str_LI_Content += '<a href="#">' + oMenu.Children[i].CAPTION_EN + '</a>';
                    str_LI_Content += '<ul class="submenu">';
                    for (j = 0; j < oMenu.Children[i].Children.length; j++) {
                        str_LI_Content += '<li><a href="../' + oMenu.Children[i].Children[j].ACTION + '" class="link">' + oMenu.Children[i].Children[j].CAPTION_EN + '</a></li>';
                    }
                    str_LI_Content += '</ul>';
                    str_LI_Content += '</li>';                    
                }
                else {                   
                    str_LI_Content += '<li><a href="../' + oMenu.Children[i].ACTION + '" class="link">' + oMenu.Children[i].CAPTION_EN + '</a></li>';
                }               
                js_UL_Main.append(str_LI_Content);
            }
        }
        // ---------------

        // ---------------
        _Is_Main_Already_Created = true;
        // ---------------
    }
    catch (e) {
        alert("Build_Menu_Content: " + e.message);
    }
}
/* --------------------------------------------------------------- */